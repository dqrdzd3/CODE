//
//  ServerResult.h
//  
//
//  Created by 李静 on 14-10-31.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"
@interface ServerResult : JSONModel
@property(nonatomic,copy) NSString *message;
@property(nonatomic,copy) NSString *tableName;
@property(nonatomic,copy) NSString *code;
@property(nonatomic,assign) int count;
@property(nonatomic,copy) NSObject <Optional>*dataObject;
@property(nonatomic,copy) NSObject <Optional>*data;
- (BOOL)isOperateSuccess;
@end
