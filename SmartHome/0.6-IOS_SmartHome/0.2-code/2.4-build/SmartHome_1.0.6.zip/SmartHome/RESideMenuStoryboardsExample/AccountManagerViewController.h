//
//  AccountManagerViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-23.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@interface AccountManagerViewController : UIViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UILabel *phone;
@property (weak, nonatomic) IBOutlet UIButton *changeAccountBtn;
- (IBAction)changeAccountClick:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *oldPsdText;
@property (weak, nonatomic) IBOutlet UITextField *nPsdText;
@property (weak, nonatomic) IBOutlet UITextField *repeatPsdText;
@property (weak, nonatomic) IBOutlet UIButton *changePsdBtn;
- (IBAction)changePsdBtnClick:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *userHeadImage;
@property (weak, nonatomic) IBOutlet UIButton *userHeadBtn;
- (IBAction)userHeadBtnClick:(id)sender;
@property(nonatomic,copy)  User *userInfo;
@end
