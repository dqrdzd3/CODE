//
//  AccountManagerViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-23.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "AccountManagerViewController.h"
#import "UIButton+Bootstrap.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import "UIImageView+WebCache.h"
#import "../StringUtils.h"
@interface AccountManagerViewController ()


@end
#define PATH_OF_DOCUMENT    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
@implementation AccountManagerViewController
@synthesize userInfo;
//NSData* imageData = nil;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height+100);
    
    [_userName addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_email addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_oldPsdText addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_nPsdText addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_repeatPsdText addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    
    [_oldPsdText addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_nPsdText addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_repeatPsdText addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];

    
    // Do any additional setup after loading the view.
    [self getUserData];
    [_changeAccountBtn infoStyle];
    [_changePsdBtn infoStyle];
//    [_changeAccountBtn setHidden:YES];
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *name = [userDefaults objectForKey:@"USERNAME"];
    if(name!=nil){
        [_userName setText:name];
    }
    NSString *email = [userDefaults objectForKey:@"EMAIL"];
    if(email!=nil){
        [_email setText:email];
    }
    
    NSString *phoneStr = [userDefaults objectForKey:@"PHONE"];
    [_phone setText:phoneStr];

    [_oldPsdText setSecureTextEntry:YES];
    [_nPsdText setSecureTextEntry:YES];
    [_repeatPsdText setSecureTextEntry:YES];
    NSString *headImageUrl = [userDefaults objectForKey:@"HEADIMAGEURL"];
    [_userHeadImage setUserInteractionEnabled:YES];
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onClickHeadImage)];
    [_userHeadImage addGestureRecognizer:singleTap];
    
    if ([[NSFileManager defaultManager]fileExistsAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"]]) {
        [[NSFileManager defaultManager] removeItemAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"] error:nil];
    }
    if ([[NSFileManager defaultManager]fileExistsAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"]]) {
        [[NSFileManager defaultManager] removeItemAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"] error:nil];
    }
}

-(void)textViewEditBegin{
    [_scrollView setContentOffset:CGPointMake(0, 200) animated:YES];
}
-(void)textViewEditDone{
    [_scrollView setContentOffset:CGPointMake(0, -64) animated:YES];
    [_userName resignFirstResponder];
    [_email resignFirstResponder];
    [_oldPsdText resignFirstResponder];
    [_nPsdText resignFirstResponder];
    [_repeatPsdText resignFirstResponder];
}
-(void)onClickHeadImage{
    NSLog(@"图片被点击!");
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"选择一张图片作为头像" delegate:self  cancelButtonTitle:@"取消" destructiveButtonTitle:@"立即拍照上传" otherButtonTitles:@"从手机相册选取",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleAutomatic;
    [actionSheet showInView:self.view];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)changeAccountClick:(id)sender {
    NSString *name = _userName.text;
    if ([name length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *email = _email.text;

    if (email.length) {
        if (![StringUtils isValidateEmail:email]) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"邮箱格式不正确" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            return;
        }
    }
    
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };

    NSString *phoneNum = _phone.text;
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_01_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary * parameter = [NSMutableDictionary dictionaryWithObjectsAndKeys:userId,@"USERID",sessionId,@"SESSIONID",phoneNum,@"PHONE",name,@"USERNAME",email,@"EMAIL", nil];
    NSString *strimagePath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NSURL *filePath = [NSURL fileURLWithPath:strimagePath];
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    
    [manager POST:url parameters:parameter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileURL:filePath name:@"file" error:nil];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        ServerResult *result = [[ServerResult alloc] initWithDictionary:resultDic error:nil];
        if (result.isOperateSuccess) {
            //将上述数据全部存储到NSUserDefaults中
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            //存储时，除NSNumber类型使用对应的类型意外，其他的都是使用setObject:forKey:
            self.userInfo.ma017 = strimagePath;
            [userDefaults setObject:name forKey:@"USERNAME"];
            [userDefaults setObject:email forKey:@"EMAIL"];
            [userDefaults synchronize];
            
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:result.message delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            
        }else{
            NSString *errorMsg = result.message;
            NSLog(@"Error: %@", errorMsg);
            
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:result.message delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"网络连接失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];

}
- (IBAction)changePsdBtnClick:(id)sender {
    [self changePassword];
}

-(void)changePassword{
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSString *oldPassword = [_oldPsdText text];
    if ([oldPassword length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请输入老密码" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *password = [_nPsdText text];
    if (password.length == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"信息不能为空" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    if ([password length] < 6) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"新密码输入不合法" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *psdConfirm = [_repeatPsdText text];
    if (psdConfirm==nil) {
        return;
    }
    if (![password isEqualToString:psdConfirm]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"密码不一致" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_03];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"oldpass":oldPassword,@"MA009":password};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            //将上述数据全部存储到NSUserDefaults中
            [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"PASSWORD"];
            [_repeatPsdText setText:@""];
            [_oldPsdText setText:@""];
            [_nPsdText setText:@""];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:result.message delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];

        }else{
            NSString *errorMsg = result.message;
            NSLog(@"Error: %@", errorMsg);
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:result.message delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        [SVProgressHUD dismiss];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"网络连接失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];
}
- (IBAction)userHeadBtnClick:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"选择一张图片作为头像" delegate:self  cancelButtonTitle:@"取消" destructiveButtonTitle:@"立即拍照上传" otherButtonTitles:@"从手机相册选取",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleAutomatic;
    [actionSheet showInView:self.view];
}


#pragma mark UIActionSheet协议
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex ==0)
    {
        [self toCameraPickingController];
        
    }
    if (buttonIndex ==1) {
        [self toPhotoPickingController];
        
    }
    else return;
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *imagePicked = [info objectForKey:UIImagePickerControllerEditedImage];
    NSData* imageData = UIImageJPEGRepresentation(imagePicked, 0);
    
    NSString *strimagepath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:strimagepath]) {
        [[NSFileManager defaultManager] removeItemAtPath:strimagepath error:nil];
    }
    BOOL bwritetofile = [imageData writeToFile:strimagepath atomically:NO];
    if (!bwritetofile) {
        NSLog(@"保存图片失败");
    }
    [_userHeadImage setImage:imagePicked];
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    return;
}
//图片照相
- (void)toCameraPickingController
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        NSLog(@"Error:没有照相设备");
    }
    else {
        UIImagePickerController *cameraPicker = [[UIImagePickerController alloc] init];
        cameraPicker.delegate = self;
        cameraPicker.allowsEditing = YES;
        cameraPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:cameraPicker animated:YES completion:nil];
    }
}
//图片
- (void)toPhotoPickingController
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        NSLog(@"Error:无图片库");
    }
    else {
        UIImagePickerController *photoPicker = [[UIImagePickerController alloc] init];
        photoPicker.allowsEditing = YES;
        photoPicker.delegate = self;
        photoPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:photoPicker animated:YES completion:nil];
    }
}



-(void)getUserData{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_04];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *phoneStr = [userDefaults objectForKey:@"PHONE"];
    NSString *password = [userDefaults objectForKey:@"PASSWORD"];
    NSDictionary *parameter = @{@"PHONE":phoneStr,@"PASSWORD":password};
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        
        if (result.isOperateSuccess) {
            NSMutableDictionary *s = [[NSMutableDictionary alloc]initWithDictionary:result.dataObject];
            NSMutableArray *maryImage = [[NSMutableArray alloc]init];
            [maryImage addObjectsFromArray:[s objectForKey:@"ma017"]];
            if (maryImage.count != 0) {
                unsigned c = maryImage.count;
                uint8_t *bytes = malloc(sizeof(*bytes) * c);
                unsigned i;
                for (i = 0; i < c; i++)
                {
                    NSString *str = [maryImage objectAtIndex:i];
                    int byte = [str intValue];
                    bytes[i] = (uint8_t)byte;
                }
                NSData* dataImage = [NSData dataWithBytes:bytes length:sizeof(unsigned char)*c];
                
                [dataImage writeToFile:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"] atomically:NO];
                [s setObject:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"] forKey:@"ma017"];
            }
            else{
                [s setObject:@"" forKey:@"ma017"];
            }
            [self setUserInfoData:s];
        }
        [SVProgressHUD dismiss];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
}

-(void)setUserInfoData:(NSDictionary *)info{
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    self.userInfo = [[User alloc] initWithDictionary:info error:nil];
    NSString *userId = userInfo.ma001;
    NSString *sessionId = userInfo.ma010;
    NSString *email = userInfo.ma005;
    NSString *userName =userInfo.ma008;

    //将上述数据全部存储到NSUserDefaults中
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    //存储时，除NSNumber类型使用对应的类型意外，其他的都是使用setObject:forKey:
    [userDefaults setObject:userId forKey:@"USERID"];
    [userDefaults setObject:sessionId forKey:@"SESSIONID"];
    [userDefaults setObject:email forKey:@"EMAIL"];
    [userDefaults setObject:userName
                     forKey:@"USERNAME"];
    [userDefaults synchronize];
    
    if(userName!=nil){
        [_userName setText:userName];
    }

    if(email!=nil){
        [_email setText:email];
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:self.userInfo.ma017]) {
        _userHeadImage.image = [UIImage imageWithContentsOfFile:self.userInfo.ma017];
    }
    else{
        _userHeadImage.image = [UIImage imageNamed:@"userHeadImage"];
    }
    [SVProgressHUD dismiss];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  
    [_email resignFirstResponder];
    [_userName resignFirstResponder];
    [_oldPsdText resignFirstResponder];
    [_nPsdText resignFirstResponder];
    [_repeatPsdText resignFirstResponder];
}
@end
