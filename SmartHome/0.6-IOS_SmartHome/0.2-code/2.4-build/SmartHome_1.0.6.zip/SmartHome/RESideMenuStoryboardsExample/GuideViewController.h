//
//  GuideViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-20.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuideViewController : UIViewController
<
UIScrollViewDelegate
>
@property (strong, nonatomic) IBOutlet UIScrollView *pageScroll;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;
@property (strong, nonatomic) NSArray *photoList;

- (IBAction)PageValueChange:(id)sender;


@end
