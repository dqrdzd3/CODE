//
//  DescriptionConfigViewController.m
//  SmartHome
//
//  Created by 李静 on 14-11-25.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "DescriptionConfigViewController.h"
#import "UIButton+Bootstrap.h"
#import "PhoneBindDeviceController.h"

#import "DeviceUtil.h"
@interface DescriptionConfigViewController ()

@end

@implementation DescriptionConfigViewController
@synthesize deviceId;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initView];
}
-(void)initView{
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height+100);
    [_lastBtn dangerStyle];
    [_nextBtn successStyle];
    int deviceType = [DeviceUtil getDeviceType:self.deviceId];
    if (deviceType == SENSOR_TYPE_GAS) {
        [_desImage setImage:[UIImage imageNamed:@"ui_sensor_hardware_show_gas"]];
        [_configLabel setText:SENSOR_HARDWARE_GAS_HINT];
        [_powerImage setImage:[UIImage imageNamed:@"ui_sensor_hardware_power_gas"]];
        [_powerHint setText:SENSOR_HARDWARE_POWER_GAS_HINT];

    }else if (deviceType == SENSOR_TYPE_AIR){
        [_desImage setImage:[UIImage imageNamed:@"ui_sensor_hardware_show_air"]];
        [_configLabel setText:SENSOR_HARDWARE_AIR_HINT];
        [_powerImage setImage:[UIImage imageNamed:@"ui_sensor_hardware_power_air"]];
        [_powerHint setText:SENSOR_HARDWARE_POWER_AIR_HINT];
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)lastBtnClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)nextBtnClick:(id)sender {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HardwareViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"hardwareViewController"];
    ca.deviceId = deviceId;
    ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
    [self presentViewController:ca animated:YES completion:NULL];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
