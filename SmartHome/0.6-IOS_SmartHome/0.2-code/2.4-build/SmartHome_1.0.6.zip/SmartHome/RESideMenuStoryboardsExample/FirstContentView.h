//
//  FirstContentView.h
//  SmartHome
//
//  Created by apple on 14-11-12.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ShareSDK/ShareSDK.h>
#import "RESideMenu.h"
#import "CMPopTipView.h"
#import "PCLineChartView.h"
#import "KGModal.h"
#import "HistoryView.h"
#import "AirDevice.h"
#import "GasDevice.h"
#import "CartoonInfo.h"
@class FirstContentView;

@protocol FirstContentViewDelegate <NSObject>
-(void)FirstContentViewRank:(FirstContentView *)firstContentView data:(NSDictionary *)dicdata;
@end

@interface FirstContentView : UIView<CMPopTipViewDelegate,UIGestureRecognizerDelegate>{
    CGRect rect;
    float fx_Info; //主页面文本左gap
    float fy_Device;//设备信息View的Y
    float fPanOldY;
    
    NSDictionary *dicAllData;
    NSString *strSensorId;
    CartoonInfo *carToonInfo;
    
    HistoryView *historyView;
    NSInteger iCartoonClickIndex;
    UIPanGestureRecognizer *panGestureRecognizer;
    
    NSString *todayDate;
}
@property (nonatomic, strong)NSDictionary *dicFLineData;
@property (nonatomic, strong)NSArray *aryFAllDeviceid;
@property (nonatomic, strong)AirDevice *dicAirData;
@property (nonatomic, strong)GasDevice *dicGasData;
@property (nonatomic, strong)id<FirstContentViewDelegate>delegate;

-(void)initData:(NSDictionary *)data AirDevice:(AirDevice *)airinfo GasDevice:(GasDevice *)gasinfo;
-(id)initWithFrame:(CGRect)frame alldata:(NSDictionary *)data AirDevice:(AirDevice *)airinfo GasDevice:(GasDevice *)gasinfo;
-(void)LoadTopViewData:(CartoonInfo *)cartooninfo;
-(void)LoadTopView;
-(void)LoadAirInfoView;
-(void)LoadGasInfoView;
-(void)LoadAirInfoData;
-(void)LoadGasInfoData;
-(void)GetLineData;
-(void)hideRightArrow;
-(void)hideLeftArrow;
@property (nonatomic, strong)	id	currentPopTipViewTarget;
@property (nonatomic, strong)	NSMutableArray	*visiblePopTipViews;
//////////////////////////////////////////////////////////////////////
//上方数据展示所需变量
@property (strong, nonatomic)UILabel *labelUpdateTitle;
@property (strong, nonatomic)UILabel *labelStatusTitle;
@property (strong, nonatomic)UIButton *btnArrowTop;
@property (strong, nonatomic)UIButton *btnArrowLeft;
@property (strong, nonatomic)UIButton *btnArrowRight;

@property (strong, nonatomic)UIImageView *imageHomeBg;
@property (strong, nonatomic)UILabel *labelUpdateDate;
@property (strong, nonatomic)UILabel *labelValue;
@property (strong, nonatomic)UILabel *labelStatus;

@property (strong, nonatomic)UIButton *btnValueRank;
@property (strong, nonatomic)UIButton *btnHistory;
@property (strong, nonatomic)UIButton *btnShare;
@property (strong, nonatomic)UIButton *btnCortoon;
@property (strong, nonatomic)UIImageView *imageValueRankIcon;
@property (strong, nonatomic)UILabel *labelValueRank;
//////////////////////////////////////////////////////////////////////
//监测设备数据展示所需变量
@property (strong, nonatomic)UIView *viewDeviceDate;
@property (strong, nonatomic)UILabel *labelDeviceName;

@property (strong, nonatomic)UIImageView *imageTemp;
@property (strong, nonatomic)UILabel *labelTemp;
@property (strong, nonatomic)UIImageView *imageWet;
@property (strong, nonatomic)UILabel *labelWet;
@property (strong, nonatomic)UIImageView *imageCo2;
@property (strong, nonatomic)UILabel *labelCo2;
@property (strong, nonatomic)UIImageView *imagePm;
@property (strong, nonatomic)UILabel *labelPm;
@property (strong, nonatomic)UIImageView *imageVoc;
@property (strong, nonatomic)UILabel *labelVoc;

@property (strong, nonatomic)UIImageView *imageGas;
@property (strong, nonatomic)UILabel *labelGas;
@property (strong, nonatomic)UIImageView *imageCo;
@property (strong, nonatomic)UILabel *labelCo;

@property (strong, nonatomic)PCLineChartView *lineChartViewTempWet;
@property (strong, nonatomic)PCLineChartView *lineChartViewCo2;
@property (strong, nonatomic)PCLineChartView *lineChartViewPm;
@property (strong, nonatomic)PCLineChartView *lineChartViewGas;
@property (strong, nonatomic)PCLineChartView *lineChartViewCo;


@end