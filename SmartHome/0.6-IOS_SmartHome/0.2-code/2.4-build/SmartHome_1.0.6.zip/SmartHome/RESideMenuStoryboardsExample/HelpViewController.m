//
//  HelpViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-22.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "HelpViewController.h"

@interface HelpViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *helpWebview;

@end

@implementation HelpViewController
@synthesize mUrl = _mUrl;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *fullURL = [SERVER_BASE_URI stringByAppendingString:SH01_05_02_02];
    NSURL *url = [NSURL URLWithString:fullURL];
    if (_mUrl!=nil) {
        url = [NSURL URLWithString:_mUrl];
    }


    NSLog(@"UTL%@",fullURL);
//     NSURL *url=[NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    
    [self.helpWebview loadRequest:requestObj];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
