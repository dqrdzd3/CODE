//
//  LoginViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-21.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "LoginViewController.h"
#import "DEMORootViewController.h"
#import "DEMOAppDelegate.h"
#import "UIButton+Bootstrap.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import "RegisterViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameInput;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UITextField *userPasswordInput;

@property (weak, nonatomic) IBOutlet UIView *viewInput;
- (IBAction)loginBtnClick:(id)sender;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // _viewInput.layer.borderColor = [UIColor greenColor].CGColor;[rgb(91,192,222) CGColor]
    _viewInput.layer.borderColor = [UIColor colorWithRed:91.0/255 green:192.0/255 blue:222.0/255 alpha:1].CGColor;
    _viewInput.backgroundColor = [UIColor whiteColor];
    _viewInput.layer.cornerRadius = 10.0;
    _viewInput.layer.borderWidth = 1.0;
    
    // Do any additional setup after loading the view.
    _userPasswordInput.secureTextEntry = YES;
    _userNameInput.returnKeyType = UIReturnKeyDone;
    _userPasswordInput.returnKeyType = UIReturnKeyDone;
    [_userNameInput addTarget:self action:@selector(userNameInputEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_userPasswordInput addTarget:self action:@selector(userPasswordInputEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"loginBg"]];
    [_loginBtn infoStyle];
    self.userPasswordInput.delegate = self;
    
    [self.view bringSubviewToFront:_userPasswordInput];
    [self.view bringSubviewToFront:_userNameInput];
    
    [_savePsdBtn setImage:[UIImage imageNamed:@"cb_on"] forState:UIControlStateSelected];
    [_savePsdBtn setImage:[UIImage imageNamed:@"cb_off"] forState:UIControlStateNormal];
    [self initData];
}
-(void)viewDidAppear:(BOOL)animated{
    [self RegisterViewControllerFinish];
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"isRegisterSuccess"])
    {
        [self gotoRegister];
    }
}
-(void)userNameInputEditDone{
    [_userNameInput resignFirstResponder];
}
-(void)userPasswordInputEditDone{
    [_userPasswordInput resignFirstResponder];
}
-(void)initData{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    bool savePsd =[userDefaults boolForKey:@"isSavePassword"];
    
    [_savePsdBtn setSelected:savePsd];
    if (savePsd) {
        NSString *phoneStr = [userDefaults objectForKey:@"PHONE"];
        NSString *psdStr = [userDefaults objectForKey:@"PASSWORD"];
        [_userNameInput setText:phoneStr];
        [_userPasswordInput setText:psdStr];
    }
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.userPasswordInput resignFirstResponder];
    [self.userNameInput resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSString *)SystemInfo{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    NSArray *modelArray = @[
                            
                            @"i386", @"x86_64",
                            
                            @"iPhone1,1",
                            @"iPhone1,2",
                            @"iPhone2,1",
                            @"iPhone3,1",
                            @"iPhone3,2",
                            @"iPhone3,3",
                            @"iPhone4,1",
                            @"iPhone5,1",
                            @"iPhone5,2",
                            @"iPhone5,3",
                            @"iPhone5,4",
                            @"iPhone6,1",
                            @"iPhone6,2",
                            @"iPhone7,2",
                            @"iPhone7,3",
                            
                            @"iPod1,1",
                            @"iPod2,1",
                            @"iPod3,1",
                            @"iPod4,1",
                            @"iPod5,1",
                            
                            @"iPad1,1",
                            @"iPad2,1",
                            @"iPad2,2",
                            @"iPad2,3",
                            @"iPad2,4",
                            @"iPad3,1",
                            @"iPad3,2",
                            @"iPad3,3",
                            @"iPad3,4",
                            @"iPad3,5",
                            @"iPad3,6",
                            
                            @"iPad2,5",
                            @"iPad2,6",
                            @"iPad2,7",
                            ];
    NSArray *modelNameArray = @[
                                @"iPhone Simulator", @"iPhone Simulator",
                                
                                @"iPhone 2G",
                                @"iPhone 3G",
                                @"iPhone 3GS",
                                @"iPhone 4",
                                @"iPhone 4",
                                @"iPhone 4",
                                @"iPhone 4S",
                                @"iPhone 5",
                                @"iPhone 5",
                                @"iPhone 5c",
                                @"iPhone 5c",
                                @"iphone 5s",
                                @"iphone 5s",
                                @"iphone 6",
                                @"iphone 6 plus",
                                
                                @"iPod Touch 1G",
                                @"iPod Touch 2G",
                                @"iPod Touch 3G",
                                @"iPod Touch 4G",
                                @"iPod Touch 5G",
                                
                                @"iPad",
                                @"iPad 2",
                                @"iPad 2",
                                @"iPad 2",
                                @"iPad 2",
                                @"iPad 3",
                                @"iPad 3",
                                @"iPad 3",
                                @"iPad 4",
                                @"iPad 4",
                                @"iPad 4",
                                
                                @"iPad mini",
                                @"iPad mini",
                                @"ipad mini"
                                ];
    NSInteger modelIndex = - 1;
    NSString *modelNameString = nil;
    modelIndex = [modelArray indexOfObject:deviceString];
    if (modelIndex >= 0 && modelIndex < [modelNameArray count]) {
        modelNameString = [modelNameArray objectAtIndex:modelIndex];
    }
    NSLog(@"----设备类型---%@",modelNameString);
    return modelNameString;
}

-(void)UpdateLoginInfo{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:D005_DOSAVE];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary * parameter = [[NSMutableDictionary alloc]init];
    NSString *strModel = [self SystemInfo];
    
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    NSString *sysnameString = [NSString stringWithCString:systemInfo.sysname encoding:NSUTF8StringEncoding];
    NSString *nodenameString = [NSString stringWithCString:systemInfo.nodename encoding:NSUTF8StringEncoding];
    NSString *releaseString = [NSString stringWithCString:systemInfo.release encoding:NSUTF8StringEncoding];
    NSString *versionString = [NSString stringWithCString:systemInfo.version encoding:NSUTF8StringEncoding];
    NSString *strAllInfo = [NSString stringWithFormat:@"%@;%@;%@;%@;%@",deviceString,sysnameString,nodenameString,releaseString,versionString];
    
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *strDate = [dateFormatter stringFromDate:date];
    
    [parameter setObject:@"1" forKey:@"ma001"];
    [parameter setObject:@"ios" forKey:@"ma002"];
    [parameter setObject:[NSString stringWithFormat:@"%f",[[[UIDevice currentDevice] systemVersion] floatValue]] forKey:@"ma003"];
    [parameter setObject:@"com.hwsensor.smartHome" forKey:@"ma004"];
    [parameter setObject:@"Apple" forKey:@"ma006"];
    [parameter setObject:strModel forKey:@"ma007"];
    [parameter setObject:_userNameInput.text forKey:@"ma008"];
    [parameter setObject:strDate forKey:@"ma009"];
    [parameter setObject:strAllInfo forKey:@"ma010"];
    [parameter setObject:@"10" forKey:@"ma011"];
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        [SVProgressHUD dismiss];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
}
- (IBAction)loginBtnClick:(id)sender {
    NSString *name = _userNameInput.text;
    
    if (name.length == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请输入用户名" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    NSString *password = _userPasswordInput.text;
    if (password.length == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请输入密码" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        
        return;
    }
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_04];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

    NSMutableDictionary * parameter = [NSMutableDictionary dictionaryWithObjectsAndKeys:name,@"PHONE",password,@"PASSWORD", nil];
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"DEVICETOKEN"];
    if (deviceToken!=nil) {
        [parameter setObject:deviceToken forKey:@"IOSTOKEN"];
    }
  
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
         [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
            NSString *resultCode = [resultDic objectForKey:SERVER_RESULT_CODE_KEY];
        ServerResult *result = [[ServerResult alloc] initWithDictionary:resultDic error:nil];
        NSString *errorMsg = result.message;
        NSLog(@"Error: %@", errorMsg);
  
        if ([resultCode isEqualToString:SERVER_RESULT_CODE_SUCCESS]) {
            NSDictionary *userInfo = [resultDic objectForKey:@"dataObject"];
            NSLog(@"userInfo: %@", userInfo);
            NSString *userId = [userInfo objectForKey:@"ma001"];
            NSString *sessionId = [userInfo objectForKey:@"ma010"];
            NSString *email = [userInfo objectForKey:@"ma005"];
            NSString *userName = [userInfo objectForKey:@"ma008"];
            NSString *headUrl = [userInfo objectForKey:@"ma012"];
        //将上述数据全部存储到NSUserDefaults中
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        //存储时，除NSNumber类型使用对应的类型意外，其他的都是使用setObject:forKey:
        [userDefaults setObject:userId forKey:@"USERID"];
        [userDefaults setObject:sessionId forKey:@"SESSIONID"];
        [userDefaults setObject:email forKey:@"EMAIL"];
        [userDefaults setObject:userName
                         forKey:@"USERNAME"];
        [userDefaults setObject:name forKey:@"PHONE"];
        [userDefaults setObject:password forKey:@"PASSWORD"];
        [userDefaults setObject:headUrl forKey:@"HEADIMAGEURL"];
        [userDefaults setBool:YES forKey:@"isLoginSuccess"];
        [userDefaults synchronize]; 
        NSLog(@"userId:%@",userId);
            
        [self UpdateLoginInfo];
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        DEMORootViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"rootController"];
        ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
         [self presentViewController:ca animated:YES completion:NULL];
         [self removeFromParentViewController];
        }else{
           UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"用户名或密码错误" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        [SVProgressHUD dismiss];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        
        [SVProgressHUD dismiss];
    }];
    
    
}
- (IBAction)savePsdBtnClick:(id)sender {
    //将上述数据全部存储到NSUserDefaults中

    bool savePsd =[[NSUserDefaults standardUserDefaults] boolForKey:@"isSavePassword"] ;
    if (savePsd) {
        [_savePsdBtn setSelected:NO];
        [[NSUserDefaults standardUserDefaults] setBool:NO
                       forKey:@"isSavePassword"];
      
    }else{
        [_savePsdBtn setSelected:YES];
        [[NSUserDefaults standardUserDefaults] setBool:YES
                       forKey:@"isSavePassword"];
    }
}

-(void)gotoRegister{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    RegisterViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"registerViewController"];
    ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
    ca.delegate = self;
    [self presentViewController:ca animated:YES completion:NULL];
}

-(void)RegisterViewControllerFinish{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    bool savePsd =[userDefaults boolForKey:@"isSavePassword"];
    if (savePsd) {
        NSString *phoneStr = [[NSUserDefaults standardUserDefaults] objectForKey:@"PHONE"];
        NSString *psdStr = [[NSUserDefaults standardUserDefaults] objectForKey:@"PASSWORD"];
        [_userNameInput setText:phoneStr];
        [_userPasswordInput setText:psdStr];
    }
}
@end
