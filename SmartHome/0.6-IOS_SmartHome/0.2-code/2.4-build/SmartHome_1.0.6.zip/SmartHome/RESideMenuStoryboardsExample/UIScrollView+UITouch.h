//
//  UIScrollView+UITouch.h
//  SmartHome
//
//  Created by 李静 on 14-11-19.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (UITouch)

@end
