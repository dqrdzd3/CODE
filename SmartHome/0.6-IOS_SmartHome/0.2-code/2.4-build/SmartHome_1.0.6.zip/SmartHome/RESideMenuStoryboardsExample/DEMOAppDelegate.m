//
//  DEMOAppDelegate.m
//  RESideMenuStoryboardsExample
//
//  Created by Roman Efimov on 10/12/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOAppDelegate.h"
#import "GuideViewController.h"
#import "Guide2ViewController.h"
#import "LoginViewController.h"
#import "DEMORootViewController.h"
#import "WeiboSDK.h"
#import "WeiboApi.h"
#import "WXApi.h"
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/TencentOAuth.h>

BOOL        g_bBindDevice;
BOOL        g_bHaveCache;
NSString    *g_UserDirPath;
@implementation DEMOAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self confirmationWasHidden:nil];
    [self onCheckVersion];
    //分享sdk
    {
        [ShareSDK registerApp:@"30fb7c8144a0"];
        //添加新浪微博应用 注册网址 http://open.weibo.com
        //当使用新浪微博客户端分享的时候需要按照下面的方法来初始化新浪的平台
//        [ShareSDK connectSinaWeiboWithAppKey:@"3451634324"
//                                   appSecret:@"dc5c7cbd325b5c7cc0ecf598dc98f739"
//                                 redirectUri:@""
//                                 weiboSDKCls:[WeiboSDK class]];

        
//        [ShareSDK connectSinaWeiboWithAppKey:@"568898243"
//         appSecret:@"38a4f8204cc784f81f9f0daaf31e02e3"
//         redirectUri:@""
//         weiboSDKCls:[WeiboSDK class]];

        
        //添加腾讯微博应用 注册网址 http://dev.t.qq.com
        [ShareSDK connectTencentWeiboWithAppKey:@"801539135"
                                      appSecret:@"174beb630f39ce51bedf11a9998f8667"
                                    redirectUri:@"http://m.hanwei.cn"
                                       wbApiCls:[WeiboApi class]];
        
        //添加QQ空间应用  注册网址  http://connect.qq.com/intro/login/
        [ShareSDK connectQZoneWithAppKey:@"801539135"
                               appSecret:@"174beb630f39ce51bedf11a9998f8667"
                       qqApiInterfaceCls:[QQApiInterface class]
                         tencentOAuthCls:[TencentOAuth class]];
        
        
        //添加微信应用 注册网址 http://open.weixin.qq.com
        [ShareSDK connectWeChatWithAppId:@"wx55ada1de78e391c9"
                               wechatCls:[WXApi class]];
        [ShareSDK ssoEnabled:YES];

    }
    _mapManager = [[BMKMapManager alloc]init];
    // 如果要关注网络及授权验证事件，请设定    generalDelegate参数
    BOOL ret = [_mapManager start:@"RI36Dvkx20tD0Ooa3XXucVj1"  generalDelegate:nil];
    if (!ret) {
        NSLog(@"manager start failed!");
    }
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    self.window.backgroundColor = [UIColor whiteColor];
    //判断是不是第一次启动应用
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"firstLaunch"])
            {
                    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"firstLaunch"];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isSavePassword"];
                    NSLog(@"第一次启动");
//                    如果是第一次启动的话,使用UserGuideViewController (用户引导页面) 作为根视图
                     GuideViewController *userGuideViewController = [storyboard instantiateViewControllerWithIdentifier:@"guideViewController"];
            
                    self.window.rootViewController = userGuideViewController;
          
            
                }
        else
            {
                    NSLog(@"不是第一次启动");
                    //如果不是第一次启动的话,使用LoginViewController作为根视图
                if(![[NSUserDefaults standardUserDefaults] boolForKey:@"isLoginSuccess"]){
                                  LoginViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"loginViewController"];
              
                    self.window.rootViewController = ca;}
                else{
                    DEMORootViewController *root = [storyboard instantiateViewControllerWithIdentifier:@"rootController"];
                    
                    self.window.rootViewController = root;
                }
            
                               }
       [self.window makeKeyAndVisible];
  
    return YES;
}

//调用psh，请求获取动态令牌
- (void) confirmationWasHidden:(NSNotification *) notification
{
    // IOS8 新系统需要使用新的代码咯
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound  | UIUserNotificationTypeBadge)categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else
    {
        //这里还是原来的代码
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
         (UIUserNotificationTypeBadge | UIUserNotificationTypeSound)];
    }
}

//得到令牌
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    //得到令牌
    NSString *strToken = [[[[deviceToken description]
                            stringByReplacingOccurrencesOfString:@"<" withString:@""]
                           stringByReplacingOccurrencesOfString:@">" withString:@""]
                          stringByReplacingOccurrencesOfString:@" " withString:@""];
    [[NSUserDefaults standardUserDefaults] setObject:strToken
                                              forKey:@"DEVICETOKEN"];
    NSLog(@"strToken:%@",strToken);
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    //push错误
    NSLog(@"Error in registration. Error:\n %@", error);
}


//网络推送通知栏打开时会调用
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    //收到的push消息，userInfo：push里服务器传递的相关信息，这个信息是由公司服务器自己设定的。可以在这里处理一些逻辑
    NSLog(@"didReceiveRemoteNotification:%@",[userInfo description]);
}

//本地推送通知栏打开时会调用
-( void )application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    NSLog(@"didReceiveRemoteNotification:%@",[notification.userInfo objectForKey:@"key"]);
}



- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
-(void)onCheckVersion
{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    //CFShow((__bridge CFTypeRef)(infoDic));
    NSString *currentVersion = [infoDic objectForKey:@"CFBundleShortVersionString"];
    
    //NSString *URL = @"http://itunes.apple.com/lookup?id=com.hwsensor.smartHome"; 937313624

    NSString *URL = @"http://itunes.apple.com/lookup";
    NSMutableDictionary * parameter = [NSMutableDictionary dictionaryWithObjectsAndKeys:APP_ID,@"id", nil];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    
    [manager POST:URL parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSArray *infoArray = [dic objectForKey:@"results"];
        if ([infoArray count]) {
            NSDictionary *releaseInfo = [infoArray objectAtIndex:0];
            NSString *lastVersion = [releaseInfo objectForKey:@"version"];
            
            if (![lastVersion isEqualToString:currentVersion]) {
               trackViewURL = [releaseInfo objectForKey:@"trackViewUrl"];
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"更新" message:@"有新的版本更新，是否前往更新？" delegate:self cancelButtonTitle:@"关闭" otherButtonTitles:@"更新", nil];
                alert.tag = 10000;
                
                [alert show];
            }
                   }

        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        

    }];
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10000) {
        if (buttonIndex==1) {
            NSURL *url = [NSURL URLWithString:[trackViewURL stringByReplacingOccurrencesOfString:@"https" withString:@"itms-apps"]];
            [[UIApplication sharedApplication]openURL:url];
        }
    }
}

//- (BOOL)application:(UIApplication *)application
//      handleOpenURL:(NSURL *)url
//{
//    return [ShareSDK handleOpenURL:url
//                        wxDelegate:self];
//}
//
//- (BOOL)application:(UIApplication *)application
//            openURL:(NSURL *)url
//  sourceApplication:(NSString *)sourceApplication
//         annotation:(id)annotation
//{
//    return [ShareSDK handleOpenURL:url
//                 sourceApplication:sourceApplication
//                        annotation:annotation
//                        wxDelegate:self];
//}

@end
