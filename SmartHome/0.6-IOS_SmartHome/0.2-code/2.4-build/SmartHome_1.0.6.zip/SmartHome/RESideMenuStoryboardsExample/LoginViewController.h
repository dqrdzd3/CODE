//
//  LoginViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-21.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegisterViewController.h"
@interface LoginViewController : UIViewController
<UITextFieldDelegate,RegisterViewControllerDelegate>{
    
}
@property (weak, nonatomic) IBOutlet UIButton *savePsdBtn;
- (IBAction)savePsdBtnClick:(id)sender;

@end
