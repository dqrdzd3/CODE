//
//  HardwareViewController.h
//  SmartHome
//
//  Created by 李静 on 14-11-24.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EASYLINK.h"
#import "Reachability.h"
#import "../RTLabel.h"
#import "SVProgressHUD.h"

@interface HardwareViewController : UIViewController<UITextFieldDelegate, EasyLinkFTCDelegate>{
@private
    Reachability *wifiReachability;
    
    NSMutableDictionary *deviceIPConfig;
    EASYLINK *easylink_config;
        NSTimer *timer;
    NSTimer *configTimer;
    SVProgressHUD *HUD;
}


@property (weak, nonatomic) IBOutlet UILabel *wifiName;
@property (weak, nonatomic) IBOutlet UITextField *wifiPassword;
- (IBAction)bindBtnClick:(id)sender;

- (IBAction)lastBtnClick:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *lastBtn;
@property (weak, nonatomic) IBOutlet UIButton *bindBtn;

@property (weak, nonatomic) IBOutlet UIImageView *desImage;

@property (weak, nonatomic) IBOutlet RTLabel *configLabel;
@property (weak, nonatomic) IBOutlet UIButton *finishBtn;
- (IBAction)finishBtnClick:(id)sender;

 @property(nonatomic,copy)NSString *deviceId;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@end
