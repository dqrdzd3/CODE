//
//  AirDevice.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-1.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "AirDevice.h"
#import "DateUtils.h"
@implementation AirDevice
@synthesize createTime;
@synthesize c6h6;
@synthesize ch2o;
@synthesize co2;
@synthesize humidity;
@synthesize name;
@synthesize pm25;
@synthesize sensorId;
@synthesize temperature;
@synthesize voc;

-(BOOL)isOnline{
    long min =[DateUtils getMinitusFromNow:createTime];
    if (min>10) {
        return NO;
    }else{
        return YES;
    }
}
@end
