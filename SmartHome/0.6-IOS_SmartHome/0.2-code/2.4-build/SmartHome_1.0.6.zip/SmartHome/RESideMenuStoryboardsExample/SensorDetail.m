//
//  SensorDetail.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-28.
//  Copyright (c) 2014年 河南汉威电子股份有限公司. All rights reserved.
//

#import "SensorDetail.h"

@implementation SensorDetail
@synthesize sensorId;
@synthesize name;
@synthesize airDevice;
@synthesize gasDevice;
@synthesize online;
-(BOOL)isOnline{
    if ([self.name isEqualToString:@"空气质量"]) {
        return airDevice.isOnline;
    }else{
        return gasDevice.isOnline;
    }
}
-(CartoonInfo *)getCartoonInfo{
    CartoonInfo *info = [[CartoonInfo alloc] init];
    if (airDevice==nil&&gasDevice==nil) {
        [info.talkText addObject:EXPRESS_NO_DATA];
        [info.expressImages addObject:[UIImage imageNamed:@"0011"]];
        return info;
    }
    if (airDevice!=nil) {
        if (sensorId!=nil && sensorId.length>0) {
            if (airDevice.temperature.length == 0) {
                airDevice.temperature = @"0.0";
            }
            if (airDevice.temperature!=nil&&airDevice.temperature.length>0) {
                NSString *name = @"温度：";
                double value = [airDevice.temperature doubleValue];
                if (value<=(TEMPERATURE_THRESHOLD+3)&& value>=(TEMPERATURE_THRESHOLD-3)) {
                    NSString *talkText = [name stringByAppendingString:EXPRESS_TEMPERATURE_NORMAL];
                    [info.talkText addObject:talkText];
                    [info.expressImages addObject:[UIImage imageNamed:@"001"]];
                    
                    [info.CartoonState addObject:@"1"];
                }else if(value>=TEMPERATURE_THRESHOLD){

                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_TEMPERATURE_HOT]];
                    [info.expressImages addObject:[UIImage imageNamed:@"006"]];
                    [info.CartoonState addObject:@"2"];
                }else if(value < TEMPERATURE_THRESHOLD){
                    [info.CartoonState addObject:@"0"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_TEMPERATURE_COLD]];
                    [info.expressImages addObject:[UIImage imageNamed:@"004"]];
                }
            }
            
            //湿度
            if (airDevice.humidity.length == 0) {
                airDevice.humidity = @"0.0";
            }
            if(airDevice.humidity !=nil&&airDevice.humidity.length>0){
                NSString *name = @"湿度：";
                double value = [airDevice.humidity doubleValue];
                if (value<=(HUMIDITY_THRESHOLD+20)&& value>=(HUMIDITY_THRESHOLD-20)) {
                    NSString *talkText = [name stringByAppendingString:EXPRESS_HUMIDITY_NORMAL];
                    [info.talkText addObject:talkText];
                    [info.expressImages addObject:[UIImage imageNamed:@"001"]];
                    [info.CartoonState addObject:@"1"];
                }else if(value>=HUMIDITY_THRESHOLD){
                    [info.CartoonState addObject:@"2"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_HUMIDITY_OVER]];
                    [info.expressImages addObject:[UIImage imageNamed:@"0011"]];
                }else if(value < HUMIDITY_THRESHOLD){
                    [info.CartoonState addObject:@"0"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_HUMIDITY_LESS]];
                    [info.expressImages addObject:[UIImage imageNamed:@"0010"]];
                }
            }
            
            //co2
            if (airDevice.co2.length == 0) {
                airDevice.co2 = @"0.0";
            }
            if(airDevice.co2 !=nil&&airDevice.co2.length>0){
                NSString *name = @"二氧化碳：";
                double value = [airDevice.co2 doubleValue];
                if (value<=(CO2_THRESHOLD+10)&& value>=(CO2_THRESHOLD-10)) {
                    NSString *talkText = [name stringByAppendingString:EXPRESS_CO2_OVER];
                    [info.CartoonState addObject:@"1"];
                    [info.talkText addObject:talkText];
                    [info.expressImages addObject:[UIImage imageNamed:@"004"]];
                }else if(value>=CO2_THRESHOLD){
                    [info.CartoonState addObject:@"2"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_CO2_OVER_MORE]];
                    [info.expressImages addObject:[UIImage imageNamed:@"007"]];
                }else if(value < CO2_THRESHOLD){
                    [info.CartoonState addObject:@"0"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_CO2_NORMAL]];
                    [info.expressImages addObject:[UIImage imageNamed:@"004"]];
                }
            }
            
            //PM25
            if (airDevice.pm25.length == 0) {
                airDevice.pm25 = @"0.0";
            }
            if(airDevice.pm25 !=nil&&airDevice.pm25.length>0){
                NSString *name = @"PM2.5：";
                double value = [airDevice.pm25 doubleValue];
                if(value < PM25_THRESHOLD){
                    [info.CartoonState addObject:@"0"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_PM25_NORMAL]];
                    [info.expressImages addObject:[UIImage imageNamed:@"001"]];
                }else if (value<=PM25_HIGH_THRESHOLD&& value>PM25_THRESHOLD) {
                    [info.CartoonState addObject:@"1"];
                    NSString *talkText = [name stringByAppendingString:EXPRESS_PM25_OVER];
                    [info.talkText addObject:talkText];
                    [info.expressImages addObject:[UIImage imageNamed:@"004"]];
                }else if(value>PM25_HIGH_THRESHOLD){
                    [info.CartoonState addObject:@"2"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_PM25_OVER_MORE]];
                    [info.expressImages addObject:[UIImage imageNamed:@"0010"]];
                }
            }
            
            //VOC
            if (airDevice.voc.length == 0) {
                airDevice.voc = @"0.0";
            }
            if(airDevice.voc !=nil&&airDevice.voc.length>0){
                NSString *name = @"VOC：";
                double value = [airDevice.voc doubleValue];
                if(value < VOC_NORMAL){
                    [info.CartoonState addObject:@"1"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_VOC_NORMAL]];
                    [info.expressImages addObject:[UIImage imageNamed:@"001"]];
                }else if (value<=VOC_HIGH&& value>VOC_MIDDLE) {
                    [info.CartoonState addObject:@"2"];
                    NSString *talkText = [name stringByAppendingString:EXPRESS_VOC_MIDDLE];
                    [info.talkText addObject:talkText];
                    [info.expressImages addObject:[UIImage imageNamed:@"004"]];
                }else if(value>VOC_HIGH){
                    [info.CartoonState addObject:@"0"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_VOC_HIGH]];
                    [info.expressImages addObject:[UIImage imageNamed:@"0010"]];
                }
            }
            
        }
    }
    if (gasDevice!=nil) {
        if (sensorId!=nil && sensorId.length>0) {
            //ch4
            if (gasDevice.ch4.length == 0) {
                gasDevice.ch4 = @"0.0";
            }
            if (gasDevice.ch4 !=nil && gasDevice.ch4.length>0) {
                NSString *name = @"天然气：";
                double value = [gasDevice.ch4 doubleValue];
                
                if(value < CH4_THRESHOLD){
                    [info.CartoonState addObject:@"1"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_CH4_NORMAL]];
                    [info.expressImages addObject:[UIImage imageNamed:@"003"]];
                }
                else if(value>=CH4_THRESHOLD){
                    [info.CartoonState addObject:@"2"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_CH4_DANGEROUS]];
                    [info.expressImages addObject:[UIImage imageNamed:@"006"]];
                }
            }
            
            //co
            if (gasDevice.co.length == 0) {
                gasDevice.co = @"0.0";
            }
            if (gasDevice.co !=nil && gasDevice.co.length>0) {
                NSString *name = @"一氧化碳：";
                double value = [gasDevice.co doubleValue];
                
                if(value < CO_THRESHOLD){
                    [info.CartoonState addObject:@"1"];
                    [info.talkText addObject:[name stringByAppendingString:EXPRESS_CO_NORMAL]];
                    [info.expressImages addObject:[UIImage imageNamed:@"003"]];
                }
                else if(value>=CO_THRESHOLD){
                        [info.CartoonState addObject:@"2"];
                        [info.talkText addObject:[name stringByAppendingString:EXPRESS_CO_DANGEROUS]];
                        [info.expressImages addObject:[UIImage imageNamed:@"0011"]];
                    }
            }
        }
    }
     return info;
}


@end
