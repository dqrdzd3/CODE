//
//  DeviceDetailViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-1.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceDetailViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>
{
   

}
@property (weak, nonatomic) IBOutlet UIPickerView *deviceSlectPicker;
@property (strong, nonatomic) NSMutableArray *displayServices;
@end
