//
//  DisscussDetailViewController.m
//  SmartHome
//
//  Created by 李静 on 14-11-13.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "DisscussDetailViewController.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import "DisscussDetailModel.h"
#import "UIButton+Bootstrap.h"
#import "DisscussDetailTableViewCell.h"
#import "UIImageView+WebCache.h"
@interface DisscussDetailViewController ()

@end

@implementation DisscussDetailViewController
@synthesize disscussList;
@synthesize disscussTheme;
- (void)viewDidLoad {
    disscussList = [[NSMutableArray alloc]init];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-64);
    
    
    _mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-250)];
    _mTableView.delegate = self;
    _mTableView.dataSource = self;
    [_scrollView addSubview:_mTableView];
    
    _inputContentText = [[UITextView alloc]initWithFrame:CGRectMake(5, _mTableView.frame.origin.y+_mTableView.frame.size.height+5, [UIScreen mainScreen].bounds.size.width-10, 80)];
    _inputContentText.delegate = self;
    _inputContentText.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _inputContentText.layer.borderWidth = 0.5;
    _inputContentText.font = [UIFont systemFontOfSize:14.0];
    _inputContentText.textColor = [UIColor blackColor];
    _inputContentText.returnKeyType = UIReturnKeyDone;
    [_scrollView addSubview:_inputContentText];
    
    
    _leftWordsLable = [[UILabel alloc]initWithFrame:CGRectMake(0,  _inputContentText.frame.origin.y+_inputContentText.frame.size.height+5, _inputContentText.frame.size.width, 20)];
    _leftWordsLable.backgroundColor = [UIColor clearColor];
    _leftWordsLable.font = [UIFont systemFontOfSize:12.0];
    _leftWordsLable.textColor = [UIColor blackColor];
    _leftWordsLable.textAlignment = NSTextAlignmentRight;
    _leftWordsLable.text = [NSString stringWithFormat:@"还能输入128个字"];
    [_scrollView addSubview:_leftWordsLable];
    
    _postBtn = [[UIButton alloc]initWithFrame:CGRectMake(5, _leftWordsLable.frame.origin.y+_leftWordsLable.frame.size.height, _leftWordsLable.frame.size.width, 40)];
    _postBtn.layer.cornerRadius = 2.0;
    [_postBtn setTitle:@"提交" forState:UIControlStateNormal];
    _postBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
    [_postBtn setBackgroundColor:[UIColor colorWithRed:0.0 green:153/255.0 blue:204/255.0 alpha:1.0]];
    [_scrollView addSubview:_postBtn];
    [_postBtn addTarget:self action:@selector(postBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    //[UIScreen mainScreen].bounds.size.height-216-64-(_inputContentText.frame.size.height+_postBtn.frame.size.height)
    [self initData];
    [_postBtn infoStyle];
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
    [_scrollView setContentOffset:CGPointMake(0, [UIScreen mainScreen].bounds.size.height-_inputContentText.frame.origin.y-30) animated:YES];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [_inputContentText resignFirstResponder];
        [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        return NO;
    }
    if (![text isEqualToString:@""] && _inputContentText.text.length >= 128) {
        return NO;
    }

    return YES;
}
-(void)textViewDidChange:(UITextView *)textView{
    if (_inputContentText.text.length >= 128) {
        _inputContentText.text = [_inputContentText.text substringToIndex:128];
    }
    _leftWordsLable.text = [NSString stringWithFormat:@"还能输入%d个字",128-_inputContentText.text.length];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)postBtnClick:(id)sender {
    [self postQuestion];
}
#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.disscussList count];
    
    NSLog(@"COUNT,@%d",count);
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableCellIdentifier = @"disscussDetailTableViewCell";
    
    DisscussDetailTableViewCell *cell = (DisscussDetailTableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    
    if (cell == nil) {
        cell = [[DisscussDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableCellIdentifier];
    }
    
    NSDictionary *s = [self.disscussList objectAtIndex:indexPath.row];
    DisscussDetailModel *item= [[DisscussDetailModel alloc] initWithDictionary:s error:nil ];
    
    cell.nameLabel.text = item.ma008;
    cell.contentLable.text = item.ma003;
    cell.dateLabel.text = item.ma004;
    
    
    CGSize maximumSizeContent = CGSizeMake([UIScreen mainScreen].bounds.size.width-65, CGFLOAT_MAX);
    NSDictionary * tdicContent = [NSDictionary dictionaryWithObjectsAndKeys:cell.contentLable.font,NSFontAttributeName,nil];
    CGSize  actualsizeContent = [cell.contentLable.text boundingRectWithSize:maximumSizeContent options:NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading attributes:tdicContent context:nil].size;
    CGRect rectContent = cell.contentLable.frame;
    rectContent.origin.x = cell.nameLabel.frame.origin.x;
    rectContent.origin.y = cell.nameLabel.frame.origin.y+cell.nameLabel.frame.size.height;
    rectContent.size.width = [UIScreen mainScreen].bounds.size.width-65;
    rectContent.size.height = actualsizeContent.height+10;
    cell.contentLable.frame = rectContent;
    
    NSString *imageUrl = item.ma009;
    if (imageUrl!=nil && imageUrl.length) {
        NSString *streamUrl = [SERVER_BASE_URI stringByAppendingString:DOWNLOADSTREAM];
        NSString *indexUrl = [@"?ma001=" stringByAppendingString:imageUrl];
        NSString *wholeUrl = [streamUrl stringByAppendingString:indexUrl];
        NSLog(@"IMAGEURL-->%@",wholeUrl);
        [cell.headImageView setImageWithURL:[NSURL URLWithString:wholeUrl] placeholderImage:[UIImage imageNamed:@"userHeadImage"]];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    DisscussDetailTableViewCell *cell = [self tableView:_mTableView cellForRowAtIndexPath:indexPath];
//    return cell.frame.size.height;
    float fcellheight = 0.0;
    DisscussDetailTableViewCell *cell = (DisscussDetailTableViewCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    fcellheight = cell.contentLable.frame.origin.y+cell.contentLable.frame.size.height+10;
    return fcellheight;
}



- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Detail selected");
}

//设置选中Cell的响应事件

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//选中后的反显颜色即刻消失

}
//获取讨论区主题详情数据
-(void)initData{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_05_01_01_03];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    if(disscussTheme==nil){
        return;
    }
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"TITLEID":disscussTheme.ma001};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [SVProgressHUD show];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            if (disscussList.count != 0) {
                [disscussList removeAllObjects];
            }
            [disscussList addObjectsFromArray:result.dataObject];
            [_mTableView reloadData];
        }
        
        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
    
}

//提交讨论内容
-(void)postQuestion{
    NSString *content = [_inputContentText text];
    if (content.length == 0 || content.length > 128) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"内容不能为空或者超过128个字" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_05_01_01_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    if(disscussTheme == nil){
        return;
    }
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"TITLEID":disscussTheme.ma001,@"REPLYMSG":content};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    
    [SVProgressHUD show];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            [SVProgressHUD dismiss];
            [self initData];
            [_inputContentText setText:@""];
            _leftWordsLable.text = [NSString stringWithFormat:@"还能输入128个字"];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"提交成功" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            
        }else{
    
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"提交失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            [SVProgressHUD dismiss];
        }
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"提交失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];
}
- (IBAction)backBtnClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
