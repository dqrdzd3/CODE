//
//  DescriptionConfigViewController.h
//  SmartHome
//
//  Created by 李静 on 14-11-25.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "../RTLabel.h"
#import "HardwareViewController.h"


@interface DescriptionConfigViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *desImage;
@property (weak, nonatomic) IBOutlet RTLabel *configLabel;
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
@property (weak, nonatomic) IBOutlet UIButton *lastBtn;
@property (weak, nonatomic) IBOutlet UIImageView *powerImage;
@property (weak, nonatomic) IBOutlet RTLabel *powerHint;

- (IBAction)lastBtnClick:(id)sender;
- (IBAction)nextBtnClick:(id)sender;

 @property(nonatomic,copy)NSString *deviceId;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@end
