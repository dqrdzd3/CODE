//
//  DEMOAppDelegate.h
//  RESideMenuStoryboardsExample
//
//  Created by Roman Efimov on 10/12/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ShareSDK/ShareSDK.h>
#import "BMapKit.h"

#import "WXApi.h"
#import "WeiboApi.h"
#import <TencentOpenAPI/QQApi.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/TencentOAuth.h>

@interface DEMOAppDelegate : UIResponder <UIApplicationDelegate,WXApiDelegate>{
    BMKMapManager* _mapManager;
    NSString *trackViewURL;
    
    enum WXScene _scene;
    SSInterfaceOrientationMask _interfaceOrientationMask;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) SSInterfaceOrientationMask interfaceOrientationMask;
@end
