//
//  FeedBackController.m
//  SmartHome
//
//  Created by 李静 on 14-11-10.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "FeedBackController.h"
#import "FeedbackTableViewCell.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import "FeedbackModel.h"
#import "UIButton+Bootstrap.h"
@interface FeedBackController ()

@end

@implementation FeedBackController
@synthesize feedbackList;

-(void)viewWillDisappear:(BOOL)animated{
    [SVProgressHUD dismiss];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initView];
    [self initData];
}
-(void)initView{
    feedbackList = [[NSMutableArray alloc]init];
    // Do any additional setup after loading the view.
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.view addSubview:_scrollView];
    

    _feedbackTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-220)];
    _feedbackTableView.delegate = self;
    _feedbackTableView.dataSource = self;
    [_scrollView addSubview:_feedbackTableView];
    
    _feedbackContentText = [[UITextView alloc]initWithFrame:CGRectMake(5, _feedbackTableView.frame.origin.y+_feedbackTableView.frame.size.height+5, [UIScreen mainScreen].bounds.size.width-10, 80)];
    _feedbackContentText.delegate = self;
    _feedbackContentText.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _feedbackContentText.layer.borderWidth = 0.5;
    _feedbackContentText.font = [UIFont systemFontOfSize:14.0];
    _feedbackContentText.textColor = [UIColor blackColor];
    _feedbackContentText.returnKeyType = UIReturnKeyDone;
    [_scrollView addSubview:_feedbackContentText];
    
    
    _numLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,  _feedbackContentText.frame.origin.y+_feedbackContentText.frame.size.height+5, _feedbackContentText.frame.size.width, 20)];
    _numLabel.backgroundColor = [UIColor clearColor];
    _numLabel.font = [UIFont systemFontOfSize:12.0];
    _numLabel.textColor = [UIColor blackColor];
    _numLabel.textAlignment = NSTextAlignmentRight;
    _numLabel.text = [NSString stringWithFormat:@"还能输入128个字"];
    [_scrollView addSubview:_numLabel];
    
    _postBtn = [[UIButton alloc]initWithFrame:CGRectMake(5, _numLabel.frame.origin.y+_numLabel.frame.size.height, _numLabel.frame.size.width, 40)];
    _postBtn.layer.cornerRadius = 2.0;
    [_postBtn setTitle:@"提交" forState:UIControlStateNormal];
    _postBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
    [_postBtn setBackgroundColor:[UIColor colorWithRed:0.0 green:153/255.0 blue:204/255.0 alpha:1.0]];
    [_scrollView addSubview:_postBtn];
    [_postBtn addTarget:self action:@selector(postBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [_postBtn infoStyle];
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
    [_scrollView setContentOffset:CGPointMake(0, 180) animated:YES];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [_feedbackContentText resignFirstResponder];
        [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        return NO;
    }
    
    if (![text isEqualToString:@""] && textView.text.length >= 128) {
        return NO;
    }
    return YES;
}
-(void)textViewDidChange:(UITextView *)textView{
    if (_feedbackContentText.text.length >= 128) {
        _feedbackContentText.text = [_feedbackContentText.text substringToIndex:128];
    }
    _numLabel.text = [NSString stringWithFormat:@"还能输入%d个字",128-textView.text.length];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)postBtnClick:(id)sender {
    [self postQuestion];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.feedbackList count];
    
    NSLog(@"COUNT,@%d",count);
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableCellIdentifier = @"feedbackTableViewCell";
    FeedbackTableViewCell *cell = (FeedbackTableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    if (cell == nil) {
        cell = [[FeedbackTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableCellIdentifier];
    }
    if (self.feedbackList.count != 0) {
        NSDictionary *s = [self.feedbackList objectAtIndex:indexPath.row];
        FeedbackModel *feedback= [[FeedbackModel alloc] initWithDictionary:s error:nil ];
        
        CGSize maximumSizeContent = CGSizeMake([UIScreen mainScreen].bounds.size.width-10, CGFLOAT_MAX);
        NSDictionary * tdicContent = [NSDictionary dictionaryWithObjectsAndKeys:cell.questionLable.font,NSFontAttributeName,nil];
        CGSize  actualsizeContent = [[NSString stringWithFormat:@"反馈问题:%@",feedback.ma002] boundingRectWithSize:maximumSizeContent options:NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading attributes:tdicContent context:nil].size;
        CGRect rectContent = cell.questionLable.frame;
        rectContent.origin.x = 5;
        rectContent.origin.y = 5;
        rectContent.size.width = [UIScreen mainScreen].bounds.size.width-10;
        rectContent.size.height = actualsizeContent.height+10;
        cell.questionLable.frame = rectContent;
        cell.questionDateLabel.frame = CGRectMake(5, cell.questionLable.frame.origin.y+cell.questionLable.frame.size.height,[UIScreen mainScreen].bounds.size.width-10, 20);
        
        
        CGSize maximumSizeContent2 = CGSizeMake([UIScreen mainScreen].bounds.size.width-10, CGFLOAT_MAX);
        NSDictionary * tdicContent2 = [NSDictionary dictionaryWithObjectsAndKeys:cell.replyLable.font,NSFontAttributeName,nil];
        CGSize  actualsizeContent2 = [[NSString stringWithFormat:@"回复问题:%@",feedback.ma005] boundingRectWithSize:maximumSizeContent2 options:NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading attributes:tdicContent2 context:nil].size;
        CGRect rectContent2 = cell.replyLable.frame;
        rectContent2.origin.x = 5;
        rectContent2.size.width = [UIScreen mainScreen].bounds.size.width-10;
        rectContent2.origin.y = cell.questionDateLabel.frame.origin.y+cell.questionDateLabel.frame.size.height;
        rectContent2.size.height = actualsizeContent2.height+10;
        cell.replyLable.frame = rectContent2;
        cell.replyDateLable.frame = CGRectMake(5, cell.replyLable.frame.origin.y+cell.replyLable.frame.size.height,[UIScreen mainScreen].bounds.size.width-10, 20);
        
        
        cell.questionLable.text = [NSString stringWithFormat:@"反馈问题:%@",feedback.ma002];
        cell.questionDateLabel.text = feedback.ma003;
        cell.replyDateLable.text = feedback.ma007;
        cell.replyLable.text = [NSString stringWithFormat:@"回复问题:%@",feedback.ma005];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    float fcellheight = 0.0;
    FeedbackTableViewCell *cell = (FeedbackTableViewCell *)[self tableView:_feedbackTableView cellForRowAtIndexPath:indexPath];
    fcellheight = cell.replyDateLable.frame.origin.y+cell.replyDateLable.frame.size.height+10;
    return fcellheight;
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Detail selected");
}

//获取讨论区主题数据
-(void)initData{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_05_01_02_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [SVProgressHUD show];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            if (feedbackList.count != 0) {
                [feedbackList removeAllObjects];
            }
            [feedbackList addObjectsFromArray:result.dataObject];
            [_feedbackTableView reloadData];
        }
        
        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
    
}

//获取讨论区主题数据
-(void)postQuestion{
    
    NSString *question = [_feedbackContentText text];
    if (question.length == 0 || question.length > 128) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"内容不能为空或者超过128个字" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_05_01_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    
    if (question==nil) {
        return;
    }
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"MSG":question};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    [SVProgressHUD show];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        
        [SVProgressHUD dismiss];
        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            [self initData];
            [_feedbackContentText setText:@""];
            _numLabel.text = [NSString stringWithFormat:@"还能输入128个字"];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"提交成功" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }else{
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"提交失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
    
}

@end
