//
//  DEMOFirstViewController.m
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOFirstViewController.h"
#import "SensorDetail.h"
#import "DeviceDataConstant.h"
#import <QuartzCore/QuartzCore.h>

extern BOOL        g_bBindDevice;
extern BOOL        g_bHaveCache;
extern NSString    *g_UserDirPath;
#define PATH_OF_DOCUMENT    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

@interface DEMOFirstViewController ()
@property (nonatomic, strong)IBOutlet UIScrollView *scrollView;
@end

@implementation DEMOFirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (mdicContentViews.count != 0) {
        return;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    mdicContentViews = [[NSMutableDictionary alloc]init];
    rect = [UIScreen mainScreen].bounds;
    _scrollView.frame = CGRectMake(0, 64, rect.size.width, rect.size.height-64);
    _scrollView.contentSize = CGSizeMake(rect.size.width*3 , rect.size.height-64);
    [_scrollView setBounces:NO];
    _scrollView.pagingEnabled = YES;
    
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId != nil) {
        NSString * folerName = userId;
        if ([[NSFileManager defaultManager] fileExistsAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:folerName]]) {
            g_UserDirPath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:folerName];
        }
        else{
            [[NSFileManager defaultManager] createDirectoryAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:folerName] withIntermediateDirectories:YES attributes:nil error:nil];
            g_UserDirPath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:folerName];
        }
    }
    
    [self LoadDataCache];
}

-(void)LoadDataCache{
    if ([[NSFileManager defaultManager]fileExistsAtPath:[g_UserDirPath stringByAppendingPathComponent:@"CacheData"]]) {
        NSString *strdataCache = [NSString stringWithContentsOfFile:[g_UserDirPath stringByAppendingPathComponent:@"CacheData"] encoding:NSUTF8StringEncoding error:nil];
        NSData *resData = [[NSData alloc] initWithData:[strdataCache dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
        NSDictionary *arr = dataObject[0];
        NSArray *list = [arr objectForKey:@"sensorList"];
        _scrollView.contentSize = CGSizeMake(rect.size.width*list.count , rect.size.height-64);
        
        for (int i = 0; i < list.count; i++) {
            NSDictionary *dicTemp = [list objectAtIndex:i];
            NSDictionary *dicAir = [dicTemp objectForKey:@"air"];
            NSDictionary *dicGas = [dicTemp objectForKey:@"gas"];
            SensorDetail *sensorDetail = [[SensorDetail alloc]init];
            AirDevice *airDevice = [[AirDevice alloc]initWithDictionary:dicAir error:nil];
            sensorDetail.airDevice = airDevice;
            GasDevice *gasDevice = [[GasDevice alloc]initWithDictionary:dicGas error:nil];
            sensorDetail.gasDevice = gasDevice;
            
            sensorDetail.sensorId = [dicTemp objectForKey:@"sensorId"];
            sensorDetail.name = [dicTemp objectForKey:@"name"];
            sensorDetail.online = [dicTemp objectForKey:@"online"];
            
            CartoonInfo *cartoonInfo = [sensorDetail getCartoonInfo];
            if ([mdicContentViews objectForKey:[dicTemp objectForKey:@"sensorId"]] == nil) {
                FirstContentView *firstContent = [[FirstContentView alloc]initWithFrame:CGRectMake(rect.size.width*i, 0, rect.size.width, rect.size.height) alldata:dicTemp AirDevice:airDevice GasDevice:gasDevice];
                firstContent.delegate = self;
                [firstContent LoadTopView];
                [firstContent LoadTopViewData:cartoonInfo];
                if (airDevice != nil) {
                    [firstContent LoadAirInfoView];
                    [firstContent LoadAirInfoData];
                }
                if (gasDevice!=nil) {
                    [firstContent LoadGasInfoView];
                    [firstContent LoadGasInfoData];
                }
                
                [_scrollView addSubview:firstContent];
                [mdicContentViews setObject:firstContent forKey:[dicTemp objectForKey:@"sensorId"]];
                if (i == list.count-1) {
                    [firstContent hideRightArrow];
                }
                if (i == 0){
                    [firstContent hideLeftArrow];
                }
            }
            else{
                FirstContentView *firstContent = [mdicContentViews objectForKey:[dicTemp objectForKey:@"sensorId"]];
                
                [firstContent LoadTopViewData:cartoonInfo];
                if (airDevice != nil) {
                    [firstContent LoadAirInfoData];
                }
                else if (airDevice != nil){
                    [firstContent LoadGasInfoData];
                }
                if (i == list.count-1) {
                    [firstContent hideRightArrow];
                }
                if (i == 0){
                    [firstContent hideLeftArrow];
                }
            }
        }
        g_bHaveCache = YES;
    }
    else{
        g_bHaveCache = NO;
    }
    [timer invalidate];
    [self initData];
}
-(void)initData{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId == nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId == nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        
        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
        NSDictionary *arr = dataObject[0];
        NSArray *list = [arr objectForKey:@"sensorList"];
        if (list.count == 0 && !g_bHaveCache) {
            g_bBindDevice = NO;
            [[NSNotificationCenter defaultCenter]postNotificationName:@"NeedAddSensor" object:nil];
            [timer invalidate];
            return ;
        }
        else{
            if (list.count != 0) {
                [requestTmp writeToFile:[g_UserDirPath stringByAppendingPathComponent:@"CacheData"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
                g_bHaveCache = YES;
            }
            _scrollView.contentSize = CGSizeMake(rect.size.width*list.count , rect.size.height-64);
            
            for (int i = 0; i < list.count; i++) {
                NSDictionary *dicTemp = [list objectAtIndex:i];
                NSDictionary *dicAir = [dicTemp objectForKey:@"air"];
                NSDictionary *dicGas = [dicTemp objectForKey:@"gas"];
                SensorDetail *sensorDetail = [[SensorDetail alloc]init];
                AirDevice *airDevice = [[AirDevice alloc]initWithDictionary:dicAir error:nil];
                sensorDetail.airDevice = airDevice;
                GasDevice *gasDevice = [[GasDevice alloc]initWithDictionary:dicGas error:nil];
                sensorDetail.gasDevice = gasDevice;
                
                sensorDetail.sensorId = [dicTemp objectForKey:@"sensorId"];
                sensorDetail.name = [dicTemp objectForKey:@"name"];
                sensorDetail.online = [dicTemp objectForKey:@"online"];
                
                CartoonInfo *cartoonInfo = [sensorDetail getCartoonInfo];
                if ([mdicContentViews objectForKey:[dicTemp objectForKey:@"sensorId"]] == nil) {
                    FirstContentView *firstContent = [[FirstContentView alloc]initWithFrame:CGRectMake(rect.size.width*i, 0, rect.size.width, rect.size.height) alldata:dicTemp AirDevice:airDevice GasDevice:gasDevice];
                    firstContent.delegate = self;
                    [firstContent LoadTopView];
                    [firstContent LoadTopViewData:cartoonInfo];
                    if (airDevice != nil) {
                        [firstContent LoadAirInfoView];
                        [firstContent LoadAirInfoData];
                    }
                    if (gasDevice!=nil) {
                        [firstContent LoadGasInfoView];
                        [firstContent LoadGasInfoData];
                    }
                    
                    [_scrollView addSubview:firstContent];
                    [mdicContentViews setObject:firstContent forKey:[dicTemp objectForKey:@"sensorId"]];
                    if (i == list.count-1) {
                        [firstContent hideRightArrow];
                    }
                    if (i == 0){
                        [firstContent hideLeftArrow];
                    }
                }
                else{
                    FirstContentView *firstContent = [mdicContentViews objectForKey:[dicTemp objectForKey:@"sensorId"]];
                    
                    [firstContent initData:dicTemp AirDevice:airDevice GasDevice:gasDevice];
                    [firstContent LoadTopViewData:cartoonInfo];
                    if (airDevice != nil) {
                        [firstContent LoadAirInfoData];
                    }
                    else if (airDevice != nil){
                        [firstContent LoadGasInfoData];
                    }
                    if (i == list.count-1) {
                        [firstContent hideRightArrow];
                    }
                    if (i == 0){
                        [firstContent hideLeftArrow];
                    }
                }
            }
            timer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(TimeOver) userInfo:nil repeats:NO];
        }

    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"failureError: %@", error);
        [SVProgressHUD dismissWithError:@"网络连接失败" afterDelay:2];
        [timer invalidate];
    }];
}


#pragma mark======FirstContentViewDelegate
-(void)FirstContentViewRank:(FirstContentView *)firstContentView data:(NSDictionary *)dicdata{
    NSDictionary *dicAir = [dicdata objectForKey:@"air"];
    NSDictionary *dicGas = [dicdata objectForKey:@"gas"];
    SensorDetail *sensorDetail = [[SensorDetail alloc]init];
    NSString *strgastype = @"";
    NSString *strGasstate = @"";
    if (dicAir.count != 0) {
        AirDevice *airDevice = [[AirDevice alloc]initWithDictionary:dicAir error:nil];
        sensorDetail.airDevice = airDevice;
        sensorDetail.sensorId = [dicAir objectForKey:@"sensorId"];
        sensorDetail.name = [dicAir objectForKey:@"name"];
        sensorDetail.online = [dicAir objectForKey:@"online"];
        strgastype = @"[0,1,2,3,4]";
        CartoonInfo *cartoonInfo = [sensorDetail getCartoonInfo];
        strGasstate = [NSString stringWithFormat:@"[%@,%@,%@,%@,%@]",[cartoonInfo.CartoonState objectAtIndex:0],[cartoonInfo.CartoonState objectAtIndex:1],[cartoonInfo.CartoonState objectAtIndex:2],[cartoonInfo.CartoonState objectAtIndex:3],[cartoonInfo.CartoonState objectAtIndex:4]];
    }
    else if (dicGas.count != 0){
        GasDevice *gasDevice = [[GasDevice alloc]initWithDictionary:dicGas error:nil];
        sensorDetail.gasDevice = gasDevice;
        sensorDetail.sensorId = [dicGas objectForKey:@"sensorId"];
        sensorDetail.name = [dicGas objectForKey:@"name"];
        sensorDetail.online = [dicGas objectForKey:@"online"];
        strgastype = @"[9,8]";
        CartoonInfo *cartoonInfo = [sensorDetail getCartoonInfo];
        strGasstate = [NSString stringWithFormat:@"[%@,%@]",[cartoonInfo.CartoonState objectAtIndex:0],[cartoonInfo.CartoonState objectAtIndex:1]];
    }
    
    RankAdviceViewController *rankAdviceViewC = [[RankAdviceViewController alloc]init];
    rankAdviceViewC.strGastype = strgastype;
    rankAdviceViewC.strGasstate = strGasstate;
    [self.navigationController pushViewController:rankAdviceViewC animated:YES];
}
-(void)TimeOver{
   [self initData];
}
-(void)viewDidAppear:(BOOL)animated{

}
-(void)viewWillDisappear:(BOOL)animated{
    [SVProgressHUD dismiss];
    [timer invalidate];
}
-(void)viewDidDisappear:(BOOL)animated{

}
@end
