//
//  DisscussController.m
//  SmartHome
//
//  Created by 李静 on 14-11-10.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "DisscussController.h"
#import "DisscussTheme.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import "DisscussDetailViewController.h"
@implementation DisscussController
@synthesize disscussThemes;
- (void)viewDidLoad {
    [super viewDidLoad];
    _mTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-64)];
    // Do any additional setup after loading the view.
//    if ([UIScreen mainScreen].bounds.size.height > 480) {
//        _mTableView.frame = CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
//    }
//    else{
//        _mTableView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
//    }
    _mTableView.dataSource = self;
    _mTableView.delegate = self;
    [self.view addSubview:_mTableView];
    [self initData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.disscussThemes count];

    NSLog(@"COUNT,@%d",count);
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableCellIdentifier2 = @"DisscussTableCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier2];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableCellIdentifier2];
    }
    NSDictionary *s = [self.disscussThemes objectAtIndex:indexPath.row];
    DisscussTheme *theme1= [[DisscussTheme alloc] initWithDictionary:s error:nil ];
    cell.textLabel.text = theme1.ma002;

    return cell;
    
}




- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}



- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Detail selected");
}
//设置选中Cell的响应事件

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//选中后的反显颜色即刻消失
     NSLog(@"didSelectRowAtIndexPath");

    DisscussTheme *theme= [[DisscussTheme alloc] initWithDictionary:[self.disscussThemes objectAtIndex:indexPath.row] error:nil ];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DisscussDetailViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"disscussDetailViewController"];
    ca.disscussTheme = theme;
    ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
    [self presentViewController:ca animated:YES completion:NULL];
}

#
//获取讨论区主题数据
-(void)initData{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_05_01_01_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [SVProgressHUD show];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];

        ServerResult *result = [[ServerResult alloc] initWithString: requestTmp error:nil];
        if (result.isOperateSuccess) {
            disscussThemes = result.dataObject;
            
            [_mTableView reloadData];
        }

        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
    
}

@end
