//
//  ProtocolViewController.m
//  SmartHome
//
//  Created by 李静 on 14-11-7.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "ProtocolViewController.h"
#import "RegisterViewController.h"
@interface ProtocolViewController ()

@end

@implementation ProtocolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (_mUrl!=nil) {
      NSURL *url = [NSURL URLWithString:_mUrl];

      NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
        
     [_mWebView loadRequest:requestObj];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)backBtnClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
