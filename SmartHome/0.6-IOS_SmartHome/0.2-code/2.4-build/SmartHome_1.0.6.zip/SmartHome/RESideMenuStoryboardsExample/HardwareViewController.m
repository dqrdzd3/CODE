//
//  HardwareViewController.m
//  SmartHome
//  设备配网
//  Created by 李静 on 14-11-24.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "HardwareViewController.h"
#import "PhoneBindDeviceController.h"
#import "UIButton+Bootstrap.h"
#import "DeviceUtil.h"
#import "SensorDetail.h"
#import "SVProgressHUD.h"
#import "DEMORootViewController.h"
#import "DescriptionConfigViewController.h"
extern BOOL newModuleFound;
extern BOOL g_bBindDevice;
BOOL configSuccess;
int configTimeMin = 2;


@interface HardwareViewController ()
/*
 Notification method handler wifi 状态改变 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification*)notification;


/* enableUIAccess
 * enable / disable the UI access like enable / disable the textfields
 * and other component while transmitting the packets.
 * @param: vbool is to validate the controls.
 */
-(void) enableUIAccess:(BOOL) isEnable;
@property (nonatomic, retain, readwrite) NSThread* waitForAckThread;
@end

@implementation HardwareViewController
@synthesize waitForAckThread;
@synthesize deviceId;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(EndConfigWifi) name:@"EndConfigWifi" object:nil];
    [self initView];
}
-(void)viewDidDisappear:(BOOL)animated{
    [self stopAction];
    
    [configTimer invalidate];
    [timer invalidate];
    [SVProgressHUD dismiss];
}
- (void)initView{
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height+100);
    [_bindBtn infoStyle];
    [_lastBtn dangerStyle];
    [_finishBtn successStyle];
    [_finishBtn setHidden:YES];
    _wifiPassword.returnKeyType = UIReturnKeyDone;
    [_wifiPassword addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    
    [_wifiPassword addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [self initEasylink];
    [_wifiPassword setSecureTextEntry:YES];
    if (deviceId!=nil&&deviceId.length) {
        int deviceType = [DeviceUtil getDeviceType:self.deviceId];
        if (deviceType == SENSOR_TYPE_GAS) {
            [_desImage setImage:[UIImage imageNamed:@"ui_sensor_wifi_show_gas"]];
            [_configLabel setText:SENSOR_WIFI_GAS_HINT];
        }else if (deviceType == SENSOR_TYPE_AIR){
            [_desImage setImage:[UIImage imageNamed:@"ui_sensor_wifi_show_air"]];
            [_configLabel setText:SENSOR_WIFI_AIR_HINT];
        }
    }
    configSuccess = NO;
}

-(void)textViewEditBegin{
    [_scrollView setContentOffset:CGPointMake(0, 200) animated:YES];
}
-(void)textViewEditDone{
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [_wifiPassword resignFirstResponder];
    
}
-(void)initEasylink{
    if( easylink_config == nil){
        easylink_config = [[EASYLINK alloc]init];
        [easylink_config startFTCServerWithDelegate:self];
    }
    
    deviceIPConfig = [[NSMutableDictionary alloc] initWithCapacity:5];
    
    // wifi notification when changed.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wifiStatusChanged:) name:kReachabilityChangedNotification object:nil];
    
    wifiReachability = [Reachability reachabilityForLocalWiFi];  //监测Wi-Fi连接状态
    [wifiReachability startNotifier];
    
    waitForAckThread = nil;
    
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus == NotReachable ) {// No activity if no wifi
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"WiFi 不可用.请检查wifi是否连接" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alertView show];
    }else{
        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
        [_wifiName setText:[EASYLINK ssidForConnectedNetwork]];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)lastBtnClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)bindBtnClick:(id)sender {
    [_wifiPassword resignFirstResponder];
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [SVProgressHUD showWithStatus:@"配网中" maskType:SVProgressHUDMaskTypeBlack];
    
    [self timerStart];
    [self configTimerStart];
}

#pragma mark - Private Methods -

/* enableUIAccess
 * enable / disable the UI access like enable / disable the textfields
 * and other component while transmitting the packets.
 * @param: vbool is to validate the controls.
 */
-(void) enableUIAccess:(BOOL) isEnable{
    //             ssidField.userInteractionEnabled = isEnable;
    //             passwordField.userInteractionEnabled = isEnable;
    
    //             ipAddress.userInteractionEnabled = isEnable;
    
    //[halo startAnimation: !isEnable];
//    _wifiPassword.userInteractionEnabled = isEnable;
//    _bindBtn.userInteractionEnabled = isEnable;
}

/*
 Notification method handler when status of wifi changes
 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification*)notification{
    NSLog(@"%s", __func__);
    Reachability *verifyConnection = [notification object];
    NSAssert(verifyConnection != NULL, @"currentNetworkStatus called with NULL verifyConnection Object");
    NetworkStatus netStatus = [verifyConnection currentReachabilityStatus];
    if ( netStatus == NotReachable ){

    }else {
        [_wifiName setText:[EASYLINK ssidForConnectedNetwork]];
        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
    }
}
#pragma mark - TRASMITTING DATA -

/*
 This method begins configuration transmit
 In case of a failure the method throws an OSFailureException.
 */
-(void) sendAction{
    newModuleFound = NO;
    [easylink_config transmitSettings];
}

/*
 This method stop the sending of the configuration to the remote device
 In case of a failure the method throws an OSFailureException.
 */
-(void) stopAction{
    [easylink_config stopTransmitting];
    if (waitForAckThread !=nil) {
         [waitForAckThread cancel];
    }
   
    waitForAckThread= nil;
}

/*
 This method waits for an acknowledge from the remote device than it stops the transmit to the remote device and returns with data it got from the remote device.
 This method blocks until it gets respond.
 The method will return true if it got the ack from the remote device or false if it got aborted by a call to stopTransmitting.
 In case of a failure the method throws an OSFailureException.
 */

- (void) waitForAck: (id)sender{
    while(![[NSThread currentThread] isCancelled])
    {
//        if ( newModuleFound==YES ){
//            [self stopAction];
//            [self enableUIAccess:YES];
//            [self.navigationController popToRootViewControllerAnimated:YES];
//            break;
//        }
        sleep(1);
    };

}

/*
 This method start the transmitting the data to connected
 AP. Nerwork validation is also done here. All exceptions from
 library is handled.
 */
- (void)startTransmitting: (int)version {
    NSArray *wlanConfigArray;
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus == NotReachable ){// No activity if no wifi
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"WiFi 不可用.请检查wifi是否连接" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *ssid = [_wifiName.text length] ? _wifiName.text : nil;
    NSString *passwordKey = [_wifiPassword.text length] ? _wifiPassword.text : @"";
    
    NSNumber *dhcp = [NSNumber numberWithBool:[[deviceIPConfig objectForKey:@"DHCP"] boolValue]];
    NSString *ipString = [[deviceIPConfig objectForKey:@"IP"] length] ? [deviceIPConfig objectForKey:@"IP"] : @"";
    NSString *netmaskString = [[deviceIPConfig objectForKey:@"NetMask"] length] ? [deviceIPConfig objectForKey:@"NetMask"] : @"";
    NSString *gatewayString = [[deviceIPConfig objectForKey:@"GateWay"] length] ? [deviceIPConfig objectForKey:@"GateWay"] : @"";
    NSString *dnsString = [[deviceIPConfig objectForKey:@"DnsServer"] length] ? [deviceIPConfig objectForKey:@"DnsServer"] : @"";
    if([[deviceIPConfig objectForKey:@"DHCP"] boolValue] == YES) ipString = @"";
    
    wlanConfigArray = [NSArray arrayWithObjects: ssid, passwordKey, dhcp, ipString, netmaskString, gatewayString, dnsString, nil];
    
    [easylink_config prepareEasyLink_withFTC:wlanConfigArray info:nil version:version];
    [self sendAction];
    [self enableUIAccess:NO];
}

//触摸其他区域键盘消失
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.wifiPassword resignFirstResponder];
}

-(void)EndConfigWifi {
    NSLog(@"EndConfigWifi");
    [self stopAction];
    [configTimer invalidate];
    [timer invalidate];
    if(configSuccess){
        [SVProgressHUD showSuccessWithStatus:@"配网成功" duration:2];
        [_desImage setImage:[UIImage imageNamed:@"icon_peiwangsuc"]];
        [_configLabel setText:SENSOR_WIFI_GAS_SUCCESS_HINT];
        
        [_finishBtn setHidden:NO];
    }else{
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"配网失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
//        [SVProgressHUD showErrorWithStatus:@"配网失败" duration:2];
    }

}

-(void)TimeOver{
    [self checkDeviceData];
}

-(void)checkDeviceData{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
        NSDictionary *arr = dataObject[0];
        NSArray *list = [arr objectForKey:@"sensorList"];
        if (list.count == 0) {
            configSuccess = false;
            [self configTimeOver];
        }

        
        for (int i = 0; i < list.count; i++) {
            NSDictionary *dicTemp = [list objectAtIndex:i];

            NSString *sensorId = [dicTemp objectForKey:@"sensorId"];
            if ([self.deviceId isEqualToString:sensorId]){
                NSString *deviceName = [dicTemp objectForKey:@"sensorId"];
                if ([deviceName isEqualToString:@"空气质量"]) {
                    NSDictionary *airDic = [dicTemp objectForKey:@"air"];
                    AirDevice *air = [[AirDevice alloc] initWithDictionary:airDic error:nil];
                    
                    NSLog(@"air%@",air.name);
                    if (air.isOnline) {
                        configSuccess = true;
                        [self configTimeOver];
                    }
                    
                }else{
                    NSDictionary *gasDic = [dicTemp objectForKey:@"gas"];
                    GasDevice *gas = [[GasDevice alloc]initWithDictionary:gasDic error:nil];
                    if (gas.isOnline) {
                        configSuccess = true;
                        [self configTimeOver];
                    }
                }

            }
            
        }
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [configTimer invalidate];
        [timer invalidate];
        [SVProgressHUD dismissWithError:@"网络错误" afterDelay:2.0];
    }];
}

-(void)timerStart{
    timer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(TimeOver) userInfo:nil repeats:YES];
}
-(void) configTimeOver{
    NSLog(@"startConfig");
    [self EndConfigWifi];
    
}
-(void)configTimerStart{
    NSLog(@"configTimerStart");
    [self startTransmitting: EASYLINK_V2];
    configTimer = [NSTimer scheduledTimerWithTimeInterval:120.0 target:self selector:@selector(configTimeOver)  userInfo:nil repeats:NO];
}

-(void)configTimeStop{
    configSuccess = NO;
    [[NSNotificationCenter defaultCenter]postNotificationName:@"EndConfigWifi" object:nil];
    [configTimer invalidate];
}

- (IBAction)finishBtnClick:(id)sender {
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"isLoginSuccess"]){
        [[NSNotificationCenter defaultCenter]postNotificationName:@"NeedShowRoot" object:nil];
        
    }else{
        [[NSNotificationCenter defaultCenter]postNotificationName:@"NeedShowLogin" object:nil];
    }
    UIViewController * controller = self.presentingViewController;
    [self dismissViewControllerAnimated:NO completion:^{
        UIViewController * c = controller.presentingViewController;
        [c dismissViewControllerAnimated:NO completion:^{
                UIViewController * b = c.presentingViewController;
                [b dismissViewControllerAnimated:NO completion:nil];
        }];
    }];
    
}
@end
