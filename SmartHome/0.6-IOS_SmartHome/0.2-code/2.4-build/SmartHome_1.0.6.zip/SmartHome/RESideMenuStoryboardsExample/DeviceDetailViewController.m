//
//  DeviceDetailViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-1.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "DeviceDetailViewController.h"
#import "SensorDetail.h"
@interface DeviceDetailViewController ()

@end

@implementation DeviceDetailViewController
@synthesize displayServices;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Picker Delegate

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [displayServices count];
}
//确定每个轮子的每一项显示什么内容
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    SensorDetail *sensorDetail = [self.displayServices objectAtIndex:row];
    return [sensorDetail.name stringByAppendingString:sensorDetail.sensorId];

}
//监听轮子的移动
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)initData{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_01_03];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
        NSDictionary *arr = dataObject[0];
        NSArray *list = [arr objectForKey:@"sensorList"];
        NSMutableArray *items = [[NSMutableArray alloc]init];
        
        for(NSDictionary *member in list)
        {
            NSLog(@"%@",[member objectForKey:@"sensorId"]);
            SensorDetail *item = [[SensorDetail alloc] init];
            item.sensorId = [member objectForKey:@"sensorId"];
            item.name =[member objectForKey:@"name"];
            
            [items addObject:item];
            
        }
        self.displayServices = items;
        // [items release];
        [_deviceSlectPicker reloadAllComponents];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
    }];
    
}

@end
