//
//  GuideViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-20.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "GuideViewController.h"
#import "LoginViewController.h"
#import "UIButton+Bootstrap.h"
@interface GuideViewController ()
@property (weak, nonatomic) IBOutlet UIButton *gotoNextBtn;
- (IBAction)clickBtn:(id)sender;

@end

@implementation GuideViewController

@synthesize photoList = _photoList;
@synthesize pageScroll = _pageScroll;
@synthesize pageControl = _pageControl;

- (void)viewDidLoad {
    [super viewDidLoad];
    [_gotoNextBtn setHidden:YES];
    [_gotoNextBtn infoStyle];
    // Do any additional setup after loading the view.
//    NSString *img1 = [[NSBundle mainBundle] pathForResource:@"welcome1"
//                                                     ofType:@"png"];
//    NSString *img2 = [[NSBundle mainBundle] pathForResource:@"welcome2"
//                                                     ofType:@"png"];
//    NSString *img3 = [[NSBundle mainBundle] pathForResource:@"welcome3"
//                                                     ofType:@"png"];
//    
//    NSString *img4 = [[NSBundle mainBundle] pathForResource:@"welcome4"
//                                                     ofType:@"png"];
//    
//    
//    NSLog(@"123%p",img4);
    
    
//    _photoList = [[NSArray alloc] initWithObjects:
//                  [UIImage imageWithContentsOfFile:img1],
//                  [UIImage imageWithContentsOfFile:img2],
//                  [UIImage imageWithContentsOfFile:img3],
//                  [UIImage imageWithContentsOfFile:img4],
//                  [self getEmptyUIImage],nil];
        _photoList = [[NSArray alloc] initWithObjects:
                      [UIImage imageNamed:@"welcome1"],
                      [UIImage imageNamed:@"welcome2"],
                      [UIImage imageNamed:@"welcome3"],
                      [self getEmptyUIImage],nil];
    NSInteger pageCount = [_photoList count];
    _pageControl.currentPage = 0;
    _pageControl.numberOfPages = pageCount;
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGSize size = rect.size;
    CGFloat width = size.width;
    CGFloat height = size.height;
    _pageScroll.frame = CGRectMake(0.0,
                                   0.0,
                                   width,
                                   height);
    _pageScroll.delegate = self;
   
    for(NSInteger i=0;i<pageCount;i++)
    {
        CGRect frame;
        frame.origin.x = _pageScroll.frame.size.width * i;
        frame.origin.y = 0;
        frame.size = _pageScroll.frame.size;
        UIImageView *pageView = [[UIImageView alloc] initWithImage:[_photoList objectAtIndex:i]];
        pageView.contentMode = UIViewContentModeScaleAspectFill;
        pageView.frame = frame;
        [_pageScroll addSubview:pageView];
    }
}
-(void)viewDidLayoutSubviews
{
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGSize size = rect.size;
    CGFloat width = size.width;
    CGFloat height = size.height;
    CGSize pageScrollViewSize = _pageScroll.frame.size;
    NSLog(@"WIDTH--%f",width);
    _pageScroll.frame =CGRectMake(0,0,width, height);

    _pageScroll.contentSize = CGSizeMake(width * _photoList.count, height);
}
-(void) viewWillAppear:(BOOL)animated
{
    CGSize pageScrollViewSize = _pageScroll.frame.size;
    _pageScroll.contentSize = CGSizeMake(pageScrollViewSize.width * _photoList.count+300, pageScrollViewSize.height);
//    CGRect rect = [[UIScreen mainScreen] bounds];
//    CGSize size = rect.size;
//    CGFloat width = size.width;
//    CGFloat height = size.height;
//    _pageScroll.contentSize =CGSizeMake(width * 3, height);
    
//    [super viewDidAppear:animated];
//    [_pageScroll setContentSize:CGSizeMake(15000, 1800)];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
   

}
-(void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth = _pageScroll.frame.size.width;
    // 在滚动超过页面宽度的50%的时候，切换到新的页面
    int page = floor((_pageScroll.contentOffset.x + pageWidth/2)/pageWidth) ;
    _pageControl.currentPage = page;
    
    [_gotoNextBtn setHidden:page<2];
   // 这里可以判断是否跳转到主页
        if (page >= 3)
        {
            //点击登陆按钮后切换到storyboard界面
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            LoginViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"loginViewController"];
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:ca];
//            ca.modalPresentationStyle = UIModalPresentationFullScreen;
            // 全屏视图显示
            ca.modalTransitionStyle = UIModalPresentationFormSheet;
            // 从下向上滑出
            // modal
            [self presentViewController:nav animated:YES completion:NULL];
//             [self presentModalViewController:ca animated:YES];//在这里一跳就行了。
//            [self removeFromParentViewController];

            
        }
}

- (IBAction)PageValueChange:(id)sender
{
    // 更新Scroll View到正确的页面
    CGRect frame;
    frame.origin.x = _pageScroll.frame.size.width * _pageControl.currentPage;
    frame.origin.y = 0;
    frame.size = _pageScroll.frame.size;
    [_pageScroll scrollRectToVisible:frame animated:YES];
}

-(UIImage *)getEmptyUIImage
{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(_pageScroll.frame.size.width,
                                                      _pageScroll.frame.size.height), NO, 0.0);
    UIImage *blank = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return blank;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)clickBtn:(id)sender {
}
@end
