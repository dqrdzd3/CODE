//
//  RegisterViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-21.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "RegisterViewController.h"
#import "LoginViewController.h"
#import "UIButton+Bootstrap.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"
#import "ProtocolViewController.h"
#import "StringUtils.h"
#define PATH_OF_DOCUMENT    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
@implementation RegisterViewController
@synthesize delegate;
@synthesize scrollView;

//NSData* imageData = nil;
- (void)viewDidLoad {
    [super viewDidLoad];
    bLocationed = NO;
    scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [scrollView setBounces:YES];
//    _userNameInput.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _userNameInput.layer.cornerRadius = 2.0;
//    _userNameInput.layer.borderWidth = 0.5;
//    
//    _phoneInput.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _phoneInput.layer.cornerRadius = 2.0;
//    _phoneInput.layer.borderWidth = 0.5;
//    
//    _psdInput.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _psdInput.layer.cornerRadius = 2.0;
//    _psdInput.layer.borderWidth = 0.5;
//    
//    _psdConfirmInput.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _psdConfirmInput.layer.cornerRadius = 2.0;
//    _psdConfirmInput.layer.borderWidth = 0.5;
//    
//    _emailInput.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _emailInput.layer.cornerRadius = 2.0;
//    _emailInput.layer.borderWidth = 0.5;
    
    [_userNameInput addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_phoneInput addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_psdInput addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_psdConfirmInput addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    [_emailInput addTarget:self action:@selector(textViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
    
    
    [_userNameInput addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_phoneInput addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_psdInput addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_psdConfirmInput addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_emailInput addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    
    
    // Do any additional setup after loading the view.
    [_registerBtn infoStyle];
    [_psdInput setSecureTextEntry:YES];
    [_psdConfirmInput setSecureTextEntry:YES];
    
    _searcher =[[BMKGeoCodeSearch alloc]init];
    _searcher.delegate = self;
    
    _locService = [[BMKLocationService alloc]init];
    _locService.delegate = self;
    //启动LocationService
    [_locService startUserLocationService];
    
    if ([[NSFileManager defaultManager]fileExistsAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"]]) {
        [[NSFileManager defaultManager] removeItemAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"head.jpg"] error:nil];
    }
    if ([[NSFileManager defaultManager]fileExistsAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"]]) {
        [[NSFileManager defaultManager] removeItemAtPath:[PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"] error:nil];
    }
}



//接收反向地理编码结果
-(void) onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:
(BMKReverseGeoCodeResult *)result
errorCode:(BMKSearchErrorCode)error{
  if (error == BMK_SEARCH_NO_ERROR) {
      NSLog(@"结果:%@",result);
      strLoc = result.address;
      strProvice = result.addressDetail.province;
      strCity = result.addressDetail.city;
      strArea = result.addressDetail.district;
  }
  else {
      NSLog(@"抱歉，未找到结果");
  }
}

//实现相关delegate 处理位置信息更新
//处理位置坐标更新
- (void)didUpdateUserLocation:(BMKUserLocation *)userLocation
{
    if (userLocation != nil && !bLocationed) {
        bLocationed = YES;
        NSLog(@"didUpdateUserLocation lat %f,long %f",userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude);
        fLa = userLocation.location.coordinate.latitude;
        fLo = userLocation.location.coordinate.longitude;
        //发起反向地理编码检索
        CLLocationCoordinate2D pt = (CLLocationCoordinate2D){fLa, fLo};
        BMKReverseGeoCodeOption *reverseGeoCodeSearchOption = [[
        BMKReverseGeoCodeOption alloc]init];
        reverseGeoCodeSearchOption.reverseGeoPoint = pt;
        BOOL flag = [_searcher reverseGeoCode:reverseGeoCodeSearchOption];
        if(flag)
        {
          NSLog(@"反geo检索发送成功");
        }
        else
        {
          NSLog(@"反geo检索发送失败");
        }
    }
}
-(void)textViewEditBegin{
    [scrollView setContentOffset:CGPointMake(0, 80) animated:YES];
}

-(void)textViewEditDone{
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [_userNameInput resignFirstResponder];
    [_phoneInput resignFirstResponder];
    [_psdInput resignFirstResponder];
    [_psdConfirmInput resignFirstResponder];
    [_emailInput resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.phoneInput resignFirstResponder];
    [self.userNameInput resignFirstResponder];
    [self.emailInput resignFirstResponder];
    [self.psdInput resignFirstResponder];
    [self.psdConfirmInput resignFirstResponder];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)registerBtnClick:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.phoneInput resignFirstResponder];
    [self.userNameInput resignFirstResponder];
    [self.emailInput resignFirstResponder];
    [self.psdInput resignFirstResponder];
    [self.psdConfirmInput resignFirstResponder];
    
    NSString *name = _userNameInput.text;
    
    if ([name length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }

    NSString *password = _psdInput.text;
    if ([password length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    NSString *phone = _phoneInput.text;
    if ([phone length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    if (![StringUtils isValidateUserName:phone]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"用户名格式不对" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    NSString *psdConfirm = _psdConfirmInput.text;
    if ([psdConfirm length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    if (![password isEqualToString:psdConfirm]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"两次密码输入不一致信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    NSString *email = _emailInput.text;
    if (email.length) {
        if (![StringUtils isValidateEmail:email]) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"邮箱格式不正确" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            return;
        }
    }
    if(![_protocolBtn isOn]){
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"注册账户须同意空气电台协议" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary * parameter = [NSMutableDictionary dictionaryWithObjectsAndKeys:phone,@"PHONE",password,@"PASSWORD",name,@"USERNAME", nil];
    if (email.length != 0) {
        [parameter setObject:email forKey:@"EMAIL"];
    }
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"DEVICETOKEN"];
    if (deviceToken!=nil) {
        [parameter setObject:deviceToken forKey:@"IOSTOKEN"];
    }
    if (fLo != 0.0 && fLa != 0.0) {
        [parameter setObject:[NSString stringWithFormat:@"%f",fLo] forKey:@"LNG"];
        [parameter setObject:[NSString stringWithFormat:@"%f",fLa] forKey:@"LAT"];
    }
    if (strLoc.length != 0) {
        [parameter setObject:strLoc forKey:@"LOC"];
    }
    if (strProvice.length != 0) {
        [parameter setObject:strProvice forKey:@"PROVICE"];
    }
    if (strCity.length != 0) {
        [parameter setObject:strCity forKey:@"CITY"];
    }
    if (strArea.length != 0) {
        [parameter setObject:strArea forKey:@"AREA"];
    }
    NSString *strimagePath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NSURL *filePath = [NSURL fileURLWithPath:strimagePath];
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    
    [manager POST:url parameters:parameter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileURL:filePath name:@"file" error:nil];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"Success: %@", responseObject);
        [SVProgressHUD dismiss];
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSString *resultCode = [resultDic objectForKey:SERVER_RESULT_CODE_KEY];
        
        ServerResult *result = [[ServerResult alloc] initWithDictionary:resultDic error:nil];
        if (result.isOperateSuccess) {
            //将上述数据全部存储到NSUserDefaults中
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isRegisterSuccess"];
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            //存储时，除NSNumber类型使用对应的类型意外，其他的都是使用setObject:forKey:
            [userDefaults setObject:name forKey:@"USERNAME"];
            [userDefaults setObject:phone forKey:@"PHONE"];
            [userDefaults setObject:email forKey:@"EMAIL"];
            [userDefaults setObject:password forKey:@"PASSWORD"];
            [userDefaults synchronize];
            [delegate RegisterViewControllerFinish];
            [SVProgressHUD dismissWithSuccess:@"注册成功" afterDelay:2.0];
            [self dismissViewControllerAnimated:YES completion:nil];
        }else{
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:result.message delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"网络连接失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];
}

- (IBAction)userHeadClick:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"选择一张图片作为头像" delegate:self  cancelButtonTitle:@"取消" destructiveButtonTitle:@"立即拍照上传" otherButtonTitles:@"从手机相册选取",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleAutomatic;
    [actionSheet showInView:self.view];
}
//图片照相
- (void)toCameraPickingController
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        NSLog(@"Error:没有照相设备");
    }
    else {
        UIImagePickerController *cameraPicker = [[UIImagePickerController alloc] init];
        cameraPicker.delegate = self;
        cameraPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        cameraPicker.allowsEditing = YES;
        [self presentViewController:cameraPicker animated:YES completion:nil];
    }
}
//图片
- (void)toPhotoPickingController
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        NSLog(@"Error:无图片库");
    }
    else {
        UIImagePickerController *photoPicker = [[UIImagePickerController alloc] init];
        photoPicker.delegate = self;
        photoPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        photoPicker.allowsEditing = YES;
        [self presentViewController:photoPicker animated:YES completion:nil];
    }
}

#pragma mark UIActionSheet协议
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex ==0)
    {
        [self toCameraPickingController];
        
    }
    if (buttonIndex ==1) {
        [self toPhotoPickingController];
        
    }
    else return;
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *imagePicked = [info objectForKey:UIImagePickerControllerEditedImage];
    NSData* imageData = UIImageJPEGRepresentation(imagePicked, 0);
    
    NSString *strimagepath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:@"temp.jpg"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:strimagepath]) {
        [[NSFileManager defaultManager] removeItemAtPath:strimagepath error:nil];
    }
    BOOL bwritetofile = [imageData writeToFile:strimagepath atomically:NO];
    if (!bwritetofile) {
        NSLog(@"保存图片失败");
    }
    [_userHeadImage setImage:imagePicked];
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    return;
}
//-(NSString *)saveUserHead{
//    NSString *path=pathInDocumentDirectory([NSString stringWithFormat:@"IMAGE-%u",[[[NSDate date]description]hash]]);
//   
//    NSData *imageData=UIImageJPEGRepresentation(_userHeadImage, 0.5);
//    [imageData writeToFile:path atomically:YES];
//    
//    [[NSUserDefaults standardUserDefaults] setObject:path forKey:@"myUserHead"];
//    return path;
//}
- (IBAction)backBtnClick:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isRegisterSuccess"];
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)viewDidDisappear:(BOOL)animated{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isRegisterSuccess"];
}
- (IBAction)protocolBtnClick:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ProtocolViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"protocolViewController"];
    //http://iweiguo.hwsensor.com/smart/protocol.html
    ca.mUrl = [BASE_URI stringByAppendingString:@"protocol.html"];
    ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
    [self presentViewController:ca animated:YES completion:NULL];

}



@end
