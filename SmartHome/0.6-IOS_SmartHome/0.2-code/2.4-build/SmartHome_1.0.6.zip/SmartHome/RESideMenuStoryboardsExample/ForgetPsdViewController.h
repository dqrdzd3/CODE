//
//  ForgetPsdViewController.h
//  SmartHome
//
//  Created by 李静 on 14-11-10.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgetPsdViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberText;
@property (weak, nonatomic) IBOutlet UIButton *getVerifyCodeBtn;
@property (weak, nonatomic) IBOutlet UITextField *verifyCodeText;
@property (weak, nonatomic) IBOutlet UITextField *nPasswordText;
@property (weak, nonatomic) IBOutlet UITextField *repeatPasswordText;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeBtnClick;
@property (weak, nonatomic) IBOutlet UIButton *postBtnClick;
- (IBAction)getVerifyBtnClick:(id)sender;
- (IBAction)postBtnClick:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *getVerifyBtn;
@property (weak, nonatomic) IBOutlet UIButton *postBtn;
- (IBAction)backBtnClick:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *countDownLabel;



@end
