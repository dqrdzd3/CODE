//
//  Guide2ViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-3.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "Guide2ViewController.h"
#import "EAIntroPage.h"
#import "SMPageControl.h"
#import <QuartzCore/QuartzCore.h>
#import "LoginViewController.h"
@interface Guide2ViewController (){
    UIView *rootView;
}
@end

@implementation Guide2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
       LoginViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"loginViewController"];
    rootView = ca.view;
    [self showIntroWithCrossDissolve];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)showCustomIntro {
    EAIntroPage *page1 = [EAIntroPage page];
  
 
    page1.bgImage = [UIImage imageNamed:@"welcome1"];
    page1.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"title1"]];
    page1.titleIconPositionY = 100;
    page1.showTitleView = NO;
    
    EAIntroPage *page2 = [EAIntroPage page];
    page2.title = @"This is page 2";
    page2.titlePositionY = 240;

    page2.descPositionY = 220;
    page2.bgImage = [UIImage imageNamed:@"welcome2"];
    page2.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon1"]];
    page2.titleIconPositionY = 260;
    
    EAIntroPage *page3 = [EAIntroPage page];
    page3.title = @"This is page 3";
    page3.titlePositionY = 240;
    page3.descPositionY = 220;
    page3.bgImage = [UIImage imageNamed:@"welcome3"];
    page3.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"icon2"]];
    page3.titleIconPositionY = 260;
    

    
    EAIntroView *intro = [[EAIntroView alloc] initWithFrame:rootView.bounds andPages:@[page1,page2,page3]];
    intro.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bigLogo"]];
    intro.titleViewY = 120;
    intro.tapToNext = YES;
    [intro setDelegate:self];
    
    SMPageControl *pageControl = [[SMPageControl alloc] init];
    pageControl.pageIndicatorImage = [UIImage imageNamed:@"pageDot"];
    pageControl.currentPageIndicatorImage = [UIImage imageNamed:@"selectedPageDot"];
    [pageControl sizeToFit];
    intro.pageControl = (UIPageControl *)pageControl;
    intro.pageControlY = 130.0f;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"skipButton"] forState:UIControlStateNormal];
    [btn setFrame:CGRectMake((320-270)/2, [UIScreen mainScreen].bounds.size.height - 80, 270, 50)];
    intro.skipButton = btn;
    
    [intro showInView:rootView animateDuration:0.3];
}
- (void)introDidFinish:(EAIntroView *)introView {
    NSLog(@"introDidFinish callback");
    
}

- (void)showIntroWithCrossDissolve {
    EAIntroPage *page1 = [EAIntroPage page];
    page1.title = @"Hello world";
    page1.desc = @"";
    page1.bgImage = [UIImage imageNamed:@"welcome1"];
    page1.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"welcome1"]];
    
    EAIntroPage *page2 = [EAIntroPage page];
    page2.title = @"This is page 2";
    page2.desc = @"";
    page2.bgImage = [UIImage imageNamed:@"welcome2"];
    page2.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"welcome2"]];
    
    EAIntroPage *page3 = [EAIntroPage page];
    page3.title = @"This is page 3";
    page3.desc = @"";
    page3.bgImage = [UIImage imageNamed:@"welcome3"];
    page3.titleIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"welcome3"]];
    
   
    
    EAIntroView *intro = [[EAIntroView alloc] initWithFrame:rootView.bounds andPages:@[page1,page2,page3]];
    [intro setDelegate:self];
    
    [intro showInView:rootView animateDuration:0.3];
}
@end
