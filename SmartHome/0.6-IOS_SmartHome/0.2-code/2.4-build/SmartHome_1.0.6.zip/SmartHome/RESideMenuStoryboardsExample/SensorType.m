//
//  SensorType.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-4.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "SensorType.h"

@implementation SensorType
const int SENSOR_TYPE_ERROR = 0;
const int SENSOR_TYPE_GAS = 1;
const int SENSOR_TYPE_AIR = 2;
const int SENSOR_TYPE_SMOKE = 3;
@end
