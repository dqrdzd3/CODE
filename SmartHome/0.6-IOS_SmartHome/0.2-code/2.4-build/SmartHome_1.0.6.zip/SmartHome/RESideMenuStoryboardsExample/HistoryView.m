//
//  HistoryView.m
//  SmartHome
//
//  Created by apple on 14-11-14.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "HistoryView.h"
@implementation HistoryView

-(id)initWithFrame:(CGRect)frame deviceid:(NSString *)deviceid{
    self = [super initWithFrame:frame];
    if (self) {
        // Do any additional setup after loading the view
        rect = frame;
        strDeviceid = deviceid;
        maryData = [[NSMutableArray alloc]init];
        iPageIndex = 1;
        iPageSize = 10;
        [self LoadView];
    }
    return self;
}

-(void)LoadView{
    UILabel *labelLeft = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, rect.size.width/2-5, 44)];
    labelLeft.backgroundColor = [UIColor clearColor];
    labelLeft.font = [UIFont systemFontOfSize:14.0];
    labelLeft.textAlignment = NSTextAlignmentRight;
    labelLeft.textColor = [UIColor colorWithRed:153/255.0 green:204/255.0 blue:51/255.0 alpha:1.0];
    labelLeft.text = @"报警时间";
    [self addSubview:labelLeft];
    
    UIImageView *imageLine = [[UIImageView alloc]initWithFrame:CGRectMake(rect.size.width/2-3, 8, 6, 28)];
    imageLine.image = [UIImage imageNamed:@"list_ho_diver"];
    [self addSubview:imageLine];
    
    UILabel *labelRight = [[UILabel alloc]initWithFrame:CGRectMake(rect.size.width/2+5, 0, rect.size.width/2-5, 44)];
    labelRight.backgroundColor = [UIColor clearColor];
    labelRight.font = [UIFont systemFontOfSize:14.0];
    labelRight.textAlignment = NSTextAlignmentLeft;
    labelRight.textColor = [UIColor colorWithRed:153/255.0 green:204/255.0 blue:51/255.0 alpha:1.0];
    labelRight.text = @"状态报警值";
    [self addSubview:labelRight];
    
    labelInfo = [[UILabel alloc]initWithFrame:CGRectMake(0, 44, rect.size.width, 20)];
    labelInfo.backgroundColor = [UIColor clearColor];
    labelInfo.font = [UIFont systemFontOfSize:14.0];
    labelInfo.textAlignment = NSTextAlignmentCenter;
    labelInfo.textColor = [UIColor grayColor];
    
    
    HistoryTableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 44, rect.size.width, rect.size.height-44)];
    HistoryTableview.dataSource = self;
    HistoryTableview.delegate = self;
    HistoryTableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:HistoryTableview];
    HistoryTableview.tableFooterView = labelInfo;
    
    header = [MJRefreshHeaderView header];
    header.scrollView = HistoryTableview;
    header.delegate = self;
    
    footer = [MJRefreshFooterView footer];
    footer.scrollView = HistoryTableview;
    footer.delegate = self;
    [self refreshViewBeginRefreshing:header];
}

-(void)initData{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_01_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    
    NSString *pageIndex = [NSString stringWithFormat:@"%d",iPageIndex];
    NSString *pageSize = [NSString stringWithFormat:@"%d",iPageSize];
    
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"DRIVERID":strDeviceid,@"PAGENO":pageIndex,@"PAGESIZE":pageSize};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        // 2.2秒后刷新表格UI
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        if ([resultDic objectForKey:@"dataObject"] == [NSNull null]) {
            labelInfo.hidden = NO;
            labelInfo.text = [resultDic objectForKey:@"message"];
        }
        else{
            labelInfo.text = @"";
            labelInfo.hidden = YES;
            if (bLoading) {
                [maryData addObjectsFromArray:[resultDic objectForKey:@"dataObject"]];
                [self doneWithView:footer];
                
            }
            if (bUpdateLoading) {
                if (maryData.count != 0) {
                    [maryData removeAllObjects];
                }
                [maryData addObjectsFromArray:[resultDic objectForKey:@"dataObject"]];
                [self doneWithView:header];
            }
        }
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [self doneWithView:footer];
        [self doneWithView:header];
        labelInfo.hidden = NO;
        labelInfo.text = @"网络链接失败";
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return maryData.count;
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}
-(HistoryTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *identifier = [NSString stringWithFormat:@"Cell_%d",indexPath.row];
    HistoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[HistoryTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                               reuseIdentifier:identifier cellWidth:rect.size.width];
    }
    if (maryData.count != 0) {
        NSDictionary *dictemp = [maryData objectAtIndex:indexPath.row];
        
        NSString *strDate = [dictemp objectForKey:@"ma005"];
        NSArray *aryDate = [strDate componentsSeparatedByString:@" "];
        
        cell.labelInfo.text = [NSString stringWithFormat:@"%@\n%@\n%@",[dictemp objectForKey:@"ma004"],[aryDate objectAtIndex:0],[aryDate objectAtIndex:1]];
        cell.labelStateValue.text = [NSString stringWithFormat:@"%@         %@",[dictemp objectForKey:@"ma003"],[dictemp objectForKey:@"ma002"]];
    }

    return cell;
}

#pragma mark - 刷新控件的代理方法
#pragma mark 开始进入刷新状态
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
NSLog(@"%@----开始进入刷新状态", refreshView.class);
    
    if (refreshView.class == [MJRefreshFooterView class]) {
        iPageIndex++;
        bLoading = YES;
        bUpdateLoading = NO;
    }
    else{
        iPageIndex = 1;
        bUpdateLoading = YES;
        bLoading = NO;
    }
    [self initData];
    
}

#pragma mark 刷新完毕
- (void)refreshViewEndRefreshing:(MJRefreshBaseView *)refreshView
{
    NSLog(@"%@----刷新完毕", refreshView.class);
    
}

#pragma mark 监听刷新状态的改变
- (void)refreshView:(MJRefreshBaseView *)refreshView stateChange:(MJRefreshState)state
{
    switch (state) {
        case MJRefreshStateNormal:
            NSLog(@"%@----切换到：普通状态", refreshView.class);
            break;
            
        case MJRefreshStatePulling:
            NSLog(@"%@----切换到：松开即可刷新的状态", refreshView.class);
            break;
        case MJRefreshStateRefreshing:
            NSLog(@"%@----切换到：正在刷新状态", refreshView.class);
            break;
        default:
            break;
    }
}

#pragma mark 刷新表格并且结束正在刷新状态
- (void)doneWithView:(MJRefreshBaseView *)refreshView
{
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
    bUpdateLoading = NO;
    bLoading = NO;
    [refreshView endRefreshing];
    [HistoryTableview reloadData];
}


@end
