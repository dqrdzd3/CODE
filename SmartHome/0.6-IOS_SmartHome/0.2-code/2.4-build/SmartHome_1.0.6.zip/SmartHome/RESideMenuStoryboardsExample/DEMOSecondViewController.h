//
//  DEMOSecondViewController.h
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"
#import "ZBarSDK.h"
#import "Reachability.h"
#import "EASYLINK.h"
#import "DeviceTableViewCell.h"
@interface DEMOSecondViewController : UIViewController<ZBarReaderDelegate,UIAlertViewDelegate,UITextFieldDelegate, EasyLinkFTCDelegate,UITableViewDataSource,UITableViewDelegate>{
@private
    Reachability *wifiReachability;
    
    NSMutableDictionary *deviceIPConfig;
    EASYLINK *easylink_config;
}

@property (weak, nonatomic) IBOutlet UIButton *deviceRegisterBtn;
- (IBAction)deviceRegisterClick:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *scanBtn;
- (IBAction)c:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *deviceId;
@property (weak, nonatomic) IBOutlet UILabel *wifiName;
@property (weak, nonatomic) IBOutlet UITextField *wifiPassword;
/*
 This method waits for an acknowledge from the remote device than it stops the transmit to the remote device and returns with data it got from the remote device.
 This method blocks until it gets respond.
 The method will return true if it got the ack from the remote device or false if it got aborted by a call to stopTransmitting.
 In case of a failure the method throws an OSFailureException.
 */
- (void) waitForAck: (id)sender;
/*
 This method start the transmitting the data to connected
 AP. Nerwork validation is also done here. All exceptions from
 library is handled.
 */
- (void)startTransmitting: (int)version;
@property (weak, nonatomic) IBOutlet UITableView *devicesTableView;
@property (strong, nonatomic) NSMutableArray *displayServices;

@end
