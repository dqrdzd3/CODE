//
//  DisscussDetailTableViewCell.h
//  SmartHome
//
//  Created by 李静 on 14-11-13.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisscussDetailTableViewCell : UITableViewCell
@property (strong, nonatomic) UIImageView *headImageView;
@property (strong, nonatomic) UILabel *nameLabel;
@property (strong, nonatomic) UILabel *contentLable;
@property (strong, nonatomic) UILabel *dateLabel;

@end
