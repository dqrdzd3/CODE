//
//  DEMOSecondViewController.m
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOSecondViewController.h"

#import "UIButton+Bootstrap.h"
#import "ZBarSDK.h"
#import "SVProgressHUD.h"
#import "SensorType.h"
#import "DeviceTableViewCell.h"
#import "SensorDetail.h"
extern BOOL newModuleFound;
extern BOOL g_bBindDevice;
extern BOOL g_bHaveCache;
extern NSString *g_UserDirPath;
@interface DEMOSecondViewController ()
/*
 Notification method handler when status of wifi changes
 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification*)notification;


/* enableUIAccess
 * enable / disable the UI access like enable / disable the textfields
 * and other component while transmitting the packets.
 * @param: vbool is to validate the controls.
 */
-(void) enableUIAccess:(BOOL) isEnable;
@property (nonatomic, retain, readwrite) NSThread* waitForAckThread;
@end

@implementation DEMOSecondViewController
@synthesize waitForAckThread;
//判断设备编号是否合法
-(BOOL)isValidateDeviceNo:(NSString *)deviceNo {
    NSString *regex = @"^(([a-fA-F0-9]{8})|([a-fA-F0-9]{12}))$";
   // NSString *regex = @"^[a-fA-F0-9]{12}$";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [emailTest evaluateWithObject:deviceNo];
}
-(void)viewDidAppear:(BOOL)animated{
    [self stopAction];
}
-(void)viewDidDisappear:(BOOL)animated{
    [self stopAction];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.displayServices = [[NSMutableArray alloc]init];
    [self initData];
    
    _wifiPassword.secureTextEntry = YES;
    // Do any additional setup after loading the view.
    [_deviceRegisterBtn infoStyle];
//    [_scanBtn setBackgroundImage:[UIImage imageNamed:@"ui_sensor_scan"] forState:UIControlStateNormal];
    if( easylink_config == nil){
        easylink_config = [[EASYLINK alloc]init];
        [easylink_config startFTCServerWithDelegate:self];
    }
    
    deviceIPConfig = [[NSMutableDictionary alloc] initWithCapacity:5];
    // wifi notification when changed.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wifiStatusChanged:) name:kReachabilityChangedNotification object:nil];
    
    wifiReachability = [Reachability reachabilityForLocalWiFi];  //监测Wi-Fi连接状态
    [wifiReachability startNotifier];
    
    //waitForAckThread = nil;
    
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus == NotReachable ) {// No activity if no wifi
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"WiFi 不可用.请检查wifi是否连接" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alertView show];
    }else{
        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
        
        
        [_wifiName setText:[EASYLINK ssidForConnectedNetwork]];
    }
    
    [_deviceId addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    [_wifiPassword addTarget:self action:@selector(textViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
   
}
-(void)textViewEditDone{
    [_deviceId resignFirstResponder];
    [_wifiPassword resignFirstResponder];
}

- (IBAction)deviceRegisterClick:(id)sender {
    [_deviceId resignFirstResponder];
    [_wifiPassword resignFirstResponder];
    
    NSString *sensorId = [_deviceId.text length] ? _deviceId.text : @"";
    if([self isValidateDeviceNo:sensorId]){
    [self startTransmitting: EASYLINK_V2];
    [self saveSensor];
    }else{
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"二维码格式不正确" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
}

- (IBAction)scanBtnClick:(id)sender {
    [_deviceId resignFirstResponder];
    [_wifiPassword resignFirstResponder];
    
    /*扫描二维码部分：
     导入ZBarSDK文件并引入一下框架
     AVFoundation.framework
     CoreMedia.framework
     CoreVideo.framework
     QuartzCore.framework
     libiconv.dylib
     引入头文件#import “ZBarSDK.h” 即可使用
     当找到条形码时，会执行代理方法
     
     - (void) imagePickerController: (UIImagePickerController*) reader didFinishPickingMediaWithInfo: (NSDictionary*) info
     
     最后读取并显示了条形码的图片和内容。*/
    
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerView.torchMode = 0;
    reader.readerDelegate = self;
    
    //reader.showsZBarControls = YES;
    //reader.tracksSymbols  =  YES ;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    UIView *viewline = [[UIView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2, [UIScreen mainScreen].bounds.size.width, 1)];
    viewline.backgroundColor = [UIColor redColor];
    [reader.view addSubview:viewline];
    
    ZBarImageScanner *scanner = reader.scanner;
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    [self presentViewController:reader animated:YES completion:nil];
    //[self presentModalViewController: reader animated: YES];
    //[reader release];
}

- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        break;
    
    [reader dismissViewControllerAnimated:YES completion:nil];
    //判断是否包含 头'http:'
    NSString *regex = @"http+:[^\\s]*";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    
    //判断是否包含 头'ssid:'
    NSString *ssid = @"ssid+:[^\\s]*";;
    NSPredicate *ssidPre = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ssid];
    
    [_deviceId setText:symbol.data];
    if ([predicate evaluateWithObject:_deviceId.text]) {
        
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil
                                                        message:@"It will use the browser to this URL。"
                                                       delegate:nil
                                              cancelButtonTitle:@"Close"
                                              otherButtonTitles:@"Ok", nil];
        alert.delegate = self;
        alert.tag=1;
        [alert show];
        
        
        
        
    }
    else if([ssidPre evaluateWithObject:_deviceId.text]){
        
        NSArray *arr = [_deviceId.text componentsSeparatedByString:@";"];
        
        NSArray * arrInfoHead = [[arr objectAtIndex:0] componentsSeparatedByString:@":"];
        
        NSArray * arrInfoFoot = [[arr objectAtIndex:1] componentsSeparatedByString:@":"];
        
        
        _deviceId.text=
        [NSString stringWithFormat:@"ssid: %@ \n password:%@",
         [arrInfoHead objectAtIndex:1],[arrInfoFoot objectAtIndex:1]];
        
        
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:_deviceId.text
                                                        message:@"The password is copied to the clipboard , it will be redirected to the network settings interface"
                                                       delegate:nil
                                              cancelButtonTitle:@"Close"
                                              otherButtonTitles:@"Ok", nil];
        
        
        alert.delegate = self;
        alert.tag=2;
        [alert show];
        
        
        UIPasteboard *pasteboard=[UIPasteboard generalPasteboard];
        //        然后，可以使用如下代码来把一个字符串放置到剪贴板上：
        pasteboard.string = [arrInfoFoot objectAtIndex:1];
        
        
    }
}
/*
 Notification method handler when app enter in forground
 @param the fired notification object
 */
//- (void)appEnterInforground:(NSNotification*)notification{
    //    NSLog(@"%s", __func__);
    //    if( easylink_config == nil){
    //        easylink_config = [[EASYLINK alloc]init];
    //        [easylink_config startFTCServerWithDelegate:self];
    //    }
    //    if( self.foundModules == nil)
    //        self.foundModules = [[NSMutableArray alloc]initWithCapacity:10];
    //    [foundModuleTableView reloadData];
    //    ssidField.text = [EASYLINK ssidForConnectedNetwork];
    //    ipAddress.text = @"Automatic";
    //
    //    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    //    if ( netStatus == NotReachable ) {// No activity if no wifi
    //        alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"WiFi not available. Please check your WiFi connection" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    //        [alertView show];
    //    }else{
    //        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
    //        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
    //        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
    //        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
    //        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
    //    }
    //
    //    NSString *password = [apInforRecord objectForKey:ssidField.text];
    //    if(password == nil) password = @"";
    //    [passwordField setText: password];
    
//}

/*
 Notification method handler when app enter in background
 @param the fired notification object
 */
//- (void)appEnterInBackground:(NSNotification*)notification{
//    NSLog(@"%s", __func__);
    
    //    [easylink_config stopTransmitting];
    //    [easylink_config closeFTCServer];
    //    easylink_config = nil;
    //    self.foundModules = nil;
    //
    //    [easyLinkSendingView close];
    //
    //    [self.navigationController popToRootViewControllerAnimated:NO];
//}

/*
 Notification method handler when status of wifi changes
 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification*)notification{
    NSLog(@"%s", __func__);
    Reachability *verifyConnection = [notification object];
    NSAssert(verifyConnection != NULL, @"currentNetworkStatus called with NULL verifyConnection Object");
    NetworkStatus netStatus = [verifyConnection currentReachabilityStatus];
    if ( netStatus == NotReachable ){
//        if ( _deviceRegisterBtn.selected )
            //            [self easyLinkV2ButtonAction:EasylinkV2Button]; /// Simply revert the state
            // The operation couldn’t be completed. No route to host
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"EMW ToolBox Alert" message:@"未连接wifi. 须连接wifi配网" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
//        [alertView show];
//        
//        _wifiName.text = @"";
//        _wifiPassword.text = @"";
    }else {
        //        NSString *password = [apInforRecord objectForKey:ssidField.text];
        //        if(password == nil) password = @"";
        //        [_wifiPassword setText:password];
        [_wifiName setText:[EASYLINK ssidForConnectedNetwork]];
        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
    }
}

#pragma mark - TRASMITTING DATA -

/*
 This method begins configuration transmit
 In case of a failure the method throws an OSFailureException.
 */
-(void) sendAction{
    newModuleFound = NO;
    [easylink_config transmitSettings];
    //waitForAckThread = [[NSThread alloc] initWithTarget:self selector:@selector(waitForAck:) object:nil];
    //[waitForAckThread start];
}

/*
 This method stop the sending of the configuration to the remote device
 In case of a failure the method throws an OSFailureException.
 */
-(void) stopAction{
    [easylink_config stopTransmitting];
    //[waitForAckThread cancel];
    //waitForAckThread= nil;
}

/*
 This method waits for an acknowledge from the remote device than it stops the transmit to the remote device and returns with data it got from the remote device.
 This method blocks until it gets respond.
 The method will return true if it got the ack from the remote device or false if it got aborted by a call to stopTransmitting.
 In case of a failure the method throws an OSFailureException.
 */

- (void) waitForAck: (id)sender{
    while(![[NSThread currentThread] isCancelled])
    {
//        if ( newModuleFound==YES ){
//            [self stopAction];
//            [self enableUIAccess:YES];
//            [self.navigationController popToRootViewControllerAnimated:YES];
//            break;
//        }
        sleep(1);
    };

}

/*
 This method start the transmitting the data to connected
 AP. Nerwork validation is also done here. All exceptions from
 library is handled.
 */
- (void)startTransmitting: (int)version {
    NSArray *wlanConfigArray;
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus == NotReachable ){// No activity if no wifi
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"WiFi not available. Please check your WiFi connection" delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *ssid = [_wifiName.text length] ? _wifiName.text : nil;
    NSString *passwordKey = [_wifiPassword.text length] ? _wifiPassword.text : @"";
    
    NSNumber *dhcp = [NSNumber numberWithBool:[[deviceIPConfig objectForKey:@"DHCP"] boolValue]];
    NSString *ipString = [[deviceIPConfig objectForKey:@"IP"] length] ? [deviceIPConfig objectForKey:@"IP"] : @"";
    NSString *netmaskString = [[deviceIPConfig objectForKey:@"NetMask"] length] ? [deviceIPConfig objectForKey:@"NetMask"] : @"";
    NSString *gatewayString = [[deviceIPConfig objectForKey:@"GateWay"] length] ? [deviceIPConfig objectForKey:@"GateWay"] : @"";
    NSString *dnsString = [[deviceIPConfig objectForKey:@"DnsServer"] length] ? [deviceIPConfig objectForKey:@"DnsServer"] : @"";
    if([[deviceIPConfig objectForKey:@"DHCP"] boolValue] == YES) ipString = @"";
    
    wlanConfigArray = [NSArray arrayWithObjects: ssid, passwordKey, dhcp, ipString, netmaskString, gatewayString, dnsString, nil];
    
    
    [easylink_config prepareEasyLink_withFTC:wlanConfigArray info:nil version:version];
    //[self sendAction];
    [self sendAction];
    [self enableUIAccess:NO];
}
#pragma mark - Private Methods -

/* enableUIAccess
 * enable / disable the UI access like enable / disable the textfields
 * and other component while transmitting the packets.
 * @param: vbool is to validate the controls.
 */
-(void) enableUIAccess:(BOOL) isEnable{
    //             ssidField.userInteractionEnabled = isEnable;
    //             passwordField.userInteractionEnabled = isEnable;
    //             userInfoField.userInteractionEnabled = isEnable;
    //             ipAddress.userInteractionEnabled = isEnable;
    
    //[halo startAnimation: !isEnable];
    
}

-(void)saveSensor{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_01_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    NSString *sensorId = [_deviceId.text length] ? _deviceId.text : nil;

    if ([sensorId length] == 0) {
        return;
    }
    NSString *wifiNa = [_wifiName.text length] ? _wifiName.text : nil;
    //    if (wifiNa==nil) {
    //        return;
    //    }
    NSString *wifiPwd = _wifiPassword.text;
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    int type = [self getDeviceType:sensorId];
    NSString *name = [self getDeviceName:type];
//    name = [name stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    NSString *typeStr = [NSString stringWithFormat:@"%d",type];
    NSString *sensorIdUper = [sensorId uppercaseString];
    NSLog(@"typeStr: %@", typeStr);
    NSLog(@"sensorIdUper: %@", sensorIdUper);
    
 //   NSString *name1=@"123";
    NSLog(@"name: %@", name);
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"DRIVERID":sensorIdUper,@"DRIVERTYPE":typeStr,@"DRIVERNAME":name};
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [SVProgressHUD show];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSString *resultCode = [resultDic objectForKey:SERVER_RESULT_CODE_KEY];
        [SVProgressHUD dismiss];
        [self initData];
        if ([resultCode isEqualToString:SERVER_RESULT_CODE_SUCCESS]) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[resultDic objectForKey:@"message"] delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            
        }else{
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[resultDic objectForKey:@"message"] delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"联网失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];

    
}

-(int)getDeviceType:(NSString *)deviceId{
    int type =SENSOR_TYPE_ERROR;
    if ([deviceId length]<1) {
        return SENSOR_TYPE_ERROR;
    }
    NSString *typeStr = [deviceId substringToIndex:1];
    int typeInt = [typeStr intValue];
    if (typeInt<=4) {
        return SENSOR_TYPE_GAS;
    }else if (typeInt>4 && typeInt<=8){
        return SENSOR_TYPE_AIR;
    }else if (typeInt>8 && typeInt<=10){
        return SENSOR_TYPE_SMOKE;
    }
    return SENSOR_TYPE_ERROR;
}

-(NSString*)getDeviceName:(int)type{
    NSString *name = @"未定义设备";
    switch (type) {
        case 0:
            break;
        case 1:
            name = @"可燃气体";
            break;
        case 2:
            name = @"空气质量";
            break;
        case 3:
            name = @"烟雾传感器";
            break;
        default:
            name = @"未定义设备";
            break;
    }
    return name;
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.displayServices count];
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *tableCellIdentifier2 = [NSString stringWithFormat:@"DeviceTableCell_%d",indexPath.row];
    DeviceTableViewCell *cell = (DeviceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier2];
    if (cell == nil) {
        cell = [[DeviceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableCellIdentifier2];
    }
    SensorDetail *sensorDetail = [self.displayServices objectAtIndex:indexPath.row];
    cell.deviceName.text = sensorDetail.name;
    cell.deviceId.text = sensorDetail.sensorId;
    if ([sensorDetail.name isEqualToString:@"空气质量"]) {
        AirDevice *air = sensorDetail.airDevice;
        NSString *time = air.createTime;
        long min = [self getMinitusFromNow:time];
        if (min <= -10 || min > 0) {
            cell.isOnline.text = @"不在线";
        }else{
            cell.isOnline.text = @"在线";
        }
        NSLog(@"air%@",air.name);
        
    }else{
        GasDevice *gas = sensorDetail.gasDevice;
        NSString *time = gas.createTime;
        long min = [self getMinitusFromNow:time];
        if (min <= -10 || min > 0) {
            cell.isOnline.text = @"不在线";
        }else{
            cell.isOnline.text = @"在线";
        }
    }
    
    NSLog(@"name-->%@",sensorDetail.name);
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Detail selected");
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle) editingStyle forRowAtIndexPath:(NSIndexPath *) indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        SensorDetail *sensorDetail = [self.displayServices objectAtIndex:indexPath.row];
        
        [self deleteDevice:sensorDetail.sensorId];
        [self.displayServices removeObjectAtIndex:[indexPath row]];
        if (self.displayServices.count == 0) {
            g_bBindDevice = NO;
            
            if ([[NSFileManager defaultManager]fileExistsAtPath:[g_UserDirPath stringByAppendingPathComponent:@"CacheData"]]) {
                [[NSFileManager defaultManager] removeItemAtPath:[g_UserDirPath stringByAppendingPathComponent:@"CacheData"] error:nil];
                g_bHaveCache = NO;
            }
        }
        [_devicesTableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationTop];
    }  
}
//设置选中Cell的响应事件

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//选中后的反显颜色即刻消失
}
-(long)getMinitusFromNow:(NSString *)time{
    int result = 0;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *  senddate = [NSDate date];
    //结束时间
    NSDate *endDate = [dateFormatter dateFromString:time];
    //当前时间
    NSDate *senderDate = [dateFormatter dateFromString:[dateFormatter stringFromDate:senddate]];
    //得到相差秒数
    NSTimeInterval second = [endDate timeIntervalSinceDate:senderDate];
    result = ((int)second)/60;
    return result;
}

-(void)deleteDevice:(NSString*)sensorId{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_01_04];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"DRIVERID":sensorId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        [_devicesTableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)initData{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [SVProgressHUD show];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
        NSDictionary *arr = dataObject[0];
        NSArray *list = [arr objectForKey:@"sensorList"];
        NSMutableArray *items = [[NSMutableArray alloc]init];
        NSError* err = nil;
        for(NSDictionary *member in list)
        {
            NSLog(@"%@",[member objectForKey:@"sensorId"]);
            SensorDetail *item = [[SensorDetail alloc] init];
            item.sensorId = [member objectForKey:@"sensorId"];
            item.name =[member objectForKey:@"name"];
            if ([item.name isEqualToString:@"空气质量"]) {
                NSDictionary *airDic = [member objectForKey:@"air"];
                AirDevice *air = [[AirDevice alloc] initWithDictionary:airDic error:&err];
                item.airDevice = air;
                NSLog(@"air%@",air.name);
                
            }else{
                NSDictionary *gasDic = [member objectForKey:@"gas"];
                GasDevice *gas = [[GasDevice alloc]initWithDictionary:gasDic error:&err];
                item.gasDevice = gas;
            }
            [items addObject:item];
            
        }
        if (self.displayServices.count != 0) {
            [self.displayServices removeAllObjects];
        }
        [self.displayServices addObjectsFromArray:items];
        if (self.displayServices.count != 0) {
            g_bBindDevice = YES;
        }
        [_devicesTableView reloadData];
        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.deviceId resignFirstResponder];
    [self.wifiPassword resignFirstResponder];
    
}
@end
