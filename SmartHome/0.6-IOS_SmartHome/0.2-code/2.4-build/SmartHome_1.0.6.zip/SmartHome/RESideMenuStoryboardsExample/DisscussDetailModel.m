//
//  DisscussDetailModel.m
//  SmartHome
//
//  Created by 李静 on 14-11-12.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "DisscussDetailModel.h"

@implementation DisscussDetailModel
@synthesize ma001;
@synthesize ma002;
@synthesize ma003;
@synthesize ma004;
@synthesize ma005;
@synthesize ma006;
@synthesize ma007;
@synthesize ma008;
@synthesize ma009;
@end
