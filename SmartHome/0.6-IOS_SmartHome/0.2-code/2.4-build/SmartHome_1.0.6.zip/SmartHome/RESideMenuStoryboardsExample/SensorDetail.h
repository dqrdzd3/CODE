//
//  SensorDetail.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-28.
//  Copyright (c) 2014年 河南汉威电子股份有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AirDevice.h"
#import "GasDevice.h"
#import "CartoonInfo.h"
@interface SensorDetail : JSONModel
    @property(nonatomic,copy)NSString *sensorId;
    @property(nonatomic,copy)NSString *name;
    @property(nonatomic,copy)NSString *online;
    @property(nonatomic,retain) AirDevice *airDevice;
    @property(nonatomic,retain) GasDevice *gasDevice;
    - (CartoonInfo *)getCartoonInfo;
- (BOOL)isOnline;
@end
