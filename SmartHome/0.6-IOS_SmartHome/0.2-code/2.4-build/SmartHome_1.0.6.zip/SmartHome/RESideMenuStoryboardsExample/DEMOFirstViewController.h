//
//  DEMOFirstViewController.h
//  RESideMenuStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"
#import "CMPopTipView.h"
#import "FirstContentView.h"
#import "RankAdviceViewController.h"

@interface DEMOFirstViewController : UIViewController<FirstContentViewDelegate>{
    CGRect rect;
    NSMutableDictionary *mdicContentViews;
    NSTimer *timer;
}
@end
