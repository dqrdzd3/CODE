//
//  SensorType.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-4.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SensorType : NSObject
FOUNDATION_EXPORT int const SENSOR_TYPE_ERROR;
//可燃气体
FOUNDATION_EXPORT const int SENSOR_TYPE_GAS;

FOUNDATION_EXPORT const int SENSOR_TYPE_AIR;
FOUNDATION_EXPORT const int SENSOR_TYPE_SMOKE;
@end
