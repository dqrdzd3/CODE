//
//  User.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-21.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "User.h"

@implementation User
@synthesize ma001;
@synthesize ma002;
@synthesize ma003;
@synthesize ma004;
@synthesize ma005;
@synthesize ma006;
@synthesize ma007;
@synthesize ma008;
@synthesize ma009;
@synthesize ma010;
@synthesize ma011;
@synthesize ma012;
@synthesize ma013;
@synthesize ma014;
@synthesize ma015;
@synthesize ma016;
@synthesize ma017;
@synthesize ma018;
@synthesize ma019;
@synthesize ma020;
@end
