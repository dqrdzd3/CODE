//
//  FirstContentView.m
//  SmartHome
//
//  Created by apple on 14-11-12.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "FirstContentView.h"
#import "SensorDetail.h"
#import "DeviceDataConstant.h"
#import <QuartzCore/QuartzCore.h>

#define TopBarHeight 64

@implementation FirstContentView
@synthesize delegate;
@synthesize dicGasData;
@synthesize dicAirData;
@synthesize dicFLineData;
@synthesize aryFAllDeviceid;

@synthesize labelUpdateTitle;
@synthesize labelStatusTitle;
@synthesize btnArrowTop;
@synthesize btnArrowLeft;
@synthesize btnArrowRight;
@synthesize imageHomeBg;
@synthesize labelStatus;
@synthesize btnValueRank;
@synthesize labelUpdateDate;
@synthesize labelValue;
@synthesize btnCortoon;
@synthesize btnHistory;
@synthesize btnShare;
@synthesize viewDeviceDate;
@synthesize imageValueRankIcon;
@synthesize labelValueRank;

@synthesize labelCo;
@synthesize labelCo2;
@synthesize labelDeviceName;
@synthesize labelGas;
@synthesize labelPm;
@synthesize labelTemp;
@synthesize labelWet;
@synthesize imageCo;
@synthesize imageCo2;
@synthesize imageGas;
@synthesize imagePm;
@synthesize imageTemp;
@synthesize imageWet;
@synthesize labelVoc;
@synthesize imageVoc;

@synthesize lineChartViewCo;
@synthesize lineChartViewCo2;
@synthesize lineChartViewGas;
@synthesize lineChartViewPm;
@synthesize lineChartViewTempWet;

@synthesize visiblePopTipViews;
-(id)initWithFrame:(CGRect)frame alldata:(NSDictionary *)data AirDevice:(AirDevice *)airinfo GasDevice:(GasDevice *)gasinfo{
    self = [super initWithFrame:frame];
    if (self) {
        rect = frame;
        iCartoonClickIndex = 0;
        fx_Info = 20;
        fy_Device = rect.size.height-197;
        dicAllData = data;
        dicAirData = airinfo;
        dicGasData = gasinfo;
        visiblePopTipViews = [[NSMutableArray alloc]init];
        // Do any additional setup after loading the view
    }
    return self;
}

-(void)initData:(NSDictionary *)data AirDevice:(AirDevice *)airinfo GasDevice:(GasDevice *)gasinfo{
    dicAllData = data;
    dicAirData = airinfo;
    dicGasData = gasinfo;
}
-(void)layoutSubviews{
    [self GetLineData];
}
#pragma mark------------LoadTopView
-(void)LoadTopView{
    if (imageHomeBg == nil) {
        imageHomeBg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
        [self addSubview:imageHomeBg];
    }
    imageHomeBg.image = [UIImage imageNamed:@"homeBg"];
    
    if (labelUpdateTitle == nil) {
        labelUpdateTitle = [[UILabel alloc]initWithFrame:CGRectMake(fx_Info, 20, rect.size.width-2*fx_Info, 20)];
        [self addSubview:labelUpdateTitle];
    }
    labelUpdateTitle.backgroundColor = [UIColor clearColor];
    labelUpdateTitle.font = [UIFont systemFontOfSize:14.0];
    labelUpdateTitle.textColor = [UIColor blackColor];
    labelUpdateTitle.text = @"更新时间";
    
    if (labelUpdateDate == nil) {
        labelUpdateDate = [[UILabel alloc]initWithFrame:CGRectMake(fx_Info, labelUpdateTitle.frame.origin.y+labelUpdateTitle.frame.size.height, labelUpdateTitle.frame.size.width, 20)];
        [self addSubview:labelUpdateDate];
    }
    labelUpdateDate.backgroundColor = [UIColor clearColor];
    labelUpdateDate.font = [UIFont systemFontOfSize:14.0];
    labelUpdateDate.textColor = [UIColor blackColor];

    
    if (labelValue == nil) {
        labelValue = [[UILabel alloc]initWithFrame:CGRectMake(fx_Info, labelUpdateDate.frame.origin.y+labelUpdateDate.frame.size.height, 0, 70)];
        [self addSubview:labelValue];
    }
    labelValue.backgroundColor = [UIColor clearColor];
    labelValue.font = [UIFont systemFontOfSize:50.0];
    labelValue.textColor = [UIColor blackColor];


    if (labelStatus == nil) {
        labelStatus = [[UILabel alloc]initWithFrame:CGRectMake(labelValue.frame.origin.x+labelValue.frame.size.width, labelValue.frame.origin.y+(labelValue.frame.size.height-25)/2, 50, 25)];
        [self addSubview:labelStatus];
    }
    labelStatus.textAlignment = NSTextAlignmentCenter;
    labelStatus.backgroundColor = [UIColor redColor];
    labelStatus.font = [UIFont boldSystemFontOfSize:18.0];
    labelStatus.textColor = [UIColor whiteColor];
    
    
    
    if (labelStatusTitle == nil) {
        labelStatusTitle = [[UILabel alloc]initWithFrame:CGRectMake(fx_Info, labelValue.frame.origin.y+labelValue.frame.size.height, rect.size.width-2*fx_Info, 20)];
        [self addSubview:labelStatusTitle];
    }
    labelStatusTitle.backgroundColor = [UIColor clearColor];
    labelStatusTitle.font = [UIFont systemFontOfSize:14.0];
    labelStatusTitle.textColor = [UIColor blackColor];
    labelStatusTitle.text = @"当前室内空气指数";
    
    
    
    if (btnValueRank == nil) {
        btnValueRank = [[UIButton alloc]initWithFrame:CGRectMake(fx_Info, labelStatusTitle.frame.origin.y+labelStatusTitle.frame.size.height, 150, 20)];
        [btnValueRank addTarget:self action:@selector(ClickValueRank) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnValueRank];
    }
    if (imageValueRankIcon == nil) {
        imageValueRankIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 10, 10)];
        [btnValueRank addSubview:imageValueRankIcon];
    }
    if (labelValueRank == nil) {
        labelValueRank = [[UILabel alloc]initWithFrame:CGRectMake(imageValueRankIcon.frame.origin.x+imageValueRankIcon.frame.size.width, 0, btnValueRank.frame.size.width-imageValueRankIcon.frame.origin.x-imageValueRankIcon.frame.size.width+20, btnValueRank.frame.size.height)];
        [btnValueRank addSubview:labelValueRank];
    }
    imageValueRankIcon.image = [UIImage imageNamed:@"up"];
    labelValueRank.backgroundColor = [UIColor clearColor];
    labelValueRank.font = [UIFont systemFontOfSize:12.0];
    labelValueRank.textColor = [UIColor blackColor];
    labelValueRank.text = @"领先全国的用户,改善>>>";
    
    
    if (btnHistory == nil) {
        btnHistory = [[UIButton alloc]initWithFrame:CGRectMake(fx_Info, fy_Device-40, 30, 30)];
        [btnHistory addTarget:self action:@selector(ClickHistory) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnHistory];
    }
    [btnHistory setImage:[UIImage imageNamed:@"history_alarm"] forState:UIControlStateNormal];
    
    
    if (btnShare == nil) {
        btnShare = [[UIButton alloc]initWithFrame:CGRectMake(btnHistory.frame.origin.x+btnHistory.frame.size.width+20, btnHistory.frame.origin.y, 30, 30)];
        [btnShare addTarget:self action:@selector(ClickShare) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnShare];
    }
    [btnShare setImage:[UIImage imageNamed:@"ui_home_share"] forState:UIControlStateNormal];
    
    
    if (btnCortoon == nil) {
        btnCortoon = [[UIButton alloc]initWithFrame:CGRectMake(rect.size.width-145, fy_Device-175.5, 125, 165.5)];
        [btnCortoon addTarget:self action:@selector(ClickCortoon) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnCortoon];
    }
    [btnCortoon setImage:[UIImage imageNamed:@"001"] forState:UIControlStateNormal];
}
#pragma mark------------LoadAirInfoView
-(void)LoadAirInfoView{
    if (viewDeviceDate == nil) {
        viewDeviceDate = [[UIView alloc]initWithFrame:CGRectMake(0, fy_Device, rect.size.width, 2*rect.size.height)];
        [self addSubview:viewDeviceDate];
    }
    viewDeviceDate.backgroundColor = [UIColor whiteColor];
    
    if (btnArrowTop == nil) {
        btnArrowTop = [[UIButton alloc]initWithFrame:CGRectMake(rect.size.width/2-15, 5, 30, 10)];
        [viewDeviceDate addSubview:btnArrowTop];
    }
    [btnArrowTop addTarget:self action:@selector(ClickArrowTop) forControlEvents:UIControlEventTouchUpInside];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_up"] forState:UIControlStateNormal];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_down"] forState:UIControlStateHighlighted];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_down"] forState:UIControlStateSelected];
    
    
    if (labelDeviceName == nil) {
        labelDeviceName = [[UILabel alloc]initWithFrame:CGRectMake(10, btnArrowTop.frame.origin.y+btnArrowTop.frame.size.height, viewDeviceDate.frame.size.width-20, 40)];
        [viewDeviceDate addSubview:labelDeviceName];
    }
    labelDeviceName.textAlignment = NSTextAlignmentCenter;
    labelDeviceName.backgroundColor = [UIColor clearColor];
    labelDeviceName.font = [UIFont boldSystemFontOfSize:12.0];
    labelDeviceName.textColor = [UIColor grayColor];

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    
    NSInteger icount = 5;//设备检测项目个数
    float fviewDeviceDateWidth = viewDeviceDate.frame.size.width;//设备展示栏目的宽度
    float fgap = 10;//间隙
    float fDeviceImageWidth = (fviewDeviceDateWidth-(2*icount)*fgap)/icount;//一项检测项目图片宽度
    float fy = labelDeviceName.frame.origin.y+labelDeviceName.frame.size.height;//该栏目的Y坐标
    
    if (imageTemp == nil) {
        imageTemp = [[UIImageView alloc]initWithFrame:CGRectMake(fgap, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageTemp];
    }
    imageTemp.image = [UIImage imageNamed:@"IconTemperature"];
    if (labelTemp == nil) {
        labelTemp = [[UILabel alloc]initWithFrame:CGRectMake(imageTemp.frame.origin.x-fgap, imageTemp.frame.origin.y+imageTemp.frame.size.height, imageTemp.frame.size.width+2*fgap, 20)];
        [viewDeviceDate addSubview:labelTemp];
    }
    labelTemp.textAlignment = NSTextAlignmentCenter;
    labelTemp.backgroundColor = [UIColor clearColor];
    labelTemp.font = [UIFont systemFontOfSize:14.0];
    labelTemp.textColor = [UIColor blackColor];

    
    if (imageWet == nil) {
        imageWet = [[UIImageView alloc]initWithFrame:CGRectMake(imageTemp.frame.origin.x+fDeviceImageWidth+2*fgap, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageWet];
    }
    imageWet.image = [UIImage imageNamed:@"IconShidu"];
    
    if (labelWet == nil) {
        labelWet = [[UILabel alloc]initWithFrame:CGRectMake(imageWet.frame.origin.x-fgap, imageWet.frame.origin.y+imageWet.frame.size.height, imageWet.frame.size.width+2*fgap, 20)];
        [viewDeviceDate addSubview:labelWet];
    }
    labelWet.textAlignment = NSTextAlignmentCenter;
    labelWet.backgroundColor = [UIColor clearColor];
    labelWet.font = [UIFont systemFontOfSize:14.0];
    labelWet.textColor = [UIColor blackColor];

    
    if (imageCo2 == nil) {
        imageCo2 = [[UIImageView alloc]initWithFrame:CGRectMake(imageWet.frame.origin.x+fDeviceImageWidth+2*fgap, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageCo2];
    }
    imageCo2.image = [UIImage imageNamed:@"co2"];
    if (labelCo2 == nil) {
        labelCo2 = [[UILabel alloc]initWithFrame:CGRectMake(imageCo2.frame.origin.x-fgap, imageCo2.frame.origin.y+imageCo2.frame.size.height, imageCo2.frame.size.width+2*fgap, 20)];
        [viewDeviceDate addSubview:labelCo2];
    }
    labelCo2.textAlignment = NSTextAlignmentCenter;
    labelCo2.backgroundColor = [UIColor clearColor];
    labelCo2.font = [UIFont systemFontOfSize:14.0];
    labelCo2.textColor = [UIColor blackColor];

    
    if (imagePm == nil) {
        imagePm = [[UIImageView alloc]initWithFrame:CGRectMake(imageCo2.frame.origin.x+fDeviceImageWidth+2*fgap, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imagePm];
    }
    imagePm.image = [UIImage imageNamed:@"IconPm"];
    if (labelPm == nil) {
        labelPm = [[UILabel alloc]initWithFrame:CGRectMake(imagePm.frame.origin.x-fgap, imagePm.frame.origin.y+imagePm.frame.size.height, imagePm.frame.size.width+2*fgap, 20)];
        [viewDeviceDate addSubview:labelPm];
    }
    labelPm.textAlignment = NSTextAlignmentCenter;
    labelPm.backgroundColor = [UIColor clearColor];
    labelPm.font = [UIFont systemFontOfSize:14.0];
    labelPm.textColor = [UIColor blackColor];

    
    if (imageVoc == nil) {
        imageVoc = [[UIImageView alloc]initWithFrame:CGRectMake(imagePm.frame.origin.x+fDeviceImageWidth+2*fgap, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageVoc];
    }
    imageVoc.image = [UIImage imageNamed:@"ui_home_unit_voc"];
    if (labelVoc == nil) {
        labelVoc = [[UILabel alloc]initWithFrame:CGRectMake(imageVoc.frame.origin.x-fgap, imageVoc.frame.origin.y+imageVoc.frame.size.height, imageVoc.frame.size.width+2*fgap, 20)];
        [viewDeviceDate addSubview:labelVoc];
    }
    labelVoc.textAlignment = NSTextAlignmentCenter;
    labelVoc.backgroundColor = [UIColor clearColor];
    labelVoc.font = [UIFont systemFontOfSize:14.0];
    labelVoc.textColor = [UIColor blackColor];

    
    //////////////////////////////////////////////////////////
    //添加左右箭头
    if (btnArrowLeft == nil) {
        btnArrowLeft = [[UIButton alloc]initWithFrame:CGRectMake(0, labelDeviceName.frame.origin.y, 10, 30)];
        [viewDeviceDate addSubview:btnArrowLeft];
    }
    [btnArrowLeft setImage:[UIImage imageNamed:@"ui_home_page_left"] forState:UIControlStateNormal];
    
    if (btnArrowRight == nil) {
        btnArrowRight = [[UIButton alloc]initWithFrame:CGRectMake(rect.size.width-10, btnArrowLeft.frame.origin.y, 10, 30)];
        [viewDeviceDate addSubview:btnArrowRight];
    }
    [btnArrowRight setImage:[UIImage imageNamed:@"ui_home_page_right"] forState:UIControlStateNormal];
    if (rect.origin.x == 0) {
        btnArrowLeft.hidden = YES;
    }
    
    labelStatus.hidden = NO;
    labelValue.hidden = NO;
    labelStatusTitle.hidden = NO;
    labelValueRank.hidden = NO;
    imageValueRankIcon.hidden = NO;
    panGestureRecognizer = [[UIPanGestureRecognizer alloc]
                            initWithTarget:self
                            action:@selector(handlePan:)];
    panGestureRecognizer.delegate = self;
    panGestureRecognizer.maximumNumberOfTouches = 1;
    [viewDeviceDate addGestureRecognizer:panGestureRecognizer];
}

#pragma mark------------LoadGasInfoView
-(void)LoadGasInfoView{
    if (viewDeviceDate == nil) {
        viewDeviceDate = [[UIView alloc]initWithFrame:CGRectMake(0, fy_Device, rect.size.width, 2*rect.size.height)];
        [self addSubview:viewDeviceDate];
    }
    viewDeviceDate.backgroundColor = [UIColor whiteColor];
    
    if (btnArrowTop == nil) {
        btnArrowTop = [[UIButton alloc]initWithFrame:CGRectMake(rect.size.width/2-15, 5, 30, 10)];
        [viewDeviceDate addSubview:btnArrowTop];
    }
    [btnArrowTop addTarget:self action:@selector(ClickArrowTop) forControlEvents:UIControlEventTouchUpInside];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_up"] forState:UIControlStateNormal];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_down"] forState:UIControlStateHighlighted];
    [btnArrowTop setImage:[UIImage imageNamed:@"ui_home_page_down"] forState:UIControlStateSelected];
    
    
    if (labelDeviceName == nil) {
        labelDeviceName = [[UILabel alloc]initWithFrame:CGRectMake(10, btnArrowTop.frame.origin.y+btnArrowTop.frame.size.height, viewDeviceDate.frame.size.width-20, 40)];
        [viewDeviceDate addSubview:labelDeviceName];
    }
    labelDeviceName.textAlignment = NSTextAlignmentCenter;
    labelDeviceName.backgroundColor = [UIColor clearColor];
    labelDeviceName.font = [UIFont boldSystemFontOfSize:12.0];
    labelDeviceName.textColor = [UIColor grayColor];
    
    
    float fviewDeviceDateWidth = viewDeviceDate.frame.size.width;//设备展示栏目的宽度
    float fDeviceImageWidth = 44;//一项检测项目图片宽度
    float fy = labelDeviceName.frame.origin.y+labelDeviceName.frame.size.height;//该栏目的Y坐标
    float fgap2 = (fviewDeviceDateWidth-2*fDeviceImageWidth)/4;
    
    if (imageGas == nil) {
        imageGas = [[UIImageView alloc]initWithFrame:CGRectMake(fgap2, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageGas];
    }
    imageGas.image = [UIImage imageNamed:@"gas"];
    if (labelGas == nil) {
        labelGas = [[UILabel alloc]initWithFrame:CGRectMake(imageGas.frame.origin.x-fgap2, imageGas.frame.origin.y+imageGas.frame.size.height, imageGas.frame.size.width+2*fgap2, 20)];
        [viewDeviceDate addSubview:labelGas];
    }
    labelGas.textAlignment = NSTextAlignmentCenter;
    labelGas.backgroundColor = [UIColor clearColor];
    labelGas.font = [UIFont systemFontOfSize:14.0];
    labelGas.textColor = [UIColor blackColor];
    
    
    if (imageCo == nil) {
        imageCo = [[UIImageView alloc]initWithFrame:CGRectMake(imageGas.frame.origin.x+imageGas.frame.size.width+2*fgap2, fy, fDeviceImageWidth, fDeviceImageWidth)];
        [viewDeviceDate addSubview:imageCo];
    }
    imageCo.image = [UIImage imageNamed:@"co"];
    if (labelCo == nil) {
        labelCo = [[UILabel alloc]initWithFrame:CGRectMake(imageCo.frame.origin.x-fgap2, imageCo.frame.origin.y+imageCo.frame.size.height, imageCo.frame.size.width+2*fgap2, 20)];
        [viewDeviceDate addSubview:labelCo];
    }
    labelCo.textAlignment = NSTextAlignmentCenter;
    labelCo.backgroundColor = [UIColor clearColor];
    labelCo.font = [UIFont systemFontOfSize:14.0];
    labelCo.textColor = [UIColor blackColor];
    
    //////////////////////////////////////////////////////////
    //添加左右箭头
    if (btnArrowLeft == nil) {
        btnArrowLeft = [[UIButton alloc]initWithFrame:CGRectMake(0, labelDeviceName.frame.origin.y, 10, 30)];
        [viewDeviceDate addSubview:btnArrowLeft];
    }
    [btnArrowLeft setImage:[UIImage imageNamed:@"ui_home_page_left"] forState:UIControlStateNormal];
    
    if (btnArrowRight == nil) {
        btnArrowRight = [[UIButton alloc]initWithFrame:CGRectMake(rect.size.width-10, btnArrowLeft.frame.origin.y, 10, 30)];
        [viewDeviceDate addSubview:btnArrowRight];
    }
    [btnArrowRight setImage:[UIImage imageNamed:@"ui_home_page_right"] forState:UIControlStateNormal];
    
    labelStatus.hidden = YES;
    labelValue.hidden = YES;
    labelStatusTitle.hidden = YES;
    labelValueRank.hidden = YES;
    imageValueRankIcon.hidden = YES;
    panGestureRecognizer = [[UIPanGestureRecognizer alloc]
                            initWithTarget:self
                            action:@selector(handlePan:)];
    panGestureRecognizer.delegate = self;
    panGestureRecognizer.maximumNumberOfTouches = 1;
    [viewDeviceDate addGestureRecognizer:panGestureRecognizer];
}
-(void)hideRightArrow{
   btnArrowRight.hidden = YES;
}
-(void)hideLeftArrow{
    btnArrowLeft.hidden = YES;
}

#pragma mark------------LoadTopViewData
-(void)LoadTopViewData:(CartoonInfo *)cartooninfo{
    
    carToonInfo = cartooninfo;
    NSString *strUpdateDate = @"";
    if (dicAirData != nil) {
        strUpdateDate = [NSString stringWithFormat:@"%@",dicAirData.createTime];
    }
    else{
        strUpdateDate = [NSString stringWithFormat:@"%@",dicGasData.createTime];
    }
    if ([strUpdateDate isEqualToString:@"1900-01-01 01:01:01"]) {
        labelUpdateDate.text = @"传感器未联网";
    }
    else{
       labelUpdateDate.text = [self DateFormat:strUpdateDate];
    }
    
    NSString *strPm = dicAirData.pm25;
    if (strPm.length == 0) {
        strPm = @"0";
    }
    
    labelValue.text = [NSString stringWithFormat:@"%d",[strPm integerValue]];
    
    CGSize maximumSizeContent = CGSizeMake([UIScreen mainScreen].bounds.size.width/2, 70);
    NSDictionary * tdicContent = [NSDictionary dictionaryWithObjectsAndKeys:labelValue.font,NSFontAttributeName,nil];
    CGSize  actualsizeContent = [strPm boundingRectWithSize:maximumSizeContent options:NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading attributes:tdicContent context:nil].size;
    CGRect frame = labelValue.frame;
    frame.size.width = actualsizeContent.width-20;
    labelValue.frame = frame;
    

    CGRect frames = labelStatus.frame;
    frames.origin.x = labelValue.frame.origin.x+labelValue.frame.size.width;
    labelStatus.frame = frames;
    
    
    [self setAQI:[strPm floatValue]];
    [self GetRankData:strPm];
    
    [self GetLineData];
}
#pragma mark------------LoadAirInfoData
-(void)LoadAirInfoData{
    strSensorId = dicAirData.sensorId;
    if (strSensorId.length == 0) {
        labelDeviceName.text = [NSString stringWithFormat:@"气体质量检测设备:"];
    }
    labelDeviceName.text = [NSString stringWithFormat:@"空气质量检测设备:%@",strSensorId];

    
    NSString *strTemp = dicAirData.temperature;
    if (strTemp.length == 0) {
        labelTemp.text = @"0.0";
    }
    else{
        labelTemp.text = strTemp;
    }
    
    NSString *strWet = dicAirData.humidity;
    if (strWet.length == 0) {
        labelWet.text = @"0.0";
    }
    else{
        labelWet.text = strWet;
    }
    
    NSString *strCo2 = dicAirData.co2;
    if (strCo2.length == 0) {
        labelCo2.text = @"0.0";
    }
    else{
        labelCo2.text = strCo2;
    }
    
    NSString *strPm = dicAirData.pm25;
    if (strPm.length == 0) {
        labelPm.text = @"0.0";
    }
    else{
        labelPm.text = strPm;
    }
    
    
    NSString *strVoc = dicAirData.voc;
    if (strVoc.length == 0) {
        labelVoc.text = @"0.0";
    }
    else{
        labelVoc.text = strVoc;
    }
    
    [self GetLineData];
}

#pragma mark------------LoadGasInfoData
-(void)LoadGasInfoData{
    strSensorId = dicGasData.sensorId;
    if (strSensorId.length == 0) {
        labelDeviceName.text = [NSString stringWithFormat:@"气体质量检测设备:"];
    }
    labelDeviceName.text = [NSString stringWithFormat:@"可燃气体检测设备:%@",strSensorId];


    NSString *strGas = dicGasData.ch4;
    if (strGas.length == 0) {
        labelGas.text = @"0.0 LEL";
    }
    else{
        labelGas.text = [NSString stringWithFormat:@"%@ LEL",strGas];
    }
    
    NSString *strCo = dicGasData.co;
    if (strCo.length == 0) {
        labelCo.text = @"0.0 PPM";
    }
    else{
        labelCo.text = [NSString stringWithFormat:@"%@ PPM",strCo];
    }
    
    if ([strGas floatValue] > CH4_THRESHOLD) {
        imageGas.image = [UIImage imageNamed:@"ui_home_unit_ch4_hight"];
    }
    else{
        imageGas.image = [UIImage imageNamed:@"gas"];
    }
    if ([strCo floatValue] > CO_THRESHOLD) {
        imageCo.image = [UIImage imageNamed:@"ui_home_unit_co_high"];
    }
    else{
        imageCo.image = [UIImage imageNamed:@"co"];
    }
    
    
    [self GetLineData];
}


#pragma mark------------NetData
-(void)GetRankData:(NSString *)score{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:RANKING];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    
    NSDictionary *parameter = @{@"SCORE":score,@"GASTYPE":@"3",@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        labelValueRank.text = [NSString stringWithFormat:@"领先全国%@的用户,改善>>>",[resultDic objectForKey:@"data"]];
        if ([resultDic objectForKey:@"dataObject"] != [NSNull null]) {
            if ([[resultDic objectForKey:@"dataObject"] isEqualToString:@"up"]) {
                imageValueRankIcon.image = [UIImage imageNamed:@"up"];
            }
            else{
                imageValueRankIcon.image = [UIImage imageNamed:@"down"];
            }
        }

    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)GetLineData{
    if (dicFLineData.count == 0) {
        NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"yyyyMMdd"];
        todayDate = [dateFormat stringFromDate:[NSDate date]];
    }
    else{
        NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"yyyyMMdd"];
        NSString* curDate = [dateFormat stringFromDate:[NSDate date]];
        if ([curDate isEqualToString:todayDate]) {
            return;
        }
    }
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        //NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        if ([resultDic objectForKey:@"dataObject"] != [NSNull null]) {
            NSArray *aryDataObject = [resultDic objectForKey:@"dataObject"];
            NSDictionary *dictemp = [aryDataObject objectAtIndex:0];
            NSArray *arySensorList = [dictemp objectForKey:@"sensorList"];
            
            NSMutableDictionary *mdicSensorId = [[NSMutableDictionary alloc]init];
            for (NSDictionary *dic in arySensorList) {
                [mdicSensorId setObject:[dic objectForKey:@"sensorId"] forKey:[dic objectForKey:@"sensorId"]];
            }
            NSArray *aryAllDeviceid = [mdicSensorId allKeys];
            
            NSMutableDictionary *mdicLineData = [[NSMutableDictionary alloc]init];
            for (int i = 0; i < aryAllDeviceid.count; i++) {
                NSString *strDeviceid = [aryAllDeviceid objectAtIndex:i];
                NSMutableArray *mary = [[NSMutableArray alloc]init];
                for (NSDictionary *dic in arySensorList) {
                    NSDictionary *dicAir = [dic objectForKey:@"air"];
                    NSDictionary *dicGas = [dic objectForKey:@"gas"];
                    if ([[dic objectForKey:@"sensorId"] isEqualToString:strDeviceid]) {
                        if (dicAir.count != 0) {
                            [mary addObject:dicAir];
                        }
                        else if (dicGas.count != 0){
                            [mary addObject:dicGas];
                        }
                    }
                }
                [mdicLineData setObject:mary forKey:strDeviceid];
            }
            dicFLineData = mdicLineData;
            aryFAllDeviceid = aryAllDeviceid;
            [self LoadLineView];
        }
        else{
            NSLog(@"dataObject空值!");
        }
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}
//折线图页面及数据
-(void)LoadLineView{
    float fLineViewWidth = viewDeviceDate.frame.size.width-10;
    float fLineHeight = 120;
    float fy = 0.0;
    if (dicAirData != nil) {
        fy = labelTemp.frame.origin.y+labelTemp.frame.size.height;
    }
    else{
        fy = labelGas.frame.origin.y+labelGas.frame.size.height;
    }
    if (lineChartViewTempWet == nil) {
        lineChartViewTempWet = [[PCLineChartView alloc] initWithFrame:CGRectMake(5,fy,fLineViewWidth,fLineHeight)];
        [lineChartViewTempWet setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
        lineChartViewTempWet.minValue = 0;
        lineChartViewTempWet.maxValue = 10;
        lineChartViewTempWet.interval = 2;
        [viewDeviceDate addSubview:lineChartViewTempWet];
    }
    if (lineChartViewCo2 == nil) {
        lineChartViewCo2 = [[PCLineChartView alloc] initWithFrame:CGRectMake(5,fy+fLineHeight,fLineViewWidth,fLineHeight)];
        [lineChartViewCo2 setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
        lineChartViewCo2.minValue = 0;
        lineChartViewCo2.maxValue = 10;
        lineChartViewCo2.interval = 2;
        [viewDeviceDate addSubview:lineChartViewCo2];
    }
    if (lineChartViewPm == nil) {
        lineChartViewPm = [[PCLineChartView alloc] initWithFrame:CGRectMake(5,fy+2*fLineHeight,fLineViewWidth,fLineHeight)];
        [lineChartViewPm setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
        lineChartViewPm.minValue = 0;
        lineChartViewPm.maxValue = 10;
        lineChartViewPm.interval = 2;
        [viewDeviceDate addSubview:lineChartViewPm];
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    //////////
    if (lineChartViewGas == nil) {
        lineChartViewGas = [[PCLineChartView alloc] initWithFrame:CGRectMake(5,fy,fLineViewWidth,fLineHeight)];
        [lineChartViewGas setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
        lineChartViewGas.minValue = 0;
        lineChartViewGas.maxValue = 10;
        lineChartViewGas.interval = 2;
        [viewDeviceDate addSubview:lineChartViewGas];
    }
    if (lineChartViewCo == nil) {
        lineChartViewCo = [[PCLineChartView alloc] initWithFrame:CGRectMake(5,fy+fLineHeight,fLineViewWidth,fLineHeight)];
        [lineChartViewCo setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
        lineChartViewCo.minValue = 0;
        lineChartViewCo.maxValue = 10;
        lineChartViewCo.interval = 2;
        [viewDeviceDate addSubview:lineChartViewCo];
    }
    
    
    if (dicAirData != nil) {
        lineChartViewTempWet.hidden = NO;
        lineChartViewCo2.hidden = NO;
        lineChartViewPm.hidden = NO;
        lineChartViewGas.hidden = YES;
        lineChartViewCo.hidden = YES;
    }
    else{
        lineChartViewTempWet.hidden = YES;
        lineChartViewCo2.hidden = YES;
        lineChartViewPm.hidden = YES;
        lineChartViewGas.hidden = NO;
        lineChartViewCo.hidden = NO;
    }
    [self GetAndShowLineData:dicFLineData aryDeviceid:aryFAllDeviceid];
}

-(void)GetAndShowLineData:(NSDictionary *)linedata aryDeviceid:(NSArray *)aryDeviceid{
    ////////////////////////////////////////////////

    for (NSInteger i = 0; i < aryDeviceid.count; i++) {
        NSString *strDeviceid = [aryDeviceid objectAtIndex:i];
        if ([strDeviceid isEqualToString:strSensorId]) {
            NSArray *arytemp = [linedata objectForKey:strDeviceid];
            if (dicAirData != nil) {
                NSMutableArray *maryWeek = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasTemp = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasWet = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasPm = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasVoc = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasCo2 = [[NSMutableArray alloc]init];
    
                NSSortDescriptor *_sorter  = [[NSSortDescriptor alloc] initWithKey:@"createTime"ascending:YES];
                [arytemp sortedArrayUsingDescriptors:[NSArray arrayWithObjects:_sorter, nil]];
                
                for (NSInteger i = (arytemp.count-1);i >= 0;i--) {
                    NSDictionary *dic = [arytemp objectAtIndex:i];
                    NSString *strTemp = [dic objectForKey:@"temperature"];
                    NSString *strWet = [dic objectForKey:@"humidity"];
                    NSString *strPm = [dic objectForKey:@"pm25"];
                    NSString *strVoc = [dic objectForKey:@"voc"];
                    NSString *strCo2 = [dic objectForKey:@"co2"];
                    if (strTemp.length == 0) {
                        strTemp = @"0.0";
                    }
                    if (strWet.length == 0) {
                        strWet = @"0.0";
                    }
                    if (strPm.length == 0) {
                        strPm = @"0.0";
                    }
                    if (strVoc.length == 0) {
                        strVoc = @"0.0";
                    }
                    if (strCo2.length == 0) {
                        strCo2 = @"0.0";
                    }
                    [maryDatasTemp addObject:strTemp];
                    [maryDatasWet addObject:strWet];
                    [maryDatasPm addObject:strPm];
                    [maryDatasVoc addObject:strVoc];
                    [maryDatasCo2 addObject:strCo2];
                    
                    [maryWeek addObject:[self WeekToCh:[dic objectForKey:@"createTime"]]];
                }

                NSInteger maxTemp = [[maryDatasTemp valueForKeyPath:@"@max.intValue"] integerValue];
                NSInteger maxWet = [[maryDatasWet valueForKeyPath:@"@max.intValue"] integerValue];
                NSInteger maxPm = [[maryDatasPm valueForKeyPath:@"@max.intValue"] integerValue];
                NSInteger maxVoc = [[maryDatasVoc valueForKeyPath:@"@max.intValue"] integerValue];
                NSInteger maxCo2 = [[maryDatasCo2 valueForKeyPath:@"@max.intValue"] integerValue];
                
                lineChartViewTempWet.minValue = 0;
                lineChartViewPm.minValue = 0;
                lineChartViewCo2.minValue = 0;
                if (maxTemp > maxWet) {
                    if (maxTemp == 0) {
                        lineChartViewTempWet.maxValue = 10;
                    }
                    else{
                        lineChartViewTempWet.interval = maxTemp/4;
                        lineChartViewTempWet.maxValue = maxTemp;
                    }
                }
                else{
                    if (maxWet == 0) {
                        lineChartViewTempWet.maxValue = 10;
                    }
                    else{
                        lineChartViewTempWet.interval = maxWet/4;
                        lineChartViewTempWet.maxValue = maxWet;
                    }
                }
                if (maxPm == 0) {
                    lineChartViewPm.maxValue = 10;
                }
                else{
                    lineChartViewPm.interval = maxPm/5;
                    lineChartViewPm.maxValue = maxPm;
                }
                if (maxCo2 > maxVoc) {
                    if (maxCo2 == 0) {
                        lineChartViewCo2.maxValue = 10;
                    }
                    else{
                        lineChartViewCo2.interval = maxCo2/5;
                        lineChartViewCo2.maxValue = maxCo2;
                    }
                }
                else{
                    if (maxVoc == 0) {
                        lineChartViewCo2.maxValue = 10;
                    }
                    else{
                        lineChartViewCo2.interval = maxVoc/5;
                        lineChartViewCo2.maxValue = maxVoc;
                    }
                    
                }
                NSMutableArray *components = [NSMutableArray array];
                PCLineChartViewComponent *componentTemp = [[PCLineChartViewComponent alloc] init];
                [componentTemp setTitle:@"温度"];
                [componentTemp setPoints:maryDatasTemp];
                [componentTemp setShouldLabelValues:NO];
                [componentTemp setColour:PCColorGreen];
                [components addObject:componentTemp];
                
                PCLineChartViewComponent *componentWet = [[PCLineChartViewComponent alloc] init];
                [componentWet setTitle:@"湿度"];
                [componentWet setPoints:maryDatasWet];
                [componentWet setShouldLabelValues:NO];
                [componentWet setColour:PCColorBlue];
                [components addObject:componentWet];
                [lineChartViewTempWet setComponents:components];
                [lineChartViewTempWet setXLabels:maryWeek];
                
                NSMutableArray *componentpm = [NSMutableArray array];
                PCLineChartViewComponent *componentPm = [[PCLineChartViewComponent alloc] init];
                [componentPm setTitle:@"pm2.5"];
                [componentPm setPoints:maryDatasPm];
                [componentPm setShouldLabelValues:NO];
                [componentPm setColour:PCColorYellow];
                [componentpm addObject:componentPm];
                [lineChartViewPm setComponents:componentpm];
                [lineChartViewPm setXLabels:maryWeek];
                
                
                NSMutableArray *componentco2 = [NSMutableArray array];
                PCLineChartViewComponent *componentCo2 = [[PCLineChartViewComponent alloc] init];
                [componentCo2 setTitle:@"co2"];
                [componentCo2 setPoints:maryDatasCo2];
                [componentCo2 setShouldLabelValues:NO];
                [componentCo2 setColour:PCColorRed];
                [componentco2 addObject:componentCo2];
                
                PCLineChartViewComponent *componentVoc = [[PCLineChartViewComponent alloc] init];
                [componentVoc setTitle:@"voc"];
                [componentVoc setPoints:maryDatasVoc];
                [componentVoc setShouldLabelValues:NO];
                [componentVoc setColour:PCColorOrange];
                [componentco2 addObject:componentVoc];
                
                [lineChartViewCo2 setComponents:componentco2];
                [lineChartViewCo2 setXLabels:maryWeek];
            }
            else
            {
                NSMutableArray *maryWeek = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasCh4 = [[NSMutableArray alloc]init];
                NSMutableArray *maryDatasCo = [[NSMutableArray alloc]init];
                NSSortDescriptor *_sorter  = [[NSSortDescriptor alloc] initWithKey:@"createTime"ascending:YES];
                [arytemp sortedArrayUsingDescriptors:[NSArray arrayWithObjects:_sorter, nil]];
                
                for (NSInteger i = (arytemp.count-1);i >= 0;i--) {
                    NSDictionary *dic = [arytemp objectAtIndex:i];
                    NSString *strCh4 = [dic objectForKey:@"ch4"];
                    NSString *strCo = [dic objectForKey:@"co"];
                    if (strCh4.length == 0) {
                        strCh4 = @"0.0";
                    }
                    if (strCo.length == 0) {
                        strCo = @"0.0";
                    }
                    [maryDatasCh4 addObject:strCh4];
                    [maryDatasCo addObject:strCo];
                    [maryWeek addObject:[self WeekToCh:[dic objectForKey:@"createTime"]]];
                }
                
                NSInteger maxTempCh4 = [[maryDatasCh4 valueForKeyPath:@"@max.intValue"] integerValue];
                NSInteger maxCo = [[maryDatasCo valueForKeyPath:@"@max.intValue"] integerValue];
                
                lineChartViewGas.minValue = 0;
                lineChartViewCo.minValue = 0;
                if (maxTempCh4 == 0) {
                    lineChartViewGas.maxValue = 10;
                }
                else{
                    lineChartViewGas.interval = maxTempCh4/5;
                    lineChartViewGas.maxValue = maxTempCh4;
                }
                if (maxCo == 0) {
                    lineChartViewCo.maxValue = 10;
                }
                else{
                    lineChartViewCo.interval = maxCo/5;
                    lineChartViewCo.maxValue = maxCo;
                }
                
                NSMutableArray *componentsch4 = [NSMutableArray array];
                PCLineChartViewComponent *componentCh4 = [[PCLineChartViewComponent alloc] init];
                [componentCh4 setTitle:@"ch4"];
                [componentCh4 setPoints:maryDatasCh4];
                [componentCh4 setShouldLabelValues:NO];
                [componentCh4 setColour:PCColorRed];
                [componentsch4 addObject:componentCh4];
                [lineChartViewGas setComponents:componentsch4];
                [lineChartViewGas setXLabels:maryWeek];
                
                NSMutableArray *componentsco = [NSMutableArray array];
                PCLineChartViewComponent *componentCo = [[PCLineChartViewComponent alloc] init];
                [componentCo setTitle:@"co"];
                [componentCo setPoints:maryDatasCo];
                [componentCo setShouldLabelValues:NO];
                [componentCo setColour:PCColorYellow];
                [componentsco addObject:componentCo];
                [lineChartViewCo setComponents:componentsco];
                [lineChartViewCo setXLabels:maryWeek];
            }
        }
    }
}

#pragma mark------------tools
-(NSString *)DateFormat:(NSString *)createTime{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *  senddate = [NSDate date];
    //结束时间
    NSDate *endDate = [dateFormatter dateFromString:[createTime substringToIndex:10]];
    //当前时间
    NSDate *senderDate = [dateFormatter dateFromString:[dateFormatter stringFromDate:senddate]];
    //得到相差秒数
    NSTimeInterval time = [endDate timeIntervalSinceDate:senderDate];
    int days = ((int)time)/(3600*24);

    NSString *result;
    if (days == 0) {
        result = [NSString stringWithFormat:@"今天%@",[createTime substringFromIndex:10]];
    }
    else if (days == -1) {
        result = [NSString stringWithFormat:@"昨天%@",[createTime substringFromIndex:10]];
    }
    else if (days == -2){
        result = [NSString stringWithFormat:@"前天%@",[createTime substringFromIndex:10]];
    }
    else if (days == -3){
        result = [NSString stringWithFormat:@"大前天%@",[createTime substringFromIndex:10]];
    }
    else{
        result = createTime;
    }
    return  result;
}
-(NSString *)WeekToCh:(NSString *)strdate{
    NSInteger week = [self dayOfWeekType:strdate];
    if (week == 1) {
        return @"周一";
    }
    else if (week == 2){
        return @"周二";
    }
    else if (week == 3){
        return @"周三";
    }
    else if (week == 4){
        return @"周四";
    }
    else if (week == 5){
        return @"周五";
    }
    else if (week == 6){
        return @"周六";
    }
    else if (week == 7){
        return @"周日";
    }
    else{
        return @"未知";
    }
}
-(NSString* )dayOfWeek:(NSString *)strdate{
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyyMMdd"];
    NSDate *date = [dateFormat dateFromString:strdate];
    
    NSDateFormatter *fmtter =[[NSDateFormatter alloc] init];
    [fmtter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
    [fmtter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    [fmtter setDateFormat:@"EEE"];
    return [fmtter stringFromDate:date];
}
-(NSInteger)dayOfWeekType:(NSString *)strdate{
    NSString* dayString = [self dayOfWeek:strdate];
    if (nil == dayString) {
        return 0;
    }
    
    if ([dayString hasPrefix:@"Mon"]) {
        return 2;
    }
    if ([dayString hasPrefix:@"Tue"]) {
        return 3;
    }
    if ([dayString hasPrefix:@"Wed"]) {
        return 4;
    }
    if ([dayString hasPrefix:@"Thu"]) {
        return 5;
    }
    if ([dayString hasPrefix:@"Fri"]) {
        return 6;
    }
    if ([dayString hasPrefix:@"Sat"]) {
        return 7;
    }
    if ([dayString hasPrefix:@"Sun"]) {
        return 1;
    }
    return 0;
}

//空气质量指数
-(void) setAQI:(int)pm25{
    NSString *status = @"";
    UIColor *color = nil;
    if(pm25==0){
        status = @"空";
        color = [UIColor colorWithRed:154/255.0 green:189/255.0 blue:207/255.0 alpha:1];
    }else if(pm25<= PM25_VERY_GOOD){
        status = @"优";
        color = [UIColor colorWithRed:72/255.0 green:201/255.0 blue:100/255.0 alpha:1];
    }else if(pm25 > PM25_VERY_GOOD&&pm25<=PM25_GOOD){
        status = @"良";
        color = [UIColor colorWithRed:207/255.0 green:177/255.0 blue:67/255.0 alpha:1];
    }else if(pm25 >PM25_GOOD&&pm25 <=PM25_WEAK){
        status = @"轻度";
        color = [UIColor colorWithRed:207/255.0 green:177/255.0 blue:67/255.0 alpha:1];
    }else if(pm25 > PM25_WEAK&&pm25 <=PM25_BAD){
        status = @"中度";
        color = [UIColor colorWithRed:223/255.0 green:95/255.0 blue:50/255.0 alpha:1];
    }else if (pm25 > PM25_BAD&& pm25<=PM25_VERY_BAD){
        status = @"重度";
        color = [UIColor colorWithRed:223/255.0 green:95/255.0 blue:50/255.0 alpha:1];
    }else if(pm25 > PM25_VERY_BAD){
        status = @"严重";
        color = [UIColor colorWithRed:223/255.0 green:95/255.0 blue:50/255.0 alpha:1];
    }
    
    [labelStatus setText:status];
    if (color!=nil) {
        [labelStatus setBackgroundColor:color];
    }
}

#pragma mark------------click&recognizer
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    CGPoint translatedPoint = [panGestureRecognizer translationInView:viewDeviceDate];
    if (translatedPoint.x != 0) {
        return NO;
    }
    return YES;
}
- (void) handlePan:(UIPanGestureRecognizer*) recognizer
{
    [self dismissAllPopTipViews];
    CGPoint translation = [recognizer translationInView:self];
    if ((recognizer.view.center.y-fPanOldY) > 0) {
        if (recognizer.state == UIGestureRecognizerStateEnded) {
            if (viewDeviceDate.frame.origin.y != fy_Device) {
                [UIView animateWithDuration:0.3 animations:^{
                    CGRect frame = viewDeviceDate.frame;
                    frame.origin.y = fy_Device;
                    viewDeviceDate.frame = frame;
                } completion:^(BOOL finished){
                    btnArrowTop.selected = NO;
                }];
                fPanOldY = recognizer.view.center.y;
                [recognizer setTranslation:CGPointZero inView:self];
                return;
            }
        }
    }
    else{
        if (recognizer.state == UIGestureRecognizerStateEnded) {
            if (viewDeviceDate.frame.origin.y != 0) {
                [UIView animateWithDuration:0.3 animations:^{
                    CGRect frame = viewDeviceDate.frame;
                    frame.origin.y = 0;
                    viewDeviceDate.frame = frame;
                } completion:^(BOOL finished){
                    btnArrowTop.selected = YES;
                }];
                fPanOldY = recognizer.view.center.y;
                [recognizer setTranslation:CGPointZero inView:self];
                return;
            }
        }
    }
    fPanOldY = recognizer.view.center.y;
    
    recognizer.view.center = CGPointMake(recognizer.view.center.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointZero inView:self];
    
}

-(void)ClickArrowTop{
    btnArrowTop.selected = !btnArrowTop.selected;
    if (!btnArrowTop.selected) {
        if (viewDeviceDate.frame.origin.y != fy_Device) {
            [UIView animateWithDuration:0.3 animations:^{
                CGRect frame = viewDeviceDate.frame;
                frame.origin.y = fy_Device;
                viewDeviceDate.frame = frame;
            } completion:^(BOOL finished){
            }];
            fPanOldY = viewDeviceDate.center.y;
        }
    }
    else{
        if (viewDeviceDate.frame.origin.y != 0) {
            [UIView animateWithDuration:0.3 animations:^{
                CGRect frame = viewDeviceDate.frame;
                frame.origin.y = 0;
                viewDeviceDate.frame = frame;
            } completion:^(BOOL finished){
            }];
            fPanOldY = viewDeviceDate.center.y;
        }
    }
}
-(void)ClickArrowLeft{
    
}
-(void)ClickArrowRight{
    
}
//点击全国排名
-(void)ClickValueRank{
    [delegate FirstContentViewRank:self data:dicAllData];
}
//点击历史记录
-(void)ClickHistory{
    if (historyView == nil) {
        historyView = [[HistoryView alloc]initWithFrame:CGRectMake(0, 0, rect.size.width-80, rect.size.height-100) deviceid:strSensorId];
    }
    [[KGModal sharedInstance] showWithContentView:historyView andAnimated:YES];
}
//点击分享
-(void)ClickShare{
    //构造分享内容
    NSString *strContent = @"";
    NSString *strUrl = @"http://weiguo.hanwei.cn/smart/download_link.html";
    if (dicAirData != nil) {
        strContent = [NSString stringWithFormat:@"空气电台播报:温度[%@]湿度[%@]二氧化碳[%@]PM2.5[%@]Voc[%@]",labelTemp.text,labelWet.text,labelCo2.text,labelPm.text,labelVoc.text];
    }
    else{
        strContent = [NSString stringWithFormat:@"空气电台播报:燃气[%@]一氧化碳[%@]",labelGas.text,labelCo.text];
    }
    
    
    UIImage *image = [UIImage imageNamed:@"share.png"];
    [self shareTitle:@"空气电台" content:strContent image:image url:strUrl];
    
}

-(void)shareTitle:(NSString *)title content:(NSString *)content image:(UIImage *)img url:(NSString *)url
{
    //分享的 底ViewControoler
    id<ISSContainer> container = [ShareSDK container];
    
    //可以 设置 sharesdk 弹出的底ViewController
    //[container setIPhoneContainerWithViewController:nil];
    
    
    //自动授权
    id<ISSAuthOptions> authOptions = [ShareSDK authOptionsWithAutoAuth:YES
                                                         allowCallback:YES
                                                         authViewStyle:SSAuthViewStyleFullScreenPopup
                                                          viewDelegate:nil
                                               authManagerViewDelegate:nil];
    
    //要分享的列表
    NSArray *shareList = [ShareSDK getShareListWithType:ShareTypeSinaWeibo, ShareTypeTencentWeibo, ShareTypeQQSpace,ShareTypeWeixiSession,ShareTypeWeixiTimeline,ShareTypeQQ,nil];
    
    //加入分享的图片
    id<ISSCAttachment> shareImage = nil;
    SSPublishContentMediaType shareType = SSPublishContentMediaTypeText;
    if(img)
    {
        shareImage = [ShareSDK pngImageWithImage:img];
        shareType = SSPublishContentMediaTypeNews;
    }
    
    //分享的内容
    id<ISSContent>publishContent = [ShareSDK content:content defaultContent:@"空气电台播报"
                                               image:shareImage
                                               title:title
                                                 url:url
                                         description:@"空气电台播报"
                                           mediaType:shareType];
    
    //弹出分享菜单
    
    [ShareSDK showShareActionSheet:container
                         shareList:shareList
                           content:publishContent
                     statusBarTips:YES
                       authOptions:authOptions
                      shareOptions:nil
                            result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
                                if (state == SSResponseStateSuccess)
                                {
                                    NSLog(@"分享成功");
                                }
                                else if (state == SSResponseStateFail)
                                {
                                    NSLog(@"发布失败!error code == %d, error code == %@", [error errorCode], [error errorDescription]);
                                }
                            }];
    
}

//点击豆
-(void)ClickCortoon{
    NSInteger imaxCartoonClickIndex = carToonInfo.talkText.count;
    if (iCartoonClickIndex >= imaxCartoonClickIndex) {
        iCartoonClickIndex = 0;
    }
    NSString *strTalktext = [carToonInfo.talkText objectAtIndex:iCartoonClickIndex];
    [btnCortoon setImage:[carToonInfo.expressImages objectAtIndex:iCartoonClickIndex] forState:UIControlStateNormal];
    [self showPopMessage:strTalktext];
    iCartoonClickIndex++;
}
#pragma mark--------------PopMessage

-(void)showPopMessage:(NSString *)message{
    [self dismissAllPopTipViews];
    
    UIColor *backgroundColor = [UIColor colorWithRed:255.0/255.0 green:255/255.0 blue:255/255.0 alpha:0.5];
    UIColor *textColor = [UIColor blackColor];

    CMPopTipView *popTipView = [[CMPopTipView alloc] initWithMessage:message];
    popTipView.delegate = self;
    
    /* Some options to try.
     */
    //popTipView.disableTapToDismiss = YES;
    popTipView.dismissTapAnywhere = NO;
    popTipView.preferredPointDirection = PointDirectionDown;
    popTipView.hasGradientBackground = NO;
    popTipView.cornerRadius = 3.0;
    popTipView.has3DStyle = NO;
    popTipView.borderWidth = 0.0;
    popTipView.sidePadding = 40.0f;
    //popTipView.topMargin = 20.0f;
    //popTipView.pointerSize = 50.0f;
    popTipView.hasShadow = NO;
    //popTipView.disableTapToDismiss = YES;
    if (backgroundColor && ![backgroundColor isEqual:[NSNull null]]) {
        popTipView.backgroundColor = backgroundColor;
    }
    if (textColor && ![textColor isEqual:[NSNull null]]) {
        popTipView.textColor = textColor;
        popTipView.textFont = [UIFont systemFontOfSize:14.0];
    }
    popTipView.animation = arc4random() % 2;
    //  popTipView.has3DStyle = (BOOL)(arc4random() % 2);
    [popTipView autoDismissAnimated:NO atTimeInterval:4.0];
    
    
    [popTipView presentPointingAtView:btnCortoon inView:self animated:YES];
    [self.visiblePopTipViews addObject:popTipView];
    self.currentPopTipViewTarget = btnCortoon;
    
    CGRect frame = popTipView.frame;
    frame.origin.y = frame.origin.y+50;
    popTipView.frame = frame;
    
}

- (void)dismissAllPopTipViews
{
    if  ([self.visiblePopTipViews count] > 0) {
        CMPopTipView *popTipView = [self.visiblePopTipViews objectAtIndex:0];
        [popTipView dismissAnimated:YES];
        [self.visiblePopTipViews removeObjectAtIndex:0];
    }
}

#pragma mark - CMPopTipViewDelegate methods

- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView
{
    [self.visiblePopTipViews removeObject:popTipView];
    self.currentPopTipViewTarget = nil;
    
}
@end
