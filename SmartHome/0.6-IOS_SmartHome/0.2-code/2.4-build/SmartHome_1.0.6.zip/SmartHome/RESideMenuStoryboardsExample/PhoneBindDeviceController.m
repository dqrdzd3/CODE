//
//  PhoneBindDeviceController.m
//  SmartHome
//
//  Created by 李静 on 14-11-24.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "PhoneBindDeviceController.h"
#import "ZBarSDK.h"
#import "UIButton+Bootstrap.h"
#import "SVProgressHUD.h"
#import "LoginViewController.h"
#import "DeviceUtil.h"
#import "SensorDetail.h"
#import "HardwareViewController.h"
#import "DEMORootViewController.h"
extern BOOL      g_bBindDevice;
extern BOOL      g_bHaveCache;

@implementation PhoneBindDeviceController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initView];
}
//触摸其他区域键盘消失
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.qrCodeTextField resignFirstResponder];
}
-(void)initView{
    _scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height+100);
    [_lastBtn dangerStyle];
    [_bindBtn infoStyle];
    [_nextBtn successStyle];
    [_nextBtn setHidden:YES];
    [_nextLabel setHidden:YES];
    [_hintLabel setText:SENSOR_WIFI_GUIDE];
    
    _qrCodeTextField.returnKeyType = UIReturnKeyDone;
    [_qrCodeTextField addTarget:self action:@selector(CodetextViewEditDone) forControlEvents:UIControlEventEditingDidEndOnExit];
    
    [_qrCodeTextField addTarget:self action:@selector(CodetextViewEditBegin) forControlEvents:UIControlEventEditingDidBegin];
}

-(void)CodetextViewEditBegin{
    [_scrollView setContentOffset:CGPointMake(0, 200) animated:YES];
}
-(void)CodetextViewEditDone{
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [_qrCodeTextField resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)bindBtnClick:(id)sender {
    [_qrCodeTextField resignFirstResponder];
    [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    
    NSString *sensorId = [_qrCodeTextField.text length] ? _qrCodeTextField.text : @"";
    if([DeviceUtil isValidateDeviceNo:sensorId]){
        [self saveSensor];
    }else{
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"二维码格式不正确" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
    
}

- (IBAction)scanBtnClick:(id)sender {
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerView.torchMode = 0;
    reader.readerDelegate = self;
    
    //reader.showsZBarControls = YES;
    //reader.tracksSymbols  =  YES ;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    UIView *viewline = [[UIView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2, [UIScreen mainScreen].bounds.size.width, 1)];
    viewline.backgroundColor = [UIColor redColor];
    [reader.view addSubview:viewline];
    
    ZBarImageScanner *scanner = reader.scanner;
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    [self presentViewController:reader animated:YES completion:nil];
}
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        break;
    
    
    [reader dismissViewControllerAnimated:YES completion:nil];
    [_qrCodeTextField setText:symbol.data];
}

- (IBAction)lastBtnClick:(id)sender {
    if(g_bBindDevice){
        [[NSNotificationCenter defaultCenter]postNotificationName:@"NeedShowRoot" object:nil];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        if(g_bHaveCache){
            [[NSNotificationCenter defaultCenter]postNotificationName:@"NeedShowRoot" object:nil];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else{
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            LoginViewController *contr = [storyboard instantiateViewControllerWithIdentifier:@"loginViewController"];
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isLoginSuccess"];
            contr.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
            [self presentModalViewController:contr animated:YES];//在这里一跳就行了。
        }
    }

    [self removeFromParentViewController];
}

- (IBAction)nextBtnClick:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DescriptionConfigViewController *ca = [storyboard instantiateViewControllerWithIdentifier:@"descriptionConfigViewController"];
        NSString *sensorId = [_qrCodeTextField.text length] ? _qrCodeTextField.text : nil;
    ca.deviceId = sensorId;
    ca.modalTransitionStyle = UIModalPresentationFormSheet;//跳转效果
            [self presentViewController:ca animated:YES completion:NULL];

}

-(void)saveSensor{
    
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_01_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    NSString *sensorId = [_qrCodeTextField.text length] ? _qrCodeTextField.text : nil;
    if (sensorId==nil) {
        return;
    }
    
    if ([sensorId length]<1) {
        return;
    }
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    int type = [DeviceUtil getDeviceType:sensorId];
    NSString *name = [DeviceUtil getDeviceName:type];

    NSString *typeStr = [NSString stringWithFormat:@"%d",type];
    NSString *sensorIdUper = [sensorId uppercaseString];
    NSLog(@"typeStr: %@", typeStr);
    NSLog(@"sensorIdUper: %@", sensorIdUper);
    
    //   NSString *name1=@"123";
    NSLog(@"name: %@", name);
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"DRIVERID":sensorIdUper,@"DRIVERTYPE":typeStr,@"DRIVERNAME":name};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [SVProgressHUD showWithStatus:@"绑定中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
        NSString *resultCode = [resultDic objectForKey:SERVER_RESULT_CODE_KEY];
        [_nextBtn setHidden:NO];
        [SVProgressHUD showSuccessWithStatus:@"绑定成功" duration:2];
//        [SVProgressHUD dismiss];
//        if ([resultCode isEqualToString:SERVER_RESULT_CODE_SUCCESS]) {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[resultDic objectForKey:@"message"] delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
//            [alertView show];

//            
//        }else{
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[resultDic objectForKey:@"message"] delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
//            [alertView show];
//            
//        }
        g_bBindDevice = YES;
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"联网失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];
    
    
}


@end
