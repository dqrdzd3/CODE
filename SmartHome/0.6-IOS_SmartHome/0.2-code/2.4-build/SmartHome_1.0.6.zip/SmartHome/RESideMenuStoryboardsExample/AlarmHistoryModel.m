//
//  AlarmHistoryModel.m
//  SmartHome
//  历史报警
//  Created by 李静 on 14-11-14.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "AlarmHistoryModel.h"

@implementation AlarmHistoryModel

@end
