//
//  DeviceListViewController.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-24.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "DeviceListViewController.h"
#import <sys/socket.h>
#import <netinet/in.h>
#import "DeviceTableViewCell.h"
#include <arpa/inet.h>
#import "SensorDetail.h"
#import "SVProgressHUD.h"
#define searchingString @"Searching for MXCHIP Modules..."
#define kWebServiceType @"_easylink._tcp"
#define kInitialDomain  @"local"
#define repeatInterval  10.0
bool newModuleFound;
bool enumerating = NO;
@interface DeviceListViewController ()



@property (nonatomic, retain, readwrite) NSTimer* timer;
@property (nonatomic, assign, readwrite) BOOL initialWaitOver;
/*
 Notification method handler when app enter in forground
 @param the fired notification object
 */
- (void)appEnterInforground:(NSNotification*)notification;

/*
 Notification method handler when app enter in background
 @param the fired notification object
 */
- (void)appEnterInBackground:(NSNotification*)notification;

@end

@implementation DeviceListViewController

@synthesize displayServices;

@dynamic timer;
@synthesize initialWaitOver = _initialWaitOver;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    // Do any additional setup after loading the view.
//    MJRefreshHeaderView *header = [MJRefreshHeaderView header];
//    header.scrollView = browserTableView;
//    header.delegate = self;
   
    // Make sure we have a chance to discover devices before showing the user that nothing was found (yet)
  //  [browserTableView reloadData];
    browserTableView.allowsMultipleSelection = NO;
//    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(initialWaitOver:) userInfo:nil repeats:NO];

    
   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)initialWaitOver:(NSTimer*)timer {
    self.initialWaitOver= YES;
    if (![self.displayServices count])
        [browserTableView reloadData];
}



- (NSTimer *)timer {
    return _timer;
}

// When this is called, invalidate the existing timer before releasing it.
- (void)setTimer:(NSTimer *)newTimer {
    [_timer invalidate];
    _timer = newTimer;
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self.displayServices count];
    if (count == 0 && self.initialWaitOver)
        return 1;
    NSLog(@"COUNT,@%d",count);
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableCellIdentifier2 = @"DeviceTableCell";
    
    DeviceTableViewCell *cell = (DeviceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier2];

    if (cell == nil) {
        cell = [[DeviceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableCellIdentifier2];
    }
    

    
    SensorDetail *sensorDetail = [self.displayServices objectAtIndex:indexPath.row];
    cell.deviceName.text = sensorDetail.name;
    cell.deviceId.text = sensorDetail.sensorId;
    if ([sensorDetail.name isEqualToString:@"空气质量"]) {
      
        AirDevice *air = sensorDetail.airDevice;
        NSString *time = air.createTime;
        long min =[self getMinitusFromNow:time];
        if (min>10) {
            cell.isOnline.text = @"不在线";
        }else{
            cell.isOnline.text = @"在线";
        }
        NSLog(@"air%@",air.name);
        
    }else{
        GasDevice *gas = sensorDetail.gasDevice;
        NSString *time = gas.createTime;
        long min =[self getMinitusFromNow:time];
        if (min>10) {
            cell.isOnline.text = @"不在线";
        }else{
            cell.isOnline.text = @"在线";
        }
    }
    
    NSLog(@"name-->%@",sensorDetail.name);
    return cell;

}




- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}



- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Detail selected");
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle) editingStyle forRowAtIndexPath:(NSIndexPath *) indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
  
          SensorDetail *sensorDetail = [self.displayServices objectAtIndex:indexPath.row];
        
        [self deleteDevice:sensorDetail.sensorId];
        [self.displayServices removeObjectAtIndex:[indexPath row]];
        [browserTableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationTop];
    }  
} 


#pragma mark - 刷新控件的代理方法
#pragma mark 开始进入刷新状态
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    NSLog(@"%@----开始进入刷新状态", refreshView.class);
   
    // 2.2秒后刷新表格UI
    [self performSelector:@selector(doneWithView:) withObject:refreshView afterDelay:1.0];
    
}

#pragma mark 刷新完毕
- (void)refreshViewEndRefreshing:(MJRefreshBaseView *)refreshView
{
    NSLog(@"%@----刷新完毕", refreshView.class);
}

#pragma mark 监听刷新状态的改变
- (void)refreshView:(MJRefreshBaseView *)refreshView stateChange:(MJRefreshState)state
{
    switch (state) {
        case MJRefreshStateNormal:
            NSLog(@"%@----切换到：普通状态", refreshView.class);
            break;
            
        case MJRefreshStatePulling:
            NSLog(@"%@----切换到：松开即可刷新的状态", refreshView.class);
            break;
            
        case MJRefreshStateRefreshing:
            NSLog(@"%@----切换到：正在刷新状态", refreshView.class);
            break;
        default:
            break;
    }
}

#pragma mark 刷新表格并且结束正在刷新状态
- (void)doneWithView:(MJRefreshBaseView *)refreshView
{
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
    [refreshView endRefreshing];
}



/*
 Notification method handler when app enter in forground
 @param the fired notification object
 */
- (void)appEnterInforground:(NSNotification*)notification{
    
    
}

/*
 Notification method handler when app enter in background
 @param the fired notification object
 */
- (void)appEnterInBackground:(NSNotification*)notification{
    NSLog(@"%s", __func__);
}
-(void)initData{

    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_02_02_01];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };

    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [SVProgressHUD show];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
                NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
                NSDictionary *arr = dataObject[0];
                NSArray *list = [arr objectForKey:@"sensorList"];
            NSMutableArray *items = [[NSMutableArray alloc]init];
         NSError* err = nil;
                for(NSDictionary *member in list)
                {
                    NSLog(@"%@",[member objectForKey:@"sensorId"]);
                    SensorDetail *item = [[SensorDetail alloc] init];
                    item.sensorId = [member objectForKey:@"sensorId"];
                    item.name =[member objectForKey:@"name"];
                    if ([item.name isEqualToString:@"空气质量"]) {
                        NSDictionary *airDic = [member objectForKey:@"air"];
                        AirDevice *air = [[AirDevice alloc] initWithDictionary:airDic error:&err];
                        item.airDevice = air;
                        NSLog(@"air%@",air.name);
                        
                    }else{
                        NSDictionary *gasDic = [member objectForKey:@"gas"];
                        GasDevice *gas = [[GasDevice alloc]initWithDictionary:gasDic error:&err];
                        item.gasDevice = gas;
                    }
                    [items addObject:item];
        
                }
        self.displayServices = items;
       // [items release];
       [browserTableView reloadData];
        [SVProgressHUD dismiss];
    
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
    }];

}

-(void)deleteDevice:(NSString*)sensorId{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_01_04];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    NSDictionary *parameter = @{@"USERID":userId,@"SESSIONID":sessionId,@"DRIVERID":sensorId};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
//        NSString *requestTmp = [NSString stringWithString:operation.responseString];
//        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
//        //系统自带JSON解析
//        
//        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];
//        NSArray *dataObject = [resultDic objectForKey:@"dataObject"];
//        NSDictionary *arr = dataObject[0];
//        NSArray *list = [arr objectForKey:@"sensorList"];
//        NSMutableArray *items = [[NSMutableArray alloc]init];
        
//        for(NSDictionary *member in list)
//        {
//            NSLog(@"%@",[member objectForKey:@"sensorId"]);
//            SensorDetail *item = [[SensorDetail alloc] init];
//            item.sensorId = [member objectForKey:@"sensorId"];
//            item.name =[member objectForKey:@"name"];
//            
//            [items addObject:item];
//            
//        }
//        self.displayServices = items;
        // [items release];
        [browserTableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
    }];

}

-(long)getMinitusFromNow:(NSString *)time{
    int result = 0;
    NSDate *date = [[NSDate alloc] init];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *fromDate = [dateFormatter dateFromString:time];
    long second = [date timeIntervalSinceDate:fromDate]/1000;
    result = second/60;
    
    return result;
}
@end
