//
//  PhoneBindDeviceController.h
//  SmartHome
//
//  Created by 李静 on 14-11-24.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
#import "RTLabel.h"
#import "DescriptionConfigViewController.h"

@interface PhoneBindDeviceController : UIViewController<ZBarReaderDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
@property (weak, nonatomic) IBOutlet UIButton *lastBtn;
- (IBAction)bindBtnClick:(id)sender;
- (IBAction)scanBtnClick:(id)sender;
- (IBAction)lastBtnClick:(id)sender;
- (IBAction)nextBtnClick:(id)sender;
@property (weak,nonatomic) IBOutlet UITextField *qrCodeTextField;
@property (weak, nonatomic) IBOutlet UIButton *bindBtn;
@property (weak, nonatomic) IBOutlet UILabel *nextLabel;
@property (weak, nonatomic) IBOutlet RTLabel *hintLabel;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@end
