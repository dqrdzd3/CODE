//
//  RankAdviceViewController.m
//  SmartHome
//
//  Created by apple on 14-11-17.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "RankAdviceViewController.h"

@implementation RankAdviceViewController
@synthesize strGasstate;
@synthesize strGastype;
@synthesize webView;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%f",[UIScreen mainScreen].bounds.size.height);
    if ([UIScreen mainScreen].bounds.size.height <= 480) {
        webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    }
    else{
        webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    }
    
    webView.scalesPageToFit = YES;
    [self.view addSubview:webView];
    // Do any additional setup after loading the view from its nib.
    [self GetAdviceData];
}

-(void)GetAdviceData{
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_01_07];
    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
    //读取NSString类型的数据
    NSString *userId = [userDefaultes stringForKey:@"USERID"];
    if (userId==nil) {
        return;
    };
    NSString *sessionId = [userDefaultes stringForKey:@"SESSIONID"];
    if (sessionId==nil) {
        return;
    };
    
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM"];
    NSString* timeInuse = [dateFormat stringFromDate:[NSDate date]];
    
    NSString *requestUrl = [NSString stringWithFormat:@"%@?SESSIONID=%@&USERID=%@&GASSTATE=%@&GASTYPE=%@&TIMEINUSE=%@",url,sessionId,userId,strGasstate,strGastype,timeInuse];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:requestUrl]];
    [webView loadRequest:request];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
