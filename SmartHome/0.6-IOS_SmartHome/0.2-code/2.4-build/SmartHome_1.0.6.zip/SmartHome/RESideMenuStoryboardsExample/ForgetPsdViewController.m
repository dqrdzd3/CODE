//
//  ForgetPsdViewController.m
//  SmartHome
//
//  Created by 李静 on 14-11-10.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "ForgetPsdViewController.h"
#import "UIButton+Bootstrap.h"
#import "LoginViewController.h"
#import "SVProgressHUD.h"
#import "ServerResult.h"

@interface ForgetPsdViewController ()
@property (nonatomic, strong) NSTimer *countDownTimer;

@end

@implementation ForgetPsdViewController
int secondsCountDown = 60;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.'
    [self initView];
}
-(void)initView{
    [_postBtn infoStyle];
    [_getVerifyBtn successStyle];
    [_phoneNumberText setEnabled:NO];
    [_phoneNumberText setText:[[NSUserDefaults standardUserDefaults] objectForKey:@"PHONE"]];
    [_nPasswordText setSecureTextEntry:YES
     ];
    [_repeatPasswordText setSecureTextEntry:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)getVerifyBtnClick:(id)sender {
    NSString *phone = [_phoneNumberText text];
    if (phone==nil) {
        return;
    }
    
    if (phone.length!=11) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请检查手机号是否正确" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    [_getVerifyBtn setEnabled:NO];
    secondsCountDown = 60;
//    [_getVerifyBtn ]
    [self startCountDown];
    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_05];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    
    NSDictionary *parameter = @{@"PHONE":phone};
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];

    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];



    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        
    }];
    

}

- (IBAction)postBtnClick:(id)sender {
    [self postData];
}


- (void)postData{
    NSString *phone = [_phoneNumberText text];
    if (phone==nil) {
        return;
    }
    
    if ([phone length]!=11) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"手机号不合法" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *verifyCode = [_verifyCodeText text];
    if (verifyCode==nil) {
        return;
    }
    
    if ([verifyCode length]<1) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请输入验证码" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    NSString *password = [_nPasswordText text];
    if (password==nil) {
        return;
    }
    
    if ([password length]<1) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请输入新密码" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }

    NSString *psdConfirm = [_repeatPasswordText text];
    if (psdConfirm==nil) {
        return;
    }
    
    if ([psdConfirm length]<1) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"请填写完整用户信息" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    if (![password isEqualToString:psdConfirm]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"确认密码与设置的密码不一样" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }

    NSString *url = [SERVER_BASE_URI stringByAppendingString:SH01_03_02_02];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    
    NSDictionary *parameter = @{@"PHONE":phone,@"PASSWORD":password,@"YZM":verifyCode};
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeBlack];
    [manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation,id responseObject) {
        NSLog(@"Success: %@", responseObject);
        NSString *requestTmp = [NSString stringWithString:operation.responseString];
        NSData *resData = [[NSData alloc] initWithData:[requestTmp dataUsingEncoding:NSUTF8StringEncoding]];
        //系统自带JSON解析
        
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:resData options:NSJSONReadingMutableLeaves error:nil];

        
        ServerResult *result = [[ServerResult alloc] initWithDictionary:resultDic error:nil];
        if (result.isOperateSuccess) {
            
            //将上述数据全部存储到NSUserDefaults中
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

            [userDefaults setObject:password forKey:@"PASSWORD"];
            [userDefaults synchronize];
            
            [self dismissViewControllerAnimated:YES completion:nil];
        }else{
            NSString *errorMsg = result.message;
            NSLog(@"Error: %@", errorMsg);
            
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:errorMsg delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
        }
        [SVProgressHUD dismiss];
    } failure:^(AFHTTPRequestOperation *operation,NSError *error) {
        NSLog(@"Error: %@", error);
        [SVProgressHUD dismiss];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"网络连接失败" delegate:Nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }];
}
- (IBAction)backBtnClick:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)countDownTime:(NSTimer *) timer{
    secondsCountDown--;
    if (secondsCountDown>0) {
        
        NSString *str= [NSString stringWithFormat:@"%ds后可重发",secondsCountDown];
        [_getVerifyBtn setTitle:str forState:UIControlStateDisabled];
        
    }else{
        [self stopCountDown];
        [_getVerifyBtn setEnabled:YES];
        [_getVerifyBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    }

}

-(void)startCountDown{
    
    // 定义一个NSTimer
    self.countDownTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                      target:self
                                                         selector:@selector(countDownTime:)  userInfo:nil
                                                     repeats:YES];
    // 当需要调用时,可以把计时器添加到事件处理循环中
//    [[NSRunLoop currentRunLoop] addTimer:self.countDownTimer forMode:NSDefaultRunLoopMode];
}

// 停止定时器
- (void) stopCountDown{
    if (self.countDownTimer != nil){
        // 定时器调用invalidate后，就会自动执行release方法。不需要在显示的调用release方法
        [self.countDownTimer invalidate];
    }
}
@end
