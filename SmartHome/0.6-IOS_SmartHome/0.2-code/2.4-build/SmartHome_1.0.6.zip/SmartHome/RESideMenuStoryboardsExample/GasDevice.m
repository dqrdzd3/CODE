//
//  GasDevice.m
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-1.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "GasDevice.h"
#import "DateUtils.h"
@implementation GasDevice
@synthesize createTime;
@synthesize ch4;
@synthesize co;
@synthesize name;
@synthesize sensorId;
@synthesize switchStatus;
-(BOOL)isOnline{
    long min =[DateUtils getMinitusFromNow:createTime];
    if (min>10) {
        return NO;
    }else{
        return YES;
    }
}
@end
