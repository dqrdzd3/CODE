//
//  DeviceListViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-10-24.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MJRefresh.h"
@interface DeviceListViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_objects;
  
@private

    BOOL _needsActivityIndicator;
    BOOL _currentResolveSuccess;
    NSTimer* _timer;
    __weak IBOutlet UITableView *browserTableView;
}
@property (strong, nonatomic) NSMutableArray *displayServices;

@end
