//
//  Guide2ViewController.h
//  RESideMenuStoryboardsExample
//
//  Created by 李静 on 14-11-3.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EAIntroView.h"
@interface Guide2ViewController : UIViewController <EAIntroDelegate>


@end
