//
//  DateUtils.m
//  SmartHome
//
//  Created by 李静 on 14-11-25.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import "DateUtils.h"

@implementation DateUtils
//获取距离当前时间分钟
+(long)getMinitusFromNow:(NSString *)time{
    int result = 0;
    NSDate *date = [[NSDate alloc] init];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *fromDate = [dateFormatter dateFromString:time];
    
    long second = [date timeIntervalSinceDate:fromDate];
    result = second/60;
    
    return result;
}
@end
