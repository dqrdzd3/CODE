//
//  DateUtils.h
//  SmartHome
//
//  Created by 李静 on 14-11-25.
//  Copyright (c) 2014年 汉威电子股份有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateUtils : NSObject
//距离当前时间分钟数
+(long)getMinitusFromNow:(NSString *)time;
@end
